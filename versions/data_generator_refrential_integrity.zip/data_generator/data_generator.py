import random
from faker import Faker
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Any
import pandas as pd

from .constraint_manager import ConstraintManager
from .validator import DataValidator


class DataGenerator:
    def __init__(self, config, locale=None, logger=None):
        self.config = config
        self.logger = logger

        if self.logger is None:
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
            self.logger = logging.getLogger()

        self.faker = Faker(locale) if locale else Faker()
        self.validator = DataValidator(logger=self.logger)

        # Initialize constraint manager
        self.constraint_manager = ConstraintManager(logger=self.logger)

        # Efficient in-memory storage for generated data
        self._generated_data = {}  # table_name -> DataFrame
        self._cache_size_limit = 50000
        self._batch_fk_refresh_threshold = 10000

    def _convert_value_to_type(self, value: str, data_type: str) -> Any:
        """Convert string value back to original data type"""
        if value is None or value == 'None':
            return None

        try:
            if data_type.lower() in ['int', 'integer']:
                return int(value)
            elif data_type.lower() in ['float', 'double', 'decimal']:
                return float(value)
            elif data_type.lower() in ['bool', 'boolean']:
                return value.lower() in ('true', '1', 'yes', 'on')
            elif data_type.lower() in ['date']:
                if isinstance(value, str):
                    return datetime.strptime(value, '%Y-%m-%d').date()
                return value
            elif data_type.lower() in ['datetime', 'timestamp']:
                if isinstance(value, str):
                    return datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
                return value
            else:
                return str(value)
        except (ValueError, TypeError) as e:
            self.logger.warning(f"Could not convert value '{value}' to type '{data_type}': {e}")
            return value

    def reset_constraint_tracking(self):
        """Reset all constraint tracking for fresh generation"""
        self.constraint_manager.reset_all_constraints()
        self._generated_data.clear()
        self.logger.info("Constraint tracking cache reset")

    def generate_value_with_distribution(self, rule, data_type):
        """Generate value considering probability distributions"""
        if isinstance(rule, dict) and rule.get("type") == "choice":
            choices = rule.get("value", [])
            probabilities = rule.get("probabilities", {})
            if probabilities:
                weights = [probabilities.get(choice, 1.0) for choice in choices]
                return random.choices(choices, weights=weights, k=1)[0]
            else:
                return random.choice(choices)

        return self.generate_value(rule, data_type)

    def generate_value(self, rule, data_type):
        """Enhanced value generation with better rule handling"""
        if isinstance(rule, str):
            cleaned_rule = rule.replace(" ", "").replace("_", "").lower()
            mapped_data = {
                "bool": random.choice([True, False]),
                "uuid": self.faker.uuid4(),
                "cc": self.faker.credit_card_number(),
                "cc_cvv": self.faker.credit_card_security_code(),
                "cc_expiry_date": self.faker.credit_card_expire(),
                "phone": self.faker.phone_number(),
                "phonenumber": self.faker.phone_number(),
                "phoneno": self.faker.phone_number(),
                "firstname": self.faker.first_name(),
                "lastname": self.faker.last_name(),
                "timestamp": self.faker.date_time().strftime("%Y-%m-%d %H:%M:%S"),
            }
            try:
                faker_dict = {x.replace("_", ""): x for x in dir(self.faker) if not x.startswith("_")}
                faker_dict.update({''.join([y[0] for y in x.split('_')]): x for x in dir(self.faker) if
                                   '_' in x and not x.startswith('_')})
                if rule in faker_dict:
                    rule = faker_dict.get(rule, faker_dict.get(cleaned_rule))
                    return getattr(self.faker, rule)()
                else:
                    return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))
            except AttributeError:
                self.logger.warning(f"Faker does not support {rule}. Checking in mapped data")
                return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))

        elif isinstance(rule, dict):
            rule_type = rule.get("type")
            rule_regex = rule.get("regex")
            data = None

            if rule_type is not None:
                if rule_type == "choice":
                    return self.generate_value_with_distribution(rule, data_type)
                elif rule_type in ["date", "date_range"]:
                    start_date = rule.get("start", "1950-01-01")
                    end_date = rule.get("end", datetime.now().strftime("%Y-%m-%d"))
                    data = self.random_date(start_date, end_date)
                elif rule_type in ["time", "time_range"]:
                    start_time = rule.get("start", "00:00:00")
                    end_time = rule.get("end", "23:59:59")
                    start_dt = datetime.strptime(f"1970-01-01 {start_time}", "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(f"1970-01-01 {end_time}", "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%H:%M:%S")
                elif rule_type in ["timestamp", "timestamp_range"]:
                    start_ts = rule.get("start", "2000-01-01 00:00:00")
                    end_ts = rule.get("end", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    start_dt = datetime.strptime(start_ts, "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(end_ts, "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%Y-%m-%d %H:%M:%S")
                elif rule_type == "range":
                    min_val = rule.get("min", 0)
                    max_val = rule.get("max", 10000)
                    if data_type == "int":
                        data = random.randint(int(min_val), int(max_val))
                    elif data_type == "float":
                        data = round(random.uniform(min_val, max_val), 2)
                elif rule_type in ["fixed", "default"]:
                    data = rule.get("value")
                elif rule_type == "email":
                    data = self.faker.email()
                elif rule_type == "phone_number":
                    data = self.faker.phone_number()
                else:
                    data = self.generate_value(rule_type, data_type)

            # Validate against regex if provided
            if rule_regex is not None and data is not None:
                max_attempts = 10
                attempts = 0
                while not self.validator.regex_validator(rule_regex, str(data)) and attempts < max_attempts:
                    if rule_type == "email":
                        data = self.faker.email()
                    elif rule_type == "phone_number":
                        data = self.generate_phone_matching_regex(rule_regex)
                    else:
                        data = self.generate_value(rule_type, data_type)
                    attempts += 1

            return data
        return None

    def random_date(self, start, end):
        """Generate random date between start and end"""
        start = datetime.strptime(start, "%Y-%m-%d")
        end = datetime.strptime(end, "%Y-%m-%d")
        delta = end - start
        return (start + timedelta(days=random.randint(0, delta.days))).date()

    def generate_phone_matching_regex(self, regex_pattern):
        """Generate phone number that matches the given regex pattern"""
        if "10,15" in regex_pattern:
            length = random.randint(10, 15)
            return ''.join([str(random.randint(0, 9)) for _ in range(length)])
        return self.faker.phone_number()

    def _generate_default_value(self, data_type):
        """Generate default value based on data type"""
        if data_type == "int":
            return random.randint(1, 100000)
        elif data_type == "float":
            return round(random.uniform(1.0, 100.0), 2)
        elif data_type == "bool":
            return random.choice([True, False])
        elif data_type == "date":
            return self.faker.date_between(start_date="-5y", end_date="today")
        elif data_type == "str":
            return self.faker.text(max_nb_chars=50)
        else:
            return None

    def _get_fk_values_optimized(self, parent_table: str, parent_column: str,
                                 expected_data_type: str = None, sample_size: int = None) -> List[Any]:
        """Optimized foreign key value retrieval using constraint manager"""
        available_values = self.constraint_manager.get_fk_values(parent_table, parent_column, sample_size)

        # If no values from constraint manager, try to get from generated data
        if not available_values and parent_table in self._generated_data:
            df = self._generated_data[parent_table]
            if not df.empty and parent_column in df.columns:
                unique_values = df[parent_column].dropna().unique().tolist()
                self.constraint_manager.update_fk_pool(parent_table, parent_column, unique_values)
                available_values = unique_values

        # Convert to expected data type if specified
        if expected_data_type and available_values:
            converted_values = []
            for value in available_values:
                converted_val = self._convert_value_to_type(str(value), expected_data_type)
                converted_values.append(converted_val)
            available_values = converted_values

        self.logger.debug(f"Retrieved {len(available_values)} FK values from {parent_table}.{parent_column}")
        return available_values

    def _get_fk_values_with_relationship(self, fk_config: Dict, expected_data_type: str = None,
                                         record_count: int = 1, sample_size: int = None) -> List[Any]:
        """Get foreign key values considering relationship type using constraint manager"""
        parent_table = fk_config["parent_table"]
        parent_column = fk_config["parent_column"]

        # Get base available values
        available_values = self._get_fk_values_optimized(
            parent_table, parent_column, expected_data_type, sample_size
        )

        if not available_values:
            self.logger.warning(f"No available values for FK {parent_table}.{parent_column}")
            return []

        # Use constraint manager to handle relationship logic
        return self.constraint_manager.get_fk_values_with_relationship(
            fk_config, available_values, record_count
        )

    def _refresh_fk_pools(self, table_name: str = None):
        """Efficiently refresh foreign key pools from DataFrame storage"""
        tables_to_refresh = [table_name] if table_name else list(self._generated_data.keys())

        df_map = {name: self._generated_data[name] for name in tables_to_refresh if name in self._generated_data}
        table_metadata_map = {name: self._get_table_metadata(name) for name in tables_to_refresh}

        self.constraint_manager.refresh_fk_pools_from_dataframe(df_map, table_metadata_map)

    def _get_table_metadata(self, table_name: str) -> Dict:
        """Get table metadata from config"""
        if isinstance(self.config, dict) and 'tables' in self.config:
            for table in self.config['tables']:
                if table.get('table_name') == table_name:
                    return table
        return {}

    def _get_primary_key_columns(self, table_metadata: Dict) -> List[str]:
        """Get primary key columns from table metadata"""
        return self.constraint_manager._get_primary_key_columns(table_metadata)

    def generate_unique_value(self, column_def, table_name, max_attempts=100):
        """Generate unique value using constraint manager"""
        column_name = column_def["name"]
        data_type = column_def["type"]
        rule = column_def.get("rule", {})

        def value_generator():
            return self.generate_value(rule, data_type) if rule else self._generate_default_value(data_type)

        return self.constraint_manager.generate_unique_value(table_name, column_name, value_generator, max_attempts)

    def apply_conditional_rules(self, row, column_def):
        """Apply conditional rules based on other column values using constraint manager"""
        conditional_rules = column_def.get("conditional_rules", [])

        for condition_rule in conditional_rules:
            when_conditions = condition_rule.get("when", [])
            then_rule = condition_rule.get("then", {}).get("rule", {})

            if self.constraint_manager.evaluate_conditions(when_conditions, row):
                if isinstance(then_rule, dict) and then_rule.get("type") in ["fixed", "default"]:
                    return then_rule.get("value")
                else:
                    base_rule = column_def.get("rule", {})
                    if isinstance(base_rule, dict) and isinstance(then_rule, dict):
                        merged_rule = {**base_rule, **then_rule}
                    else:
                        merged_rule = then_rule
                    return self.generate_value_with_distribution(merged_rule, column_def["type"])

        return None

    def generate_batch_optimized(self, table_metadata, batch_size, foreign_key_data=None):
        """Optimized batch generation using constraint manager"""
        table_name = table_metadata["table_name"]
        columns = table_metadata["columns"]
        foreign_keys = table_metadata.get("foreign_keys", [])

        if foreign_key_data is None:
            foreign_key_data = {}

        batch_data = []

        # Pre-generate FK pools for this batch with relationship awareness
        fk_pools = {}
        fk_distributions = {}

        for fk in foreign_keys:
            child_column = fk["child_column"]
            relationship_type = self.constraint_manager.get_relationship_type(fk)

            # Get expected data type
            expected_type = self._get_column_data_type(table_metadata, child_column)

            if relationship_type in ["one_to_many", "one_to_one"]:
                # Pre-calculate distribution for the entire batch
                fk_values = self._get_fk_values_with_relationship(
                    fk, expected_type, batch_size
                )
                fk_distributions[child_column] = fk_values
            else:
                # Use regular FK pool for many-to-one
                available_values = self._get_fk_values_optimized(
                    fk["parent_table"], fk["parent_column"], expected_type, sample_size=10000
                )
                # Include provided foreign_key_data
                fk_key = f"{fk['parent_table']}.{fk['parent_column']}"
                if fk_key in foreign_key_data:
                    additional_values = [
                        self._convert_value_to_type(str(val), expected_type)
                        for val in foreign_key_data[fk_key]
                    ]
                    available_values.extend(additional_values)

                if available_values:
                    fk_pools[child_column] = available_values
                else:
                    # Generate fallback values
                    fallback_values = []
                    for i in range(min(1000, batch_size)):
                        if expected_type == 'int':
                            fallback_values.append(random.randint(1, 1000))
                        else:
                            fallback_values.append(f"default_{i}")
                    fk_pools[child_column] = fallback_values

        # Generate batch records
        for record_idx in range(batch_size):
            row = {}

            # Handle primary keys using constraint manager
            pk_columns = self._get_primary_key_columns(table_metadata)
            composite_columns = table_metadata.get("composite_primary_key", [])

            if composite_columns:
                # Handle composite primary key
                for i, col_name in enumerate(composite_columns):
                    col_def = next((c for c in columns if c["name"] == col_name), None)
                    if col_def:
                        def pk_generator():
                            if col_def["type"] == "int":
                                return record_idx + 1 + i
                            elif col_def.get("rule") == "uuid" or col_def["type"] == "uuid":
                                return self.generate_value(col_def.get("rule"), col_def["type"])
                            else:
                                return f"{col_name}_{record_idx + 1 + i}"

                        # Use constraint manager for PK uniqueness
                        row[col_name] = self.constraint_manager.generate_unique_pk_value(
                            table_name, col_name, pk_generator
                        )

            elif pk_columns:
                # Handle single primary key
                pk_col_name = pk_columns[0]
                pk_col_def = next((c for c in columns if c["name"] == pk_col_name), None)
                if pk_col_def:
                    def pk_generator():
                        if pk_col_def["type"] == "int":
                            return record_idx + 1
                        elif pk_col_def.get("rule") == "uuid" or pk_col_def["type"] == "uuid":
                            return self.generate_value(pk_col_def.get("rule"), pk_col_def["type"])
                        else:
                            return f"{table_name}_{record_idx + 1}"

                    row[pk_col_name] = self.constraint_manager.generate_unique_pk_value(
                        table_name, pk_col_name, pk_generator
                    )

            # Handle foreign keys with relationship awareness
            for fk in foreign_keys:
                child_column = fk["child_column"]

                if child_column in fk_distributions:
                    # Use pre-calculated distribution for one-to-one and one-to-many
                    if record_idx < len(fk_distributions[child_column]):
                        row[child_column] = fk_distributions[child_column][record_idx]
                elif child_column in fk_pools and fk_pools[child_column]:
                    # Use random selection for many-to-one
                    row[child_column] = random.choice(fk_pools[child_column])

                # Handle nullable constraint using constraint manager
                if fk.get("nullable", False):
                    col_def = next((c for c in columns if c["name"] == child_column), None)
                    if col_def and self.constraint_manager.should_generate_null(col_def):
                        row[child_column] = None

            # Generate other column values
            for column in columns:
                column_name = column["name"]

                if column_name in row:
                    continue

                data_type = column["type"]
                constraints = column.get("constraints", []) + column.get("constraint", [])

                # Handle unique constraints using constraint manager
                if "unique" in constraints:
                    row[column_name] = self.generate_unique_value(column, table_name)
                else:
                    # Apply conditional rules
                    conditional_value = self.apply_conditional_rules(row, column)
                    if conditional_value is not None:
                        row[column_name] = conditional_value
                    else:
                        # Generate regular value
                        rule = column.get("rule")
                        if rule:
                            row[column_name] = self.generate_value_with_distribution(rule, data_type)
                        else:
                            row[column_name] = self._generate_default_value(data_type)

                # Handle nullable columns using constraint manager
                if self.constraint_manager.should_generate_null(column):
                    row[column_name] = None

                # Apply length constraints using constraint manager
                length_constraint = column.get("length")
                if length_constraint and row[column_name] is not None:
                    rule = column.get("rule", {})
                    row[column_name] = self.constraint_manager.adjust_value_for_length(
                        row[column_name], length_constraint, rule, data_type
                    )

            batch_data.append(row)

        # Apply batch-level length constraints
        batch_data = self.constraint_manager.apply_length_constraints_to_batch(batch_data, table_metadata)

        return batch_data

    def _get_column_data_type(self, table_metadata: Dict, column_name: str) -> str:
        """Get data type for a column from table metadata"""
        columns = table_metadata.get('columns', [])
        for col in columns:
            if col.get('name') == column_name:
                return col.get('type', 'str')
        return 'str'

    def store_generated_batch(self, table_name: str, batch_data: List[Dict]):
        """Store generated batch in DataFrame format for efficient access"""
        if not batch_data:
            return

        # Convert to DataFrame
        df_batch = pd.DataFrame(batch_data)

        # Append to existing DataFrame or create new one
        if table_name in self._generated_data:
            self._generated_data[table_name] = pd.concat([
                self._generated_data[table_name], df_batch
            ], ignore_index=True)
        else:
            self._generated_data[table_name] = df_batch

        # Refresh FK pools periodically for large datasets
        if len(self._generated_data[table_name]) % self._batch_fk_refresh_threshold == 0:
            self._refresh_fk_pools(table_name)

        self.logger.debug(f"Stored batch of {len(batch_data)} records for {table_name}. "
                          f"Total: {len(self._generated_data[table_name])}")

    def get_generated_data_df(self, table_name: str) -> pd.DataFrame:
        """Get generated data as DataFrame"""
        return self._generated_data.get(table_name, pd.DataFrame())

    def get_generated_data_dict(self, table_name: str) -> List[Dict[str, Any]]:
        """Get generated data as list of dictionaries (for compatibility)"""
        df = self.get_generated_data_df(table_name)
        if df.empty:
            return []
        return df.to_dict('records')

    def clear_generated_data(self, table_name: str = None):
        """Clear generated data for a specific table or all tables"""
        if table_name:
            if table_name in self._generated_data:
                del self._generated_data[table_name]
            self.constraint_manager.reset_table_constraints(table_name)
        else:
            self._generated_data.clear()
            self.constraint_manager.reset_all_constraints()

    def get_constraint_statistics(self):
        """Get constraint statistics from constraint manager"""
        return self.constraint_manager.get_constraint_statistics()
