import logging
import json
import random
from typing import Dict, List, Any, Set, Union, Optional, Tuple
from collections import defaultdict
import itertools

import pandas as pd


class ConstraintManager:
    """
    Comprehensive constraint manager for data generation including:
    - Primary Key constraints (simple and composite)
    - Foreign Key constraints with relationship types
    - Unique constraints (simple and composite)
    - Length constraints with intelligent adjustment
    - Nullable constraints with probability control
    - Conditional constraints with complex evaluation
    - Sequence generation with prefix/suffix
    - Cross-table validation
    """

    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)

        # Basic constraint tracking caches
        self._pk_cache = defaultdict(set)  # table.column -> set of used values
        self._fk_pools = defaultdict(list)  # table.column -> list of available values
        self._unique_constraints = defaultdict(set)  # table.column -> set of used values

        # Relationship constraint tracking
        self._one_to_one_used = defaultdict(set)  # parent_table.parent_column -> set of used values
        self._one_to_many_distribution = defaultdict(dict)  # parent_table.parent_column -> {parent_id: child_count}

        # Advanced constraint tracking
        self._composite_constraints = defaultdict(set)  # table.composite_key -> set of used combinations
        self._conditional_cache = defaultdict(dict)  # table.column -> {condition_hash: generated_values}
        self._sequence_counters = defaultdict(int)  # table.column -> current sequence value

        # Performance settings
        self._cache_size_limit = 50000
        self._batch_fk_refresh_threshold = 10000

    def reset_all_constraints(self):
        """Reset all constraint tracking for fresh generation"""
        self._pk_cache.clear()
        self._fk_pools.clear()
        self._unique_constraints.clear()
        self._one_to_one_used.clear()
        self._one_to_many_distribution.clear()
        self._composite_constraints.clear()
        self._conditional_cache.clear()
        self._sequence_counters.clear()
        self.logger.info("All constraint tracking caches reset")

    def reset_table_constraints(self, table_name: str):
        """Reset constraints for a specific table"""
        keys_to_remove = []
        for cache in [self._pk_cache, self._fk_pools, self._unique_constraints,
                      self._one_to_one_used, self._one_to_many_distribution,
                      self._composite_constraints, self._conditional_cache, self._sequence_counters]:
            for key in cache.keys():
                if key.startswith(f"{table_name}."):
                    keys_to_remove.append((cache, key))

        for cache, key in keys_to_remove:
            del cache[key]

        self.logger.info(f"Reset constraints for table: {table_name}")

    def is_pk_value_used(self, table_name: str, column_name: str, value: Any) -> bool:
        """Check if primary key value is already used"""
        constraint_key = f"{table_name}.{column_name}"
        return value in self._pk_cache.get(constraint_key, set())

    def add_pk_value(self, table_name: str, column_name: str, value: Any):
        """Add primary key value to tracking"""
        constraint_key = f"{table_name}.{column_name}"
        if len(self._pk_cache[constraint_key]) < self._cache_size_limit:
            self._pk_cache[constraint_key].add(value)

    def generate_unique_pk_value(self, table_name: str, column_name: str,
                                 value_generator_func, max_attempts: int = 100) -> Any:
        """Generate a unique primary key value"""
        for attempt in range(max_attempts):
            value = value_generator_func()
            if not self.is_pk_value_used(table_name, column_name, value):
                self.add_pk_value(table_name, column_name, value)
                return value
        base_value = str(value_generator_func()) if value_generator_func else "pk"
        unique_value = f"{base_value}_{random.randint(10000, 99999)}"
        self.add_pk_value(table_name, column_name, unique_value)
        return unique_value

    def is_unique_value_used(self, table_name: str, column_name: str, value: Any) -> bool:
        """Check if unique constraint value is already used"""
        constraint_key = f"{table_name}.{column_name}"
        return value in self._unique_constraints.get(constraint_key, set())

    def add_unique_value(self, table_name: str, column_name: str, value: Any):
        """Add value to unique constraint tracking"""
        constraint_key = f"{table_name}.{column_name}"
        if len(self._unique_constraints[constraint_key]) < self._cache_size_limit:
            self._unique_constraints[constraint_key].add(value)

    def generate_unique_value(self, table_name: str, column_name: str,
                              value_generator_func, max_attempts: int = 100) -> Any:
        """Generate unique value for columns with unique constraints"""
        for attempt in range(max_attempts):
            value = value_generator_func()
            if not self.is_unique_value_used(table_name, column_name, value):
                self.add_unique_value(table_name, column_name, value)
                return value

        base_value = str(value_generator_func()) if value_generator_func else "unique"
        unique_value = f"{base_value}_{random.randint(10000, 99999)}"
        self.add_unique_value(table_name, column_name, unique_value)
        return unique_value

    def update_fk_pool(self, table_name: str, column_name: str, values: List[Any]):
        """Update foreign key pool with new values"""
        fk_key = f"{table_name}.{column_name}"
        self._fk_pools[fk_key] = values
        self.logger.debug(f"Updated FK pool {fk_key} with {len(values)} values")

    def get_fk_values(self, parent_table: str, parent_column: str,
                      sample_size: Optional[int] = None) -> List[Any]:
        """Get available foreign key values"""
        fk_key = f"{parent_table}.{parent_column}"
        available_values = self._fk_pools.get(fk_key, [])

        # Sample if too many values (for performance)
        if sample_size and len(available_values) > sample_size:
            available_values = random.sample(available_values, sample_size)

        return available_values

    def refresh_fk_pools_from_dataframe(self, df_map: Dict[str, pd.DataFrame],
                                        table_metadata_map: Dict[str, Dict]):
        """Efficiently refresh foreign key pools from DataFrame storage"""
        for table_name, df in df_map.items():
            if df.empty:
                continue

            table_metadata = table_metadata_map.get(table_name, {})
            pk_columns = self._get_primary_key_columns(table_metadata)

            # Update FK pools for each PK column
            for pk_col in pk_columns:
                if pk_col in df.columns:
                    unique_values = df[pk_col].dropna().unique().tolist()
                    self.update_fk_pool(table_name, pk_col, unique_values)

    def get_relationship_type(self, fk_config: Dict) -> str:
        """Get relationship type from foreign key configuration"""
        return fk_config.get("relationship_type", "many_to_one").lower()

    def handle_one_to_one_relationship(self, fk_config: Dict, available_values: List[Any]) -> Optional[Any]:
        """Handle one-to-one relationship constraints"""
        parent_table = fk_config["parent_table"]
        parent_column = fk_config["parent_column"]
        constraint_key = f"{parent_table}.{parent_column}"

        # Filter out already used values
        unused_values = [val for val in available_values
                         if val not in self._one_to_one_used[constraint_key]]

        if not unused_values:
            self.logger.warning(f"No unused values available for one-to-one relationship {constraint_key}")
            return None

        # Select a value and mark it as used
        selected_value = random.choice(unused_values)
        self._one_to_one_used[constraint_key].add(selected_value)

        self.logger.debug(f"Assigned one-to-one value {selected_value} for {constraint_key}")
        return selected_value

    def handle_one_to_many_relationship(self, fk_config: Dict, available_values: List[Any],
                                        record_count: int) -> List[Any]:
        """Handle one-to-many relationship with distribution control"""
        distribution_type = fk_config.get("distribution", "random")
        min_children = fk_config.get("min_children", 1)
        max_children = fk_config.get("max_children", 10)

        if distribution_type == "even":
            return self._distribute_evenly(available_values, record_count, min_children, max_children)
        elif distribution_type == "weighted":
            weights = fk_config.get("weights", {})
            return self._distribute_weighted(available_values, record_count, weights)
        else:  # random distribution
            return self._distribute_randomly(available_values, record_count, min_children, max_children)

    def _distribute_evenly(self, available_values: List[Any], record_count: int,
                           min_children: int, max_children: int) -> List[Any]:
        """Distribute children evenly across parent values"""
        if not available_values:
            return []

        distribution = []
        values_cycle = itertools.cycle(available_values)

        for _ in range(record_count):
            distribution.append(next(values_cycle))

        return distribution

    def _distribute_randomly(self, available_values: List[Any], record_count: int,
                             min_children: int, max_children: int) -> List[Any]:
        """Distribute children randomly with min/max constraints"""
        if not available_values:
            return []

        distribution = []
        parent_counts = {val: 0 for val in available_values}

        for _ in range(record_count):
            # Filter parents that haven't reached max_children
            available_parents = [val for val, count in parent_counts.items()
                                 if count < max_children]

            if not available_parents:
                available_parents = available_values

            selected_parent = random.choice(available_parents)
            distribution.append(selected_parent)
            parent_counts[selected_parent] += 1

        return distribution

    def _distribute_weighted(self, available_values: List[Any], record_count: int,
                             weights: Dict[str, float]) -> List[Any]:
        """Distribute children based on specified weights"""
        if not available_values:
            return []

        weighted_values = []
        value_weights = []

        for value in available_values:
            weight = weights.get(str(value), 1.0)
            weighted_values.append(value)
            value_weights.append(weight)

        return random.choices(weighted_values, weights=value_weights, k=record_count)

    def get_fk_values_with_relationship(self, fk_config: Dict, available_values: List[Any],
                                        record_count: int = 1) -> List[Any]:
        """Get foreign key values considering relationship type"""
        relationship_type = self.get_relationship_type(fk_config)

        if not available_values:
            self.logger.warning(f"No available values for FK {fk_config['parent_table']}.{fk_config['parent_column']}")
            return []

        # Handle different relationship types
        if relationship_type == "one_to_one":
            if record_count == 1:
                value = self.handle_one_to_one_relationship(fk_config, available_values)
                return [value] if value is not None else []
            else:
                result = []
                for _ in range(record_count):
                    value = self.handle_one_to_one_relationship(fk_config, available_values)
                    if value is not None:
                        result.append(value)
                    else:
                        break
                return result

        elif relationship_type == "one_to_many":
            return self.handle_one_to_many_relationship(fk_config, available_values, record_count)

        else:  # many_to_one (default behavior)
            if record_count == 1:
                return [random.choice(available_values)]
            else:
                return [random.choice(available_values) for _ in range(record_count)]

    def check_length_constraint(self, value: Any, length_constraint: Any) -> bool:
        """Check if value meets length constraint"""
        if not isinstance(value, str):
            return True

        value_length = len(value)

        if isinstance(length_constraint, int):
            return value_length == length_constraint
        elif isinstance(length_constraint, dict):
            min_length = length_constraint.get('min', 0)
            max_length = length_constraint.get('max', float('inf'))
            return min_length <= value_length <= max_length

        return True

    def adjust_value_for_length(self, value: Any, length_constraint: Any,
                                rule: Dict = None, data_type: str = "str") -> str:
        """Adjust value to meet length constraint"""
        if not isinstance(value, str):
            return str(value)

        current_length = len(value)

        if isinstance(length_constraint, int):
            target_length = length_constraint

            if current_length > target_length:
                # Truncate intelligently
                if isinstance(rule, dict) and rule.get("prefix"):
                    prefix = rule.get("prefix", "")
                    suffix = rule.get("suffix", "")
                    available_length = target_length - len(prefix) - len(suffix)
                    if available_length > 0:
                        core_value = value[len(prefix):len(value) - len(suffix)] if suffix else value[len(prefix):]
                        truncated_core = core_value[:available_length]
                        return f"{prefix}{truncated_core}{suffix}"
                return value[:target_length]
            elif current_length < target_length:
                # Pad with appropriate character
                if data_type in ['int', 'integer'] and value.isdigit():
                    return value.zfill(target_length)
                else:
                    return value.ljust(target_length, 'X')

        elif isinstance(length_constraint, dict):
            min_length = length_constraint.get('min', 0)
            max_length = length_constraint.get('max', float('inf'))

            if current_length < min_length:
                if data_type in ['int', 'integer'] and value.isdigit():
                    return value.zfill(min_length)
                else:
                    return value.ljust(min_length, 'X')
            elif current_length > max_length and max_length != float('inf'):
                return value[:int(max_length)]

        return value

    def should_generate_null(self, column_def: Dict, null_probability: float = 0.1) -> bool:
        """Determine if a nullable column should generate a null value"""
        nullable = column_def.get("nullable", True)
        if not nullable:
            return False

        custom_probability = column_def.get("null_probability", null_probability)
        return random.random() < custom_probability

    def evaluate_conditions(self, conditions: List[Dict], row: Dict) -> bool:
        """Evaluate conditional constraints against a row"""
        for condition in conditions:
            column = condition["column"]
            operator = condition["operator"]

            operator_clean = operator.replace(" ", "").replace("_", "").lower()

            operator_mapping = {
                "equals": "eq", "=": "eq", "eq": "eq",
                "notequals": "ne", "!=": "ne", "ne": "ne",
                "less": "lt", "<": "lt", "lessthan": "lt", "lt": "lt",
                "lessequal": "le", "<=": "le", "le": "le",
                "greater": "gt", ">": "gt", "greaterthan": "gt", "gt": "gt",
                "greaterequal": "ge", ">=": "ge", "ge": "ge",
                "between": "range", "range": "range",
                "in": "contains", "contains": "contains",
                "notin": "notcontains", "notcontains": "notcontains",
            }

            normalized_operator = operator_mapping.get(operator_clean, operator_clean)

            if column not in row:
                self.logger.warning(f"Condition column '{column}' not found in row data")
                return False

            row_value = row[column]
            condition_value = condition.get("value")

            try:
                if normalized_operator == "eq":
                    if row_value != condition_value:
                        return False
                elif normalized_operator == "ne":
                    if row_value == condition_value:
                        return False
                elif normalized_operator == "lt":
                    if row_value is None or row_value >= condition_value:
                        return False
                elif normalized_operator == "le":
                    if row_value is None or row_value > condition_value:
                        return False
                elif normalized_operator == "gt":
                    if row_value is None or row_value <= condition_value:
                        return False
                elif normalized_operator == "ge":
                    if row_value is None or row_value < condition_value:
                        return False
                elif normalized_operator == "range":
                    min_val = condition.get("min", condition.get("start"))
                    max_val = condition.get("max", condition.get("end"))
                    if row_value is None or not (min_val <= row_value <= max_val):
                        return False
                elif normalized_operator == "contains":
                    values_list = condition.get("values", condition.get("value", []))
                    if row_value not in values_list:
                        return False
                elif normalized_operator == "notcontains":
                    values_list = condition.get("values", condition.get("value", []))
                    if row_value in values_list:
                        return False
                else:
                    self.logger.warning(f"Unknown operator '{operator}' (normalized: '{normalized_operator}')")
                    return False

            except (TypeError, ValueError) as e:
                self.logger.warning(f"Error evaluating condition {condition}: {e}")
                return False

        return True

    def _get_primary_key_columns(self, table_metadata: Dict) -> List[str]:
        """Get primary key columns from table metadata"""
        composite_pk = table_metadata.get("composite_primary_key", [])
        if composite_pk:
            return composite_pk

        pk_columns = []
        for column in table_metadata.get("columns", []):
            constraints = column.get("constraints", [])
            constraint = column.get("constraint", [])

            if "PK" in constraints or "PK" in constraint:
                pk_columns.append(column["name"])

        return pk_columns

    def get_constraint_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics about constraint usage"""
        return {
            "primary_key_constraints": len(self._pk_cache),
            "unique_constraints": len(self._unique_constraints),
            "foreign_key_pools": len(self._fk_pools),
            "one_to_one_relationships": len(self._one_to_one_used),
            "one_to_many_relationships": len(self._one_to_many_distribution),
            "composite_constraints": len(self._composite_constraints),
            "conditional_cache_entries": len(self._conditional_cache),
            "sequence_counters": len(self._sequence_counters),
            "total_pk_values_tracked": sum(len(values) for values in self._pk_cache.values()),
            "total_unique_values_tracked": sum(len(values) for values in self._unique_constraints.values()),
            "total_fk_values_available": sum(len(values) for values in self._fk_pools.values()),
            "total_composite_combinations": sum(
                len(combinations) for combinations in self._composite_constraints.values()),
            "active_sequences": sum(1 for counter in self._sequence_counters.values() if counter > 0)
        }

    # ===================== COMPOSITE CONSTRAINTS =====================

    def handle_composite_constraint(self, table_name: str, column_names: List[str],
                                    values: List[Any]) -> bool:
        """Handle composite unique constraints (multiple columns together must be unique)"""
        if len(column_names) != len(values):
            self.logger.error(f"Column names and values length mismatch for composite constraint")
            return False

        composite_key = f"{table_name}.{'+'.join(sorted(column_names))}"
        value_tuple = tuple(values)

        if value_tuple in self._composite_constraints[composite_key]:
            return False  # Combination already exists

        self._composite_constraints[composite_key].add(value_tuple)
        return True

    def generate_sequence_value(self, table_name: str, column_name: str,
                                start: int = 1, step: int = 1,
                                prefix: str = "", suffix: str = "") -> Any:
        """Generate sequential values with optional prefix/suffix"""
        sequence_key = f"{table_name}.{column_name}"

        if sequence_key not in self._sequence_counters:
            self._sequence_counters[sequence_key] = start
        else:
            self._sequence_counters[sequence_key] += step

        current_value = self._sequence_counters[sequence_key]

        if prefix or suffix:
            return f"{prefix}{current_value}{suffix}"
        else:
            return current_value

    def validate_cross_table_constraints(self, table_data_map: Dict[str, List[Dict]],
                                         constraint_rules: List[Dict]) -> List[str]:
        """Validate constraints that span multiple tables"""
        validation_errors = []

        for rule in constraint_rules:
            rule_type = rule.get("type")

            if rule_type == "referential_integrity":
                # Check that all foreign key values exist in parent table
                child_table = rule["child_table"]
                parent_table = rule["parent_table"]
                child_column = rule["child_column"]
                parent_column = rule["parent_column"]

                if child_table not in table_data_map or parent_table not in table_data_map:
                    validation_errors.append(
                        f"Missing table data for referential integrity check: {child_table} -> {parent_table}")
                    continue

                child_data = table_data_map[child_table]
                parent_data = table_data_map[parent_table]

                parent_values = {row.get(parent_column) for row in parent_data if row.get(parent_column) is not None}

                for row in child_data:
                    child_value = row.get(child_column)
                    if child_value is not None and child_value not in parent_values:
                        validation_errors.append(
                            f"Referential integrity violation: {child_table}.{child_column} = {child_value} not found in {parent_table}.{parent_column}")

            elif rule_type == "data_consistency":
                # Check data consistency across tables (e.g., sum constraints)
                table_constraints = rule.get("tables", [])
                for constraint in table_constraints:
                    table_name = constraint["table"]
                    column_name = constraint["column"]
                    expected_sum = constraint.get("expected_sum")

                    if table_name in table_data_map and expected_sum is not None:
                        actual_sum = sum(row.get(column_name, 0) for row in table_data_map[table_name] if
                                         isinstance(row.get(column_name), (int, float)))
                        if abs(actual_sum - expected_sum) > constraint.get("tolerance", 0):
                            validation_errors.append(
                                f"Data consistency violation: {table_name}.{column_name} sum = {actual_sum}, expected = {expected_sum}")

        return validation_errors

    def optimize_constraint_performance(self):
        """Optimize constraint tracking performance by cleaning up old data"""
        # Clean up caches that exceed size limits
        for cache_name, cache in [
            ("pk_cache", self._pk_cache),
            ("unique_constraints", self._unique_constraints),
            ("composite_constraints", self._composite_constraints)
        ]:
            for key, values in cache.items():
                if len(values) > self._cache_size_limit:
                    # Keep only the most recent values (assuming they're more relevant)
                    if isinstance(values, set):
                        cache[key] = set(list(values)[-self._cache_size_limit // 2:])
                    elif isinstance(values, list):
                        cache[key] = values[-self._cache_size_limit // 2:]

                    self.logger.debug(
                        f"Optimized {cache_name}[{key}]: reduced from {len(values)} to {len(cache[key])} entries")

    def export_constraint_state(self, output_path: str):
        """Export current constraint state to file for debugging or resuming generation"""
        constraint_state = {
            "pk_cache": {k: list(v) for k, v in self._pk_cache.items()},
            "unique_constraints": {k: list(v) for k, v in self._unique_constraints.items()},
            "fk_pools": dict(self._fk_pools),
            "one_to_one_used": {k: list(v) for k, v in self._one_to_one_used.items()},
            "composite_constraints": {k: [list(combo) for combo in v] for k, v in self._composite_constraints.items()},
            "sequence_counters": dict(self._sequence_counters),
            "statistics": self.get_constraint_statistics()
        }

        try:
            with open(output_path, 'w') as f:
                json.dump(constraint_state, f, indent=2, default=str)
            self.logger.info(f"Constraint state exported to: {output_path}")
        except Exception as e:
            self.logger.error(f"Failed to export constraint state: {e}")

    def import_constraint_state(self, input_path: str):
        """Import constraint state from file to resume generation"""
        try:
            with open(input_path, 'r') as f:
                constraint_state = json.load(f)

            # Restore caches
            self._pk_cache = defaultdict(set)
            for k, v in constraint_state.get("pk_cache", {}).items():
                self._pk_cache[k] = set(v)

            self._unique_constraints = defaultdict(set)
            for k, v in constraint_state.get("unique_constraints", {}).items():
                self._unique_constraints[k] = set(v)

            self._fk_pools = defaultdict(list, constraint_state.get("fk_pools", {}))

            self._one_to_one_used = defaultdict(set)
            for k, v in constraint_state.get("one_to_one_used", {}).items():
                self._one_to_one_used[k] = set(v)

            self._composite_constraints = defaultdict(set)
            for k, combinations in constraint_state.get("composite_constraints", {}).items():
                self._composite_constraints[k] = {tuple(combo) for combo in combinations}

            self._sequence_counters = defaultdict(int, constraint_state.get("sequence_counters", {}))

            self.logger.info(f"Constraint state imported from: {input_path}")

        except Exception as e:
            self.logger.error(f"Failed to import constraint state: {e}")

    def apply_length_constraints_to_batch(self, batch_data: List[Dict], table_metadata: Dict) -> List[Dict]:
        """Apply length constraints to a batch of data"""
        if not batch_data or not table_metadata:
            return batch_data

        columns = table_metadata.get("columns", [])

        for i, row in enumerate(batch_data):
            for column in columns:
                column_name = column.get("name")
                length_constraint = column.get("length")

                if not column_name or not length_constraint or column_name not in row:
                    continue

                current_value = row[column_name]

                # Skip null values
                if current_value is None:
                    continue

                # Only process string values or values that can be converted to strings
                if not isinstance(current_value, (str, int, float)):
                    continue

                # Convert to string for length processing
                str_value = str(current_value)

                # Get additional column metadata
                rule = column.get("rule", {})
                data_type = column.get("type", "str")

                # Apply length constraint adjustment
                adjusted_value = self.adjust_value_for_length(
                    str_value, length_constraint, rule, data_type
                )

                # Convert back to original type if needed
                if adjusted_value != str_value:
                    try:
                        if data_type.lower() in ['int', 'integer'] and adjusted_value.isdigit():
                            batch_data[i][column_name] = int(adjusted_value)
                        elif data_type.lower() in ['float', 'double', 'decimal']:
                            batch_data[i][column_name] = float(adjusted_value)
                        else:
                            batch_data[i][column_name] = adjusted_value

                        self.logger.debug(
                            f"Length constraint applied to {column_name}: '{current_value}' -> '{adjusted_value}'")

                    except (ValueError, TypeError) as e:
                        # If conversion fails, keep as string
                        batch_data[i][column_name] = adjusted_value
                        self.logger.warning(
                            f"Could not convert adjusted value back to {data_type} for {column_name}: {e}")

        return batch_data
