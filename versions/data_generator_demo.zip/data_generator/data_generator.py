import random
from faker import Faker
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Any, Set, Union, Optional
from collections import defaultdict
import json
import pandas as pd

from .validator import DataValidator


class DataGenerator:
    def __init__(self, config, locale=None, logger=None):
        self.config = config
        self.logger = logger

        if self.logger is None:
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
            self.logger = logging.getLogger()

        self.faker = None
        if locale is not None:
            self.faker = Faker(locale=locale)
        else:
            self.faker = Faker()
        self.validator = DataValidator(logger=self.logger)

        # Efficient in-memory storage for generated data
        self._generated_data = {}  # table_name -> DataFrame

        # Optimized caches for constraint tracking
        self._pk_cache = defaultdict(set)  # table.column -> set of used values
        self._fk_pools = defaultdict(list)  # table.column -> list of available values
        self._unique_constraints = defaultdict(set)  # table.column -> set of used values

        # Performance optimizations
        self._cache_size_limit = 50000  # Increased cache size
        self._batch_fk_refresh_threshold = 10000  # Refresh FK pools every N records

    def _convert_value_to_type(self, value: str, data_type: str) -> Any:
        """Convert string value back to original data type"""
        if value is None or value == 'None':
            return None

        try:
            if data_type.lower() in ['int', 'integer']:
                return int(value)
            elif data_type.lower() in ['float', 'double', 'decimal']:
                return float(value)
            elif data_type.lower() in ['bool', 'boolean']:
                return value.lower() in ('true', '1', 'yes', 'on')
            elif data_type.lower() in ['date']:
                if isinstance(value, str):
                    return datetime.strptime(value, '%Y-%m-%d').date()
                return value
            elif data_type.lower() in ['datetime', 'timestamp']:
                if isinstance(value, str):
                    return datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
                return value
            else:  # string types
                return str(value)
        except (ValueError, TypeError) as e:
            self.logger.warning(f"Could not convert value '{value}' to type '{data_type}': {e}")
            return value

    def reset_constraint_tracking(self):
        """Reset all constraint tracking for fresh generation"""
        self._pk_cache.clear()
        self._fk_pools.clear()
        self._unique_constraints.clear()
        self._generated_data.clear()
        self.logger.info("Constraint tracking cache reset")

    def _refresh_fk_pools(self, table_name: str = None):
        """Efficiently refresh foreign key pools from DataFrame storage"""
        tables_to_refresh = [table_name] if table_name else list(self._generated_data.keys())

        for table in tables_to_refresh:
            if table not in self._generated_data:
                continue

            df = self._generated_data[table]
            if df.empty:
                continue

            # Get primary key columns for this table
            table_metadata = self._get_table_metadata(table)
            if not table_metadata:
                continue

            pk_columns = self._get_primary_key_columns(table_metadata)

            # Update FK pools for each PK column
            for pk_col in pk_columns:
                if pk_col in df.columns:
                    fk_key = f"{table}.{pk_col}"
                    # Use pandas for efficient unique value extraction
                    unique_values = df[pk_col].dropna().unique().tolist()
                    self._fk_pools[fk_key] = unique_values
                    self.logger.debug(f"Refreshed FK pool {fk_key} with {len(unique_values)} values")

    def _get_table_metadata(self, table_name: str) -> Dict:
        """Get table metadata from config"""
        if isinstance(self.config, dict) and 'tables' in self.config:
            for table in self.config['tables']:
                if table.get('table_name') == table_name:
                    return table
        return {}

    def _get_primary_key_columns(self, table_metadata: Dict) -> List[str]:
        """Get primary key columns from table metadata"""
        # Check for composite primary key first
        composite_pk = table_metadata.get("composite_primary_key", [])
        if composite_pk:
            return composite_pk

        # Look for individual primary key columns
        pk_columns = []
        for column in table_metadata.get("columns", []):
            constraints = column.get("constraints", [])
            constraint = column.get("constraint", [])  # Alternative field name

            if "PK" in constraints or "PK" in constraint:
                pk_columns.append(column["name"])

        return pk_columns

    def _get_fk_values_optimized(self, parent_table: str, parent_column: str,
                                 expected_data_type: str = None, sample_size: int = None) -> List[Any]:
        """Optimized foreign key value retrieval with sampling"""
        fk_key = f"{parent_table}.{parent_column}"

        # Check if we have cached values
        if fk_key in self._fk_pools and len(self._fk_pools[fk_key]) > 0:
            available_values = self._fk_pools[fk_key]
        else:
            # Refresh from DataFrame if available
            if parent_table in self._generated_data:
                df = self._generated_data[parent_table]
                if not df.empty and parent_column in df.columns:
                    unique_values = df[parent_column].dropna().unique().tolist()
                    self._fk_pools[fk_key] = unique_values
                    available_values = unique_values
                else:
                    return []
            else:
                return []

        # Convert to expected data type if specified
        if expected_data_type:
            converted_values = []
            for value in available_values:
                converted_val = self._convert_value_to_type(str(value), expected_data_type)
                converted_values.append(converted_val)
            available_values = converted_values

        # Sample if too many values (for performance)
        if sample_size and len(available_values) > sample_size:
            available_values = random.sample(available_values, sample_size)

        self.logger.debug(f"Retrieved {len(available_values)} FK values from {parent_table}.{parent_column}")
        return available_values

    def _is_unique_value_used(self, table_name: str, column_name: str, value: Any) -> bool:
        """Check if unique constraint value is already used"""
        constraint_key = f"{table_name}.{column_name}"
        return value in self._unique_constraints.get(constraint_key, set())

    def _add_unique_value(self, table_name: str, column_name: str, value: Any):
        """Add value to unique constraint tracking"""
        constraint_key = f"{table_name}.{column_name}"
        if len(self._unique_constraints[constraint_key]) < self._cache_size_limit:
            self._unique_constraints[constraint_key].add(value)

    def generate_value_with_distribution(self, rule, data_type):
        """Generate value considering probability distributions"""
        if isinstance(rule, dict) and rule.get("type") == "choice":
            choices = rule.get("value", [])
            probabilities = rule.get("probabilities", {})
            if probabilities:
                # Use weighted random selection
                weights = [probabilities.get(choice, 1.0) for choice in choices]
                return random.choices(choices, weights=weights, k=1)[0]
            else:
                return random.choice(choices)

        return self.generate_value(rule, data_type)

    def generate_value(self, rule, data_type):
        """Enhanced value generation with better rule handling"""
        if isinstance(rule, str):
            cleaned_rule = rule.replace(" ", "").replace("_", "").lower()
            mapped_data = {
                "bool": random.choice([True, False]),
                "uuid": self.faker.uuid4(),
                "cc": self.faker.credit_card_number(),
                "cc_cvv": self.faker.credit_card_security_code(),
                "cc_expiry_date": self.faker.credit_card_expire(),
                "phone": self.faker.phone_number(),
                "phonenumber": self.faker.phone_number(),
                "phoneno": self.faker.phone_number(),
                "firstname": self.faker.first_name(),
                "lastname": self.faker.last_name(),
                "timestamp": self.faker.date_time().strftime("%Y-%m-%d %H:%M:%S"),
            }
            try:
                faker_dict = {x.replace("_", ""): x for x in dir(self.faker) if not x.startswith("_")}
                faker_dict.update({''.join([y[0] for y in x.split('_')]): x for x in dir(self.faker) if
                                   '_' in x and not x.startswith('_')})
                if rule in faker_dict:
                    rule = faker_dict.get(rule, faker_dict.get(cleaned_rule))
                    return getattr(self.faker, rule)()
                else:
                    return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))
            except AttributeError:
                self.logger.warning(f"Faker does not support {rule}. Checking in mapped data")
                return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))

        elif isinstance(rule, dict):
            rule_type = rule.get("type")
            rule_regex = rule.get("regex")
            data = None

            if rule_type is not None:
                if rule_type == "choice":
                    return self.generate_value_with_distribution(rule, data_type)
                elif rule_type in ["date", "date_range"]:
                    start_date = rule.get("start", "1950-01-01")
                    end_date = rule.get("end", datetime.now().strftime("%Y-%m-%d"))
                    data = self.random_date(start_date, end_date)
                elif rule_type in ["time", "time_range"]:
                    start_time = rule.get("start", "00:00:00")
                    end_time = rule.get("end", "23:59:59")
                    start_dt = datetime.strptime(f"1970-01-01 {start_time}", "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(f"1970-01-01 {end_time}", "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%H:%M:%S")
                elif rule_type in ["timestamp", "timestamp_range"]:
                    start_ts = rule.get("start", "2000-01-01 00:00:00")
                    end_ts = rule.get("end", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    start_dt = datetime.strptime(start_ts, "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(end_ts, "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%Y-%m-%d %H:%M:%S")
                elif rule_type == "range":
                    min_val = rule.get("min", 0)
                    max_val = rule.get("max", 10000)
                    if data_type == "int":
                        data = random.randint(int(min_val), int(max_val))
                    elif data_type == "float":
                        data = round(random.uniform(min_val, max_val), 2)
                elif rule_type in ["fixed", "default"]:
                    data = rule.get("value")
                elif rule_type == "email":
                    data = self.faker.email()
                elif rule_type == "phone_number":
                    data = self.faker.phone_number()
                else:
                    data = self.generate_value(rule_type, data_type)

            # Validate against regex if provided
            if rule_regex is not None and data is not None:
                max_attempts = 10
                attempts = 0
                while not self.validator.regex_validator(rule_regex, str(data)) and attempts < max_attempts:
                    if rule_type == "email":
                        data = self.faker.email()
                    elif rule_type == "phone_number":
                        data = self.generate_phone_matching_regex(rule_regex)
                    else:
                        data = self.generate_value(rule_type, data_type)
                    attempts += 1

            return data
        return None

    def random_date(self, start, end):
        """Generate random date between start and end"""
        start = datetime.strptime(start, "%Y-%m-%d")
        end = datetime.strptime(end, "%Y-%m-%d")
        delta = end - start
        return (start + timedelta(days=random.randint(0, delta.days))).date()

    def generate_phone_matching_regex(self, regex_pattern):
        """Generate phone number that matches the given regex pattern"""
        if "10,15" in regex_pattern:
            length = random.randint(10, 15)
            return ''.join([str(random.randint(0, 9)) for _ in range(length)])
        return self.faker.phone_number()

    def handle_conditions(self, conditions, row):
        """Enhanced condition handling with better operator support"""
        for condition in conditions:
            column = condition["column"]
            operator = condition["operator"].replace(" ", "").replace("_", "").lower()

            if column not in row:
                return False

            row_value = row[column]
            if row_value is None:
                return False

            if operator in ["equals", "=", "eq"]:
                if row_value != condition["value"]:
                    return False
            elif operator in ["notequals", "!=", "ne"]:
                if row_value == condition["value"]:
                    return False
            elif operator in ["less", "<", "lessthan", "lt"]:
                if row_value >= condition["value"]:
                    return False
            elif operator in ["lessequal", "<=", "le"]:
                if row_value > condition["value"]:
                    return False
            elif operator in ["greater", ">", "greaterthan", "gt"]:
                if row_value <= condition["value"]:
                    return False
            elif operator in ["greaterequal", ">=", "ge"]:
                if row_value < condition["value"]:
                    return False
            elif operator in ["between", "range"]:
                min_val = condition.get("min", condition.get("start"))
                max_val = condition.get("max", condition.get("end"))
                if not (min_val <= row_value <= max_val):
                    return False
            elif operator in ["in", "contains"]:
                if row_value not in condition.get("values", []):
                    return False
            elif operator in ["notin", "notcontains"]:
                if row_value in condition.get("values", []):
                    return False
        return True

    def generate_unique_value(self, column_def, table_name, max_attempts=100):
        """Generate unique value for columns with unique constraints"""
        column_name = column_def["name"]
        data_type = column_def["type"]
        rule = column_def.get("rule", {})

        for attempt in range(max_attempts):
            value = self.generate_value(rule, data_type) if rule else self._generate_default_value(data_type)

            if not self._is_unique_value_used(table_name, column_name, value):
                self._add_unique_value(table_name, column_name, value)
                return value

        # Fallback: append attempt number to ensure uniqueness
        base_value = str(value) if value else "unique"
        return f"{base_value}_{random.randint(10000, 99999)}"

    def _generate_default_value(self, data_type):
        """Generate default value based on data type"""
        if data_type == "int":
            return random.randint(1, 100000)
        elif data_type == "float":
            return round(random.uniform(1.0, 100.0), 2)
        elif data_type == "bool":
            return random.choice([True, False])
        elif data_type == "date":
            return self.faker.date_between(start_date="-5y", end_date="today")
        elif data_type == "str":
            return self.faker.text(max_nb_chars=50)
        else:
            return None

    def generate_batch_optimized(self, table_metadata, batch_size, foreign_key_data=None):
        """Optimized batch generation using vectorized operations where possible"""
        table_name = table_metadata["table_name"]
        columns = table_metadata["columns"]
        foreign_keys = table_metadata.get("foreign_keys", [])

        if foreign_key_data is None:
            foreign_key_data = {}

        batch_data = []

        # Pre-generate FK pools for this batch
        fk_pools = {}
        for fk in foreign_keys:
            child_column = fk["child_column"]
            parent_table = fk["parent_table"]
            parent_column = fk["parent_column"]

            # Get expected data type
            expected_type = self._get_column_data_type(table_metadata, child_column)

            # Get FK values with sampling for large pools
            available_values = self._get_fk_values_optimized(
                parent_table, parent_column, expected_type, sample_size=10000
            )

            # Also include provided foreign_key_data
            fk_key = f"{parent_table}.{parent_column}"
            if fk_key in foreign_key_data:
                additional_values = [
                    self._convert_value_to_type(str(val), expected_type)
                    for val in foreign_key_data[fk_key]
                ]
                available_values.extend(additional_values)

            if available_values:
                fk_pools[child_column] = available_values
            else:
                # Generate fallback values
                fallback_values = []
                for i in range(min(1000, batch_size)):
                    if expected_type == 'int':
                        fallback_values.append(random.randint(1, 1000))
                    else:
                        fallback_values.append(f"default_{i}")
                fk_pools[child_column] = fallback_values

        # Generate batch records
        for record_idx in range(batch_size):
            row = {}

            # Handle primary keys
            pk_columns = self._get_primary_key_columns(table_metadata)
            composite_columns = table_metadata.get("composite_primary_key", [])

            if composite_columns:
                # Handle composite primary key
                for i, col_name in enumerate(composite_columns):
                    col_def = next((c for c in columns if c["name"] == col_name), None)
                    if col_def and col_def["type"] == "int":
                        row[col_name] = record_idx + 1 + i
                    elif col_def and (col_def["rule"] == "uuid" or col_def["type"] == "uuid"):
                        row[col_def] = self.generate_value(col_def["rule"], col_def["type"])
                    else:
                        row[col_name] = f"{col_name}_{record_idx + 1 + i}"
            elif pk_columns:
                # Handle single primary key
                pk_col_name = pk_columns[0]
                pk_col_def = next((c for c in columns if c["name"] == pk_col_name), None)
                if pk_col_def and pk_col_def["type"] == "int":
                    row[pk_col_name] = record_idx + 1
                elif pk_col_def and (pk_col_def["rule"] == "uuid" or pk_col_def["type"] == "uuid"):
                    row[pk_col_name] = self.generate_value(pk_col_def["rule"], pk_col_def["type"])
                else:
                    row[pk_col_name] = f"{table_name}_{record_idx + 1}"

            # Handle foreign keys efficiently
            for fk in foreign_keys:
                child_column = fk["child_column"]
                if child_column in fk_pools and fk_pools[child_column]:
                    row[child_column] = random.choice(fk_pools[child_column])

            # Generate other column values
            for column in columns:
                column_name = column["name"]

                if column_name in row:
                    continue

                data_type = column["type"]
                constraints = column.get("constraints", []) + column.get("constraint", [])

                # Handle unique constraints
                if "unique" in constraints:
                    row[column_name] = self.generate_unique_value(column, table_name)
                else:
                    # Apply conditional rules
                    conditional_value = self.apply_conditional_rules(row, column)
                    if conditional_value is not None:
                        row[column_name] = conditional_value
                    else:
                        # Generate regular value
                        rule = column.get("rule")
                        if rule:
                            row[column_name] = self.generate_value_with_distribution(rule, data_type)
                        else:
                            row[column_name] = self._generate_default_value(data_type)

                # Handle nullable columns
                nullable = column.get("nullable", True)
                if nullable and random.random() < 0.1:  # 10% chance of null
                    row[column_name] = None

            batch_data.append(row)

        return batch_data

    def _get_column_data_type(self, table_metadata: Dict, column_name: str) -> str:
        """Get data type for a column from table metadata"""
        columns = table_metadata.get('columns', [])
        for col in columns:
            if col.get('name') == column_name:
                return col.get('type', 'str')
        return 'str'

    def apply_conditional_rules(self, row, column_def):
        """Apply conditional rules based on other column values"""
        conditional_rules = column_def.get("conditional_rules", [])

        for condition_rule in conditional_rules:
            when_conditions = condition_rule.get("when", [])
            then_rule = condition_rule.get("then", {}).get("rule", {})

            if self.handle_conditions(when_conditions, row):
                if isinstance(then_rule, dict) and then_rule.get("type") in ["fixed", "default"]:
                    return then_rule.get("value")
                else:
                    base_rule = column_def.get("rule", {})
                    if isinstance(base_rule, dict) and isinstance(then_rule, dict):
                        merged_rule = {**base_rule, **then_rule}
                    else:
                        merged_rule = then_rule
                    return self.generate_value_with_distribution(merged_rule, column_def["type"])

        return None

    def store_generated_batch(self, table_name: str, batch_data: List[Dict]):
        """Store generated batch in DataFrame format for efficient access"""
        if not batch_data:
            return

        # Convert to DataFrame
        df_batch = pd.DataFrame(batch_data)

        # Append to existing DataFrame or create new one
        if table_name in self._generated_data:
            self._generated_data[table_name] = pd.concat([
                self._generated_data[table_name], df_batch
            ], ignore_index=True)
        else:
            self._generated_data[table_name] = df_batch

        # Refresh FK pools periodically for large datasets
        if len(self._generated_data[table_name]) % self._batch_fk_refresh_threshold == 0:
            self._refresh_fk_pools(table_name)

        self.logger.debug(f"Stored batch of {len(batch_data)} records for {table_name}. "
                          f"Total: {len(self._generated_data[table_name])}")

    def get_generated_data_df(self, table_name: str) -> pd.DataFrame:
        """Get generated data as DataFrame"""
        return self._generated_data.get(table_name, pd.DataFrame())

    def get_generated_data_dict(self, table_name: str) -> List[Dict[str, Any]]:
        """Get generated data as list of dictionaries (for compatibility)"""
        df = self.get_generated_data_df(table_name)
        if df.empty:
            return []
        return df.to_dict('records')

    def clear_generated_data(self, table_name: str = None):
        """Clear generated data for a specific table or all tables"""
        if table_name:
            if table_name in self._generated_data:
                del self._generated_data[table_name]
        else:
            self._generated_data.clear()

    def maintain_fk_relationships_bulk(self, df_map: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
        """Efficiently maintain foreign key relationships using pandas operations"""
        # Similar to old_code.py approach but optimized
        for table_name, df in df_map.items():
            table_metadata = self._get_table_metadata(table_name)
            if not table_metadata:
                continue

            foreign_keys = table_metadata.get('foreign_keys', [])
            for fk in foreign_keys:
                parent_table = fk['parent_table']
                parent_column = fk['parent_column']
                child_column = fk['child_column']

                if parent_table in df_map and not df_map[parent_table].empty:
                    parent_df = df_map[parent_table]
                    if parent_column in parent_df.columns:
                        # Use pandas sampling for efficient FK assignment
                        available_values = parent_df[parent_column].dropna().values
                        if len(available_values) > 0:
                            df_map[table_name][child_column] = pd.Series(
                                random.choices(available_values, k=len(df))
                            )

        return df_map