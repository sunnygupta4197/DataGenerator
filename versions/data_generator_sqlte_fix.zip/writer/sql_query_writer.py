import pandas as pd

from .base_writer import BaseWriter

class SQLQueryWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, batch_size, logger=None):
        super().__init__(data, table_metadata, output_dir, 'sql', batch_size, logger)

    def write_batch(self, batch_data, sql_file):
        with open(sql_file, 'w') as file:
            values_list = []
            for _, row in batch_data.iterrows():
                values = ', '.join(f"'{str(x).replace("'", "''")}'" if pd.notnull(x) else "NULL" for x in row)
                values_list.append(f"({values})")
            insert_stmt = f"INSERT INTO {self.table_metadata["table_name"]} ({', '.join(self.columns)}) VALUES ({', '.join(values_list)});\n"
            file.write(insert_stmt)

