import os
import logging
import pandas as pd
from reader.json_reader import JSONConfigReader
from data_generator.data_generator import DataGenerator

logging.basicConfig(level=logging.ERROR, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)


def write_data(data, table_metadata, output_dir, output_format, chunk_id):
    logger.info(f'Writing data in chunk {chunk_id} in parquet format')
    df = pd.DataFrame(data)
    filename = f"{table_metadata["table_name"]}_part{chunk_id}.{output_format}"
    path = os.path.join(output_dir, filename)
    logger.info(f'Writing data to {path}')
    if output_format == "csv":
        df.to_csv(path, index=False)
    elif output_format == "parquet":
        df.to_parquet(path, index=False)
    logger.info(f"Chunk {chunk_id} written to {path} with {len(data)} records")


def generate_data_and_save(table_metadata, total_records, foreign_key_data, output_dir, output_format, chunk_size=100000):
    buffer = []
    chunk_id = 1
    data_generator = DataGenerator(config)
    for index, row in enumerate(data_generator.generate_row(table_metadata, total_records, foreign_key_data), 1):
        buffer.append(row)
        if index % chunk_size == 0:
            write_data(buffer, table_metadata, output_dir, output_format, chunk_id)
            chunk_id += 1
            buffer = []

    if buffer:
        write_data(buffer, table_metadata, output_dir, output_format, chunk_id)
    

def main(config, total_records=None, output_dir=None, chunk_size=100):
    os.makedirs(output_dir, exist_ok=True)

    all_foreign_key_data = {}
    for table_metadata in config["tables"]:
        foreign_key_data = {}
        if "foreign_keys" in table_metadata:
            for foreign_key in table_metadata["foreign_keys"]:
                parent_table = foreign_key["parent_table"]
                parent_column = foreign_key["parent_column"]
                foreign_key_data[foreign_key["child_column"]] = all_foreign_key_data.get(parent_table, {}).get(
                    parent_column, [])

        total_records = config.get("total_records", total_records)

        print(f"Generating data for {table_metadata['table_name']} with {total_records} records")
        generate_data_and_save(table_metadata, total_records, foreign_key_data, output_dir, config.get('output_format', 'csv'), chunk_size)
        primary_key_columns = [column["name"] for column in table_metadata["columns"] if "PK" in column.get("constraints", [])]
        composite_primary_key = table_metadata.get("composite_primary_key", [])
        primary_key_columns = composite_primary_key if composite_primary_key else primary_key_columns

        all_foreign_key_data[table_metadata["table_name"]] = {}
        for primary_key_column in primary_key_columns:
            all_foreign_key_data[table_metadata["table_name"]][primary_key_column] = list(range(1, total_records + 1))

if __name__ == "__main__":
    config_file = "config2.json"
    config = JSONConfigReader(config_file).load_config()
    output_dir = './output'
    main(config, total_records=config.get("row_count", 100), output_dir=output_dir)