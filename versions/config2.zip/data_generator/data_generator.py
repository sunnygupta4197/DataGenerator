import random
from faker import Faker
from datetime import datetime, timedelta
import logging

from .validator import DataValidator


class DataGenerator:
    def __init__(self, config, logger=None):
        self.config = config
        self.logger = logger
        if self.logger is None:
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
            self.logger = logging.getLogger()
        self.faker = Faker()
        self.validator = DataValidator()

    def random_date(self, start, end):
        start = datetime.strptime(start, "%Y-%m-%d")
        end = datetime.strptime(end, "%Y-%m-%d")
        delta = end - start
        return (start + (timedelta(days=random.randint(0, delta.days)))).date()

    def generate_value(self, rule, data_type):
        if isinstance(rule, str):
            cleaned_rule = rule.replace(" ", "").replace("_", "").lower()
            mapped_data = {
                "bool": random.choice([True, False]),
                "uuid": self.faker.uuid4(),
                "cc": self.faker.credit_card_number(),
                "cc_cvv": self.faker.credit_card_security_code(),
                "cc_expiry_date": self.faker.credit_card_expire(),
                "zip": self.faker.zipcode(),
                "phone": self.faker.phone_number(),
                "phonenumber": self.faker.phone_number(),
                "phoneno": self.faker.phone_number(),
                "firstname": self.faker.first_name(),
                "lastname": self.faker.last_name(),
            }
            try:
                return getattr(self.faker, rule)()
            except AttributeError:
                self.logger.warning(f"Faker does not support {rule}. Checking in mapped data")
                return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))
        elif isinstance(rule, dict):
            rule_type = rule.get("type")
            rule_regex = rule.get("regex")
            data  = None
            if rule_type is not None:
                data = self.generate_value(rule_type, data_type)
                if data is None:
                    if rule_type in ["date", "date_range"]:
                        data = self.random_date(rule["start"], rule.get("end", datetime.now().strftime("%Y-%m-%d")))
                    if rule_type == "range":
                        min_val = rule.get("min", 0)
                        max_val = rule.get("max", 10000)
                        data = random.randint(int(min_val), int(max_val)) if data_type == "int" else round(random.uniform(min_val, max_val), 2)
                    if rule_type in ["fixed", "default"]:
                        data = rule["value"]
                    if rule_type == "choice":
                        data = random.choice(rule["value"])
            if rule_regex is not None and data is not None:
                while not self.validator.regex_validator(rule_regex, data):
                    data = self.generate_value(rule_type, data_type)
            return data
        return None

    def handle_conditions(self, conditions, row):
        self.logger.info("Handling conditions")
        for condition in conditions:
            column = condition["column"]
            operator = condition["operator"].replace(" ", "").replace("_", "").lower()
            if operator in ["equals", "=", "eq"]:
                if row[column] != condition["value"]:
                    return False
            elif operator in ["less", "<", "lessthen", "lt"]:
                if row[column] >= condition["value"]:
                    return False
            elif operator in ["greater", ">", "greaterthen", "gt"]:
                if row[column] <= condition["value"]:
                    return False
            elif operator in ["between", "range"]:
                if not (condition["min"] < row[column] <= condition["max"]):
                    return False
        return True

    def generate_row(self, table_metadata, record_count, constraints={}):
        columns = table_metadata["columns"]
        composite_columns = table_metadata.get("composite_columns", [])

        while record_count > 0:
            row = {}

            for column in columns:
                name = column["name"]
                data_type = column["type"]
                null_value = column.get("nullable", True)
                conditional_rule = column.get("conditional_rules", [])
                applied_condition = False
                rule = column.get("rule")

                for condition in conditional_rule:
                    if self.handle_conditions(condition["when"], row):
                        then_rule = condition["then"]["rule"]
                        if isinstance(then_rule, dict) and then_rule["type"] in ["fixed", "default"]:
                            row[name] = then_rule["value"]
                        else:
                            for key in rule:
                                then_rule.setdefault(key, rule[key])
                            row[name] = self.generate_value(then_rule, data_type)
                        applied_condition = True
                if applied_condition:
                    continue

                if rule:
                    row[name] = self.generate_value(rule, data_type)
                else:
                    if data_type == "int":
                        row[name] = random.randint(1, 100)
                    elif data_type == "float":
                        row[name] = round(random.uniform(1, 100), 2)
                    elif data_type == "bool":
                        row[name] = random.choice([True, False])
                    elif data_type == "date":
                        self.faker.date_time_between()
                        row[name] = self.faker.date_between(start_date="-5y", end_date="today")
                    elif data_type == "str":
                        row[name] = self.faker.text(max_nb_chars=100)
                    else:
                        row[name] = None
            record_count -= 1
            yield row
