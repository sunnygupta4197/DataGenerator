import os
import pandas as pd

from base_writer import BaseWriter

class CSVWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, output_format, chunk_id, logger=None):
        super().__init__(data, table_metadata, output_dir, output_format, chunk_id, logger)

    def write_data(self):
        self.logger.info(f'Writing data in chunk {self.chunk_id} in parquet format')
        df = pd.DataFrame(self.data)
        path = self._prepare_file_name("parquet")
        df.to_parquet(path, index=False) # , row_group_size=5 * 10**6)
        self.logger.info(f"Chunk {self.chunk_id} written to {path} with {len(self.data)} records")
