from .base_writer import BaseWriter

class CSVWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, batch_size, logger=None):
        super().__init__(data, table_metadata, output_dir, 'csv', batch_size, logger)

    def write_batch(self, batch_data, file_name):
        batch_data.to_csv(file_name, index=False, sep=",", na_rep="NaN")
