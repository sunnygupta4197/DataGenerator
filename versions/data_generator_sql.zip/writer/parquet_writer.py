from .base_writer import BaseWriter

class ParquetWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, batch_size, logger=None):
        super().__init__(data, table_metadata, output_dir, 'parquet', batch_size, logger)

    def write_batch(self, batch_data, file_name):
        batch_data.to_parquet(file_name, index=False)

