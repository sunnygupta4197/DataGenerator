import sqlite3
import json
import re
from typing import Dict, List, Any, Optional, Union
from datetime import datetime, date, timedelta
import logging
import random
import string
from faker import Faker
import os


class JSONSchemaToSQLite:
    def __init__(self, db_path: str = "data_generator.db", enable_logging: bool = True):
        self.db_path = db_path
        self.connection = None
        self.enable_logging = enable_logging
        self.fake = Faker()

        # Enhanced type mapping for any possible schema
        self.type_mapping = {
            "int": "INTEGER", "integer": "INTEGER", "number": "INTEGER",
            "string": "TEXT", "str": "TEXT", "text": "TEXT", "varchar": "TEXT",
            "float": "REAL", "real": "REAL", "double": "REAL", "decimal": "REAL",
            "date": "TEXT", "datetime": "TEXT", "timestamp": "TEXT", "time": "TEXT",
            "bool": "TEXT", "boolean": "TEXT",
            "blob": "BLOB", "binary": "BLOB",
            "json": "TEXT", "object": "TEXT", "array": "TEXT"
        }

        if enable_logging:
            logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
            self.logger = logging.getLogger(__name__)

    def connect(self):
        """Establish connection to SQLite database"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.execute("PRAGMA foreign_keys = ON")
            self.connection.execute("PRAGMA journal_mode = WAL")
            if self.enable_logging:
                self.logger.info(f"Connected to database: {self.db_path}")
            return self.connection
        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Failed to connect to database: {e}")
            raise

    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            if self.enable_logging:
                self.logger.info("Database connection closed")

    def process_schema_file(self, schema_file_path: str) -> bool:
        """Process a JSON schema file and create all tables"""
        try:
            with open(schema_file_path, 'r') as file:
                schema_data = json.load(file)

            return self.process_schema(schema_data)

        except FileNotFoundError:
            if self.enable_logging:
                self.logger.error(f"Schema file not found: {schema_file_path}")
            return False
        except json.JSONDecodeError as e:
            if self.enable_logging:
                self.logger.error(f"Invalid JSON in schema file: {e}")
            return False

    def process_schema(self, schema_data: Dict[str, Any]) -> bool:
        """Process schema data and create all tables dynamically"""
        if not self.connection:
            self.connect()

        try:
            # Handle different schema formats
            tables = self._extract_tables(schema_data)

            if not tables:
                if self.enable_logging:
                    self.logger.warning("No tables found in schema")
                return False

            # Create tables in dependency order
            creation_order = self._determine_creation_order(tables)
            results = {}

            for table_name in creation_order:
                table_schema = next(t for t in tables if t.get("table_name") == table_name)
                success = self.create_table_from_schema(table_schema)
                results[table_name] = success

                if not success:
                    if self.enable_logging:
                        self.logger.error(f"Failed to create table: {table_name}")

            if self.enable_logging:
                success_count = sum(1 for success in results.values() if success)
                self.logger.info(f"Created {success_count}/{len(results)} tables successfully")

            return all(results.values())

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error processing schema: {e}")
            return False

    def _extract_tables(self, schema_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract table definitions from various schema formats"""
        tables = []

        # Format 1: {"tables": [...]}
        if "tables" in schema_data:
            tables = schema_data["tables"]

        # Format 2: {"table_name": "...", "columns": [...]}
        elif "table_name" in schema_data and "columns" in schema_data:
            tables = [schema_data]

        # Format 3: Multiple tables as top-level keys
        elif all(isinstance(v, dict) and ("columns" in v or "fields" in v) for v in schema_data.values()):
            for table_name, table_config in schema_data.items():
                table_config["table_name"] = table_name
                tables.append(table_config)

        # Format 4: Array of table definitions
        elif isinstance(schema_data, list):
            tables = schema_data

        return tables

    def _determine_creation_order(self, tables: List[Dict[str, Any]]) -> List[str]:
        """Determine table creation order based on foreign key dependencies"""
        table_names = [t.get("table_name") for t in tables]
        dependencies = {}

        # Build dependency graph
        for table in tables:
            table_name = table.get("table_name")
            dependencies[table_name] = set()

            # Check foreign keys
            foreign_keys = table.get("foreign_keys", [])
            for fk in foreign_keys:
                parent_table = fk.get("parent_table")
                if parent_table and parent_table in table_names:
                    dependencies[table_name].add(parent_table)

        # Topological sort
        ordered = []
        visited = set()
        temp_visited = set()

        def visit(table_name):
            if table_name in temp_visited:
                # Circular dependency - just add it
                return
            if table_name in visited:
                return

            temp_visited.add(table_name)
            for dependency in dependencies.get(table_name, set()):
                visit(dependency)
            temp_visited.remove(table_name)
            visited.add(table_name)
            ordered.append(table_name)

        for table_name in table_names:
            if table_name not in visited:
                visit(table_name)

        return ordered

    def create_table_from_schema(self, schema: Dict[str, Any]) -> bool:
        """Create SQLite table from any JSON schema format"""
        if not self.connection:
            self.connect()

        try:
            table_name = schema.get("table_name")
            if not table_name:
                raise ValueError("Table name is required in schema")

            # Build CREATE TABLE statement
            create_sql = self._build_create_table_sql(schema)

            if self.enable_logging:
                self.logger.info(f"Creating table: {table_name}")
                self.logger.debug(f"SQL: {create_sql}")

            # Execute table creation
            self.connection.execute(create_sql)

            # Create indexes
            self._create_dynamic_indexes(schema)

            self.connection.commit()
            if self.enable_logging:
                self.logger.info(f"Table '{table_name}' created successfully!")
            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error creating table {schema.get('table_name', 'unknown')}: {e}")
            if self.connection:
                self.connection.rollback()
            return False

    def _build_create_table_sql(self, schema: Dict[str, Any]) -> str:
        """Build CREATE TABLE SQL for any schema format"""
        table_name = schema["table_name"]

        # Handle different column formats
        columns = self._extract_columns(schema)

        column_definitions = []
        primary_keys = []

        # Process each column
        for column in columns:
            col_def, is_pk = self._build_dynamic_column_definition(column)
            column_definitions.append(col_def)

            if is_pk:
                primary_keys.append(column.get("name") or column.get("field") or column.get("column_name"))

        # Add primary key constraint if found
        if primary_keys:
            pk_constraint = f"PRIMARY KEY ({', '.join(primary_keys)})"
            column_definitions.append(pk_constraint)
        elif "primary_key" in schema:
            # Handle explicit primary key definition
            pk_cols = schema["primary_key"]
            if isinstance(pk_cols, list):
                pk_constraint = f"PRIMARY KEY ({', '.join(pk_cols)})"
            else:
                pk_constraint = f"PRIMARY KEY ({pk_cols})"
            column_definitions.append(pk_constraint)

        # Add foreign key constraints
        if "foreign_keys" in schema:
            for fk in schema["foreign_keys"]:
                try:
                    fk_constraint = self._build_foreign_key_constraint(fk)
                    column_definitions.append(fk_constraint)
                except Exception as e:
                    if self.enable_logging:
                        self.logger.warning(f"Skipping invalid foreign key: {e}")

        # Add unique constraints
        if "unique_constraints" in schema:
            for unique_cols in schema["unique_constraints"]:
                if isinstance(unique_cols, list):
                    unique_constraint = f"UNIQUE ({', '.join(unique_cols)})"
                else:
                    unique_constraint = f"UNIQUE ({unique_cols})"
                column_definitions.append(unique_constraint)

        # Build final SQL
        sql = f"CREATE TABLE IF NOT EXISTS {table_name} (\n"
        sql += ",\n".join(f"    {col_def}" for col_def in column_definitions)
        sql += "\n)"

        return sql

    def _extract_columns(self, schema: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract column definitions from various schema formats"""
        # Format 1: "columns" as list
        if "columns" in schema and isinstance(schema["columns"], list):
            return schema["columns"]

        # Format 2: "columns" as dict
        elif "columns" in schema and isinstance(schema["columns"], dict):
            columns = []
            for col_name, col_config in schema["columns"].items():
                if isinstance(col_config, dict):
                    col_config["name"] = col_name
                    columns.append(col_config)
                else:
                    # Simple type definition
                    columns.append({"name": col_name, "type": str(col_config)})
            return columns

        # Format 3: "fields"
        elif "fields" in schema:
            return schema["fields"]

        # Format 4: Direct column definitions
        elif "properties" in schema:
            columns = []
            for col_name, col_config in schema["properties"].items():
                col_config["name"] = col_name
                columns.append(col_config)
            return columns

        return []

    def _build_dynamic_column_definition(self, column: Dict[str, Any]) -> tuple:
        """Build column definition for any column format"""
        # Get column name from various possible keys
        col_name = column.get("name") or column.get("field") or column.get("column_name") or column.get("key")
        if not col_name:
            raise ValueError("Column name is required")

        # Get column type
        col_type = (column.get("type") or column.get("data_type") or
                    column.get("datatype") or "string").lower()

        sql_type = self.type_mapping.get(col_type, "TEXT")
        definition = f"{col_name} {sql_type}"

        is_primary_key = False

        # Handle constraints
        constraints = column.get("constraint", column.get("constraints", []))
        if isinstance(constraints, str):
            constraints = [constraints]

        # Check for primary key
        if ("PK" in constraints or "PRIMARY KEY" in constraints or
                column.get("primary_key", False) or column.get("is_primary", False)):
            is_primary_key = True

        # Handle nullability
        nullable = column.get("nullable", column.get("null", column.get("allow_null", True)))
        required = column.get("required", column.get("not_null", False))

        if not nullable or required:
            definition += " NOT NULL"

        # Handle default values
        default_value = column.get("default", column.get("default_value"))
        if default_value is not None:
            if isinstance(default_value, str) and col_type not in ["int", "integer", "float", "real", "number"]:
                definition += f" DEFAULT '{default_value}'"
            else:
                definition += f" DEFAULT {default_value}"

        # Handle various constraint types
        rule = column.get("rule", column.get("validation", column.get("constraints")))
        if rule:
            constraint_sql = self._build_constraint_sql(col_name, rule, col_type)
            if constraint_sql:
                definition += f" {constraint_sql}"

        return definition, is_primary_key

    def _build_constraint_sql(self, col_name: str, rule: Any, col_type: str) -> str:
        """Build constraint SQL from rule definition"""
        if isinstance(rule, dict):
            rule_type = rule.get("type", "").lower()

            # Range constraints
            if rule_type == "range" or "min" in rule or "max" in rule:
                constraints = []
                if "min" in rule:
                    constraints.append(f"{col_name} >= {rule['min']}")
                if "max" in rule:
                    constraints.append(f"{col_name} <= {rule['max']}")
                if constraints:
                    return f"CHECK ({' AND '.join(constraints)})"

            # Choice constraints
            elif rule_type == "choice" or "values" in rule or "value" in rule:
                choices = rule.get("value", rule.get("values", rule.get("choices", [])))
                if choices:
                    if all(isinstance(choice, str) for choice in choices):
                        choice_list = "', '".join(choices)
                        return f"CHECK ({col_name} IN ('{choice_list}'))"
                    else:
                        choice_list = ", ".join(str(choice) for choice in choices)
                        return f"CHECK ({col_name} IN ({choice_list}))"

            # Length constraints
            elif rule_type == "length" or "min_length" in rule or "max_length" in rule:
                constraints = []
                if "min_length" in rule:
                    constraints.append(f"LENGTH({col_name}) >= {rule['min_length']}")
                if "max_length" in rule:
                    constraints.append(f"LENGTH({col_name}) <= {rule['max_length']}")
                if "length" in rule:
                    constraints.append(f"LENGTH({col_name}) = {rule['length']}")
                if constraints:
                    return f"CHECK ({' AND '.join(constraints)})"

            # Pattern constraints (basic)
            elif rule_type == "pattern" or "regex" in rule:
                # SQLite doesn't support regex in CHECK, so we'll skip this
                pass

        return ""

    def _build_foreign_key_constraint(self, fk_config: Dict[str, Any]) -> str:
        """Build foreign key constraint from various formats"""
        # Try different key names for foreign key components
        child_column = (fk_config.get("child_column") or fk_config.get("column") or
                        fk_config.get("from") or fk_config.get("source_column"))
        parent_table = (fk_config.get("parent_table") or fk_config.get("table") or
                        fk_config.get("references") or fk_config.get("target_table"))
        parent_column = (fk_config.get("parent_column") or fk_config.get("to") or
                         fk_config.get("target_column") or fk_config.get("referenced_column"))

        if not all([child_column, parent_table, parent_column]):
            raise ValueError("Foreign key configuration incomplete")

        constraint = f"FOREIGN KEY ({child_column}) REFERENCES {parent_table}({parent_column})"

        # Add ON DELETE and ON UPDATE actions if specified
        if "on_delete" in fk_config:
            constraint += f" ON DELETE {fk_config['on_delete']}"
        if "on_update" in fk_config:
            constraint += f" ON UPDATE {fk_config['on_update']}"

        return constraint

    def _create_dynamic_indexes(self, schema: Dict[str, Any]):
        """Create indexes based on schema analysis"""
        table_name = schema["table_name"]
        columns = self._extract_columns(schema)

        # Create indexes on foreign key columns
        if "foreign_keys" in schema:
            for fk in schema["foreign_keys"]:
                col_name = (fk.get("child_column") or fk.get("column") or
                            fk.get("from") or fk.get("source_column"))
                if col_name:
                    self._create_index(table_name, col_name, "fk")

        # Create indexes on commonly indexed fields
        index_patterns = ["id", "email", "phone", "username", "code", "status", "created_at", "updated_at"]

        for column in columns:
            col_name = column.get("name") or column.get("field") or column.get("column_name")
            if col_name:
                col_name_lower = col_name.lower()

                # Check if column matches common index patterns
                for pattern in index_patterns:
                    if pattern in col_name_lower:
                        self._create_index(table_name, col_name, pattern)
                        break

                # Create index if explicitly requested
                if column.get("index", False) or column.get("create_index", False):
                    self._create_index(table_name, col_name, "explicit")

        # Create composite indexes if specified
        if "indexes" in schema:
            for index_config in schema["indexes"]:
                if isinstance(index_config, dict):
                    index_name = index_config.get("name", f"idx_{table_name}_composite")
                    columns_list = index_config.get("columns", [])
                    if columns_list:
                        self._create_composite_index(table_name, columns_list, index_name)
                elif isinstance(index_config, list):
                    # Simple list of columns
                    index_name = f"idx_{table_name}_{'_'.join(index_config)}"
                    self._create_composite_index(table_name, index_config, index_name)

    def _create_index(self, table_name: str, column_name: str, index_type: str):
        """Create a single-column index"""
        try:
            index_name = f"idx_{table_name}_{column_name}_{index_type}"
            sql = f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({column_name})"
            self.connection.execute(sql)

            if self.enable_logging:
                self.logger.debug(f"Created index: {index_name}")
        except Exception as e:
            if self.enable_logging:
                self.logger.warning(f"Failed to create index on {table_name}.{column_name}: {e}")

    def _create_composite_index(self, table_name: str, columns: List[str], index_name: str):
        """Create a composite index on multiple columns"""
        try:
            columns_str = ", ".join(columns)
            sql = f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns_str})"
            self.connection.execute(sql)

            if self.enable_logging:
                self.logger.debug(f"Created composite index: {index_name}")
        except Exception as e:
            if self.enable_logging:
                self.logger.warning(f"Failed to create composite index {index_name}: {e}")

    def analyze_schema(self, schema_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a schema and return detailed information"""
        tables = self._extract_tables(schema_data)

        analysis = {
            "total_tables": len(tables),
            "tables": {},
            "relationships": [],
            "indexes": [],
            "constraints": []
        }

        for table in tables:
            table_name = table.get("table_name")
            columns = self._extract_columns(table)

            table_analysis = {
                "name": table_name,
                "total_columns": len(columns),
                "columns": [],
                "primary_keys": [],
                "foreign_keys": [],
                "unique_constraints": [],
                "check_constraints": []
            }

            # Analyze columns
            for column in columns:
                col_name = column.get("name") or column.get("field") or column.get("column_name")
                col_type = column.get("type", "string")

                col_analysis = {
                    "name": col_name,
                    "type": col_type,
                    "sql_type": self.type_mapping.get(col_type.lower(), "TEXT"),
                    "nullable": column.get("nullable", True),
                    "has_default": "default" in column or "default_value" in column,
                    "is_primary_key": column.get("primary_key", False),
                    "has_constraints": bool(column.get("rule") or column.get("validation"))
                }

                table_analysis["columns"].append(col_analysis)

                if col_analysis["is_primary_key"]:
                    table_analysis["primary_keys"].append(col_name)

            # Analyze foreign keys
            if "foreign_keys" in table:
                for fk in table["foreign_keys"]:
                    fk_analysis = {
                        "child_table": table_name,
                        "child_column": fk.get("child_column") or fk.get("column"),
                        "parent_table": fk.get("parent_table") or fk.get("table"),
                        "parent_column": fk.get("parent_column") or fk.get("to")
                    }
                    table_analysis["foreign_keys"].append(fk_analysis)
                    analysis["relationships"].append(fk_analysis)

            analysis["tables"][table_name] = table_analysis

        return analysis

    def export_schema_to_json(self, output_file: str = "exported_schema.json") -> bool:
        """Export current database schema to JSON format"""
        if not self.connection:
            self.connect()

        try:
            schema = {"tables": []}

            # Get all table names
            cursor = self.connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
            table_names = [row[0] for row in cursor.fetchall()]

            for table_name in table_names:
                table_schema = {"table_name": table_name, "columns": []}

                # Get column information
                cursor = self.connection.execute(f"PRAGMA table_info({table_name})")
                columns_info = cursor.fetchall()

                for col_info in columns_info:
                    column = {
                        "name": col_info[1],
                        "type": col_info[2],
                        "nullable": not col_info[3],
                        "default": col_info[4],
                        "primary_key": bool(col_info[5])
                    }
                    table_schema["columns"].append(column)

                # Get foreign keys
                cursor = self.connection.execute(f"PRAGMA foreign_key_list({table_name})")
                fk_info = cursor.fetchall()

                if fk_info:
                    table_schema["foreign_keys"] = []
                    for fk in fk_info:
                        foreign_key = {
                            "child_column": fk[3],
                            "parent_table": fk[2],
                            "parent_column": fk[4]
                        }
                        table_schema["foreign_keys"].append(foreign_key)

                schema["tables"].append(table_schema)

            # Write to file
            with open(output_file, 'w') as f:
                json.dump(schema, f, indent=2)

            if self.enable_logging:
                self.logger.info(f"Schema exported to {output_file}")
            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error exporting schema: {e}")
            return False

    def get_table_row_count(self, table_name):
        if not self.connection:
            self.connect()
        try:
            cursor = self.connection.execute(f"SELECT COUNT(*) FROM {table_name}")
            row_count = cursor.fetchone()[0]
            return row_count
        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error getting table row count: {e}")
            return 0

    def get_table_statistics(self, table_name: Optional[str] = None) -> Dict[str, Any]:
        """Get statistics for tables in the database"""
        if not self.connection:
            self.connect()

        try:
            stats = {}

            if table_name:
                table_names = [table_name]
            else:
                cursor = self.connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
                table_names = [row[0] for row in cursor.fetchall()]

            for tbl_name in table_names:
                # Get row count
                row_count = self.get_table_row_count(tbl_name)

                # Get column count
                cursor = self.connection.execute(f"PRAGMA table_info({tbl_name})")
                column_info = cursor.fetchall()
                column_count = len(column_info)

                # Get table size (approximate)
                size_bytes = 0
                if column_info:
                    column_names = [col[1] for col in column_info]
                    if column_names:
                        columns_concat = "|| ".join(f"COALESCE(CAST({col} AS TEXT), '')" for col in column_names)
                        cursor = self.connection.execute(f"SELECT SUM(LENGTH({columns_concat})) FROM {tbl_name}")
                        try:
                            size_bytes = cursor.fetchone()[0] or 0
                        except:
                            size_bytes = 0

                stats[tbl_name] = {
                    "row_count": row_count,
                    "column_count": column_count,
                    "estimated_size_bytes": size_bytes,
                    "estimated_size_kb": round(size_bytes / 1024, 2) if size_bytes > 0 else 0
                }

            return stats

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error getting table statistics: {e}")
            return {}

    def validate_schema(self, schema_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate a JSON schema before processing"""
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "table_count": 0,
            "column_count": 0
        }

        try:
            tables = self._extract_tables(schema_data)
            validation_result["table_count"] = len(tables)

            if not tables:
                validation_result["is_valid"] = False
                validation_result["errors"].append("No tables found in schema")
                return validation_result

            table_names = set()
            total_columns = 0

            for table in tables:
                table_name = table.get("table_name")

                # Check table name
                if not table_name:
                    validation_result["errors"].append("Table missing name")
                    validation_result["is_valid"] = False
                    continue

                if table_name in table_names:
                    validation_result["errors"].append(f"Duplicate table name: {table_name}")
                    validation_result["is_valid"] = False
                else:
                    table_names.add(table_name)

                # Check columns
                columns = self._extract_columns(table)
                if not columns:
                    validation_result["warnings"].append(f"Table {table_name} has no columns")
                    continue

                total_columns += len(columns)
                column_names = set()
                has_primary_key = False

                for column in columns:
                    col_name = column.get("name") or column.get("field") or column.get("column_name")

                    if not col_name:
                        validation_result["errors"].append(f"Column in table {table_name} missing name")
                        validation_result["is_valid"] = False
                        continue

                    if col_name in column_names:
                        validation_result["errors"].append(f"Duplicate column name in {table_name}: {col_name}")
                        validation_result["is_valid"] = False
                    else:
                        column_names.add(col_name)

                    # Check for primary key
                    if (column.get("primary_key", False) or
                            column.get("is_primary", False) or
                            "PK" in str(column.get("constraints", []))):
                        has_primary_key = True

                    # Validate column type
                    col_type = column.get("type", "string").lower()
                    if col_type not in self.type_mapping:
                        validation_result["warnings"].append(
                            f"Unknown column type '{col_type}' in {table_name}.{col_name}, will default to TEXT"
                        )

                if not has_primary_key:
                    validation_result["warnings"].append(f"Table {table_name} has no primary key")

                # Validate foreign keys
                if "foreign_keys" in table:
                    for fk in table["foreign_keys"]:
                        parent_table = fk.get("parent_table") or fk.get("table")
                        if parent_table and parent_table not in table_names:
                            validation_result["warnings"].append(
                                f"Foreign key in {table_name} references unknown table: {parent_table}"
                            )

            validation_result["column_count"] = total_columns

        except Exception as e:
            validation_result["is_valid"] = False
            validation_result["errors"].append(f"Schema validation error: {str(e)}")

        return validation_result

    def drop_table(self, table_name: str) -> bool:
        """Drop a table from the database"""
        if not self.connection:
            self.connect()

        try:
            # Check if table exists
            cursor = self.connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (table_name,)
            )
            if not cursor.fetchone():
                if self.enable_logging:
                    self.logger.warning(f"Table {table_name} does not exist")
                return False

            # Drop the table
            self.connection.execute(f"DROP TABLE {table_name}")
            self.connection.commit()

            if self.enable_logging:
                self.logger.info(f"Table {table_name} dropped successfully")
            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error dropping table {table_name}: {e}")
            return False

    def clear_table(self, table_name: str) -> bool:
        """Clear all data from a table"""
        if not self.connection:
            self.connect()

        try:
            self.connection.execute(f"DELETE FROM {table_name}")
            self.connection.commit()

            if self.enable_logging:
                self.logger.info(f"Table {table_name} cleared successfully")
            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error clearing table {table_name}: {e}")
            return False

    def backup_database(self, backup_path: str) -> bool:
        """Create a backup of the database"""
        if not self.connection:
            self.connect()

        try:
            backup_conn = sqlite3.connect(backup_path)
            self.connection.backup(backup_conn)
            backup_conn.close()

            if self.enable_logging:
                self.logger.info(f"Database backed up to {backup_path}")
            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error creating backup: {e}")
            return False

    def execute_query(self, query: str, params: Optional[tuple] = None) -> List[Dict[str, Any]]:
        """Execute a custom SQL query and return results"""
        if not self.connection:
            self.connect()

        try:
            if params:
                cursor = self.connection.execute(query, params)
            else:
                cursor = self.connection.execute(query)

            # Get column names
            columns = [description[0] for description in cursor.description] if cursor.description else []

            # Fetch results
            rows = cursor.fetchall()

            # Convert to list of dictionaries
            results = []
            for row in rows:
                results.append(dict(zip(columns, row)))

            return results

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error executing query: {e}")
            return []

    def list_tables(self) -> List[str]:
        """List all tables in the database"""
        if not self.connection:
            self.connect()

        try:
            cursor = self.connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
            return [row[0] for row in cursor.fetchall()]

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error listing tables: {e}")
            return []

    def get_table_schema(self, table_name: str) -> Dict[str, Any]:
        """Get detailed schema information for a specific table"""
        if not self.connection:
            self.connect()

        try:
            schema = {
                "table_name": table_name,
                "columns": [],
                "foreign_keys": [],
                "indexes": []
            }

            # Get column information
            cursor = self.connection.execute(f"PRAGMA table_info({table_name})")
            columns_info = cursor.fetchall()

            for col_info in columns_info:
                column = {
                    "name": col_info[1],
                    "type": col_info[2],
                    "nullable": not col_info[3],
                    "default": col_info[4],
                    "primary_key": bool(col_info[5])
                }
                schema["columns"].append(column)

            # Get foreign keys
            cursor = self.connection.execute(f"PRAGMA foreign_key_list({table_name})")
            fk_info = cursor.fetchall()

            for fk in fk_info:
                foreign_key = {
                    "child_column": fk[3],
                    "parent_table": fk[2],
                    "parent_column": fk[4],
                    "on_delete": fk[6],
                    "on_update": fk[5]
                }
                schema["foreign_keys"].append(foreign_key)

            # Get indexes
            cursor = self.connection.execute(f"PRAGMA index_list({table_name})")
            index_info = cursor.fetchall()

            for idx in index_info:
                index_detail = {
                    "name": idx[1],
                    "unique": bool(idx[2]),
                    "columns": []
                }

                # Get index columns
                cursor2 = self.connection.execute(f"PRAGMA index_info({idx[1]})")
                for col in cursor2.fetchall():
                    index_detail["columns"].append(col[2])

                schema["indexes"].append(index_detail)

            return schema

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error getting schema for table {table_name}: {e}")
            return {}

    def insert_data(self, table_name: str, data: Union[Dict[str, Any], List[Dict[str, Any]]],
                    ignore_conflicts: bool = False, update_on_conflict: bool = False) -> bool:
        """Insert single or multiple rows of data into a table

        Args:
            table_name: Name of the table to insert into
            data: Single dict or list of dicts containing the data to insert
            ignore_conflicts: If True, ignore rows that would cause conflicts
            update_on_conflict: If True, update existing rows on conflict (requires primary key)

        Returns:
            bool: True if insertion was successful, False otherwise
        """
        if not self.connection:
            self.connect()

        try:
            # Normalize data to list format
            if isinstance(data, dict):
                data_list = [data]
            elif isinstance(data, list):
                data_list = data
            else:
                raise ValueError("Data must be a dict or list of dicts")

            if not data_list:
                if self.enable_logging:
                    self.logger.warning("No data provided for insertion")
                return False

            # Get all possible columns from the data
            all_columns = set()
            for row in data_list:
                all_columns.update(row.keys())
            all_columns = list(all_columns)

            # Verify columns exist in table
            cursor = self.connection.execute(f"PRAGMA table_info({table_name})")
            table_columns = {col[1] for col in cursor.fetchall()}

            invalid_columns = [col for col in all_columns if col not in table_columns]
            if invalid_columns:
                raise ValueError(f"Invalid columns for table {table_name}: {invalid_columns}")

            # Build SQL statement
            placeholders = ", ".join(["?" for _ in all_columns])
            base_sql = f"INSERT INTO {table_name} ({', '.join(all_columns)}) VALUES ({placeholders})"

            if ignore_conflicts:
                sql = base_sql.replace("INSERT INTO", "INSERT OR IGNORE INTO")
            elif update_on_conflict:
                # Get primary key columns
                cursor = self.connection.execute(f"PRAGMA table_info({table_name})")
                pk_columns = [col[1] for col in cursor.fetchall() if col[5]]  # col[5] is pk flag

                if pk_columns:
                    update_clause = ", ".join(
                        [f"{col} = excluded.{col}" for col in all_columns if col not in pk_columns])
                    if update_clause:
                        sql = f"{base_sql} ON CONFLICT({', '.join(pk_columns)}) DO UPDATE SET {update_clause}"
                    else:
                        sql = base_sql.replace("INSERT INTO", "INSERT OR REPLACE INTO")
                else:
                    sql = base_sql.replace("INSERT INTO", "INSERT OR REPLACE INTO")
            else:
                sql = base_sql

            # Prepare data for insertion
            values_list = []
            for row in data_list:
                # Ensure all columns are present, use None for missing values
                row_values = [row.get(col) for col in all_columns]
                values_list.append(row_values)

            # Execute insertion
            if len(values_list) == 1:
                self.connection.execute(sql, values_list[0])
            else:
                self.connection.executemany(sql, values_list)

            self.connection.commit()

            if self.enable_logging:
                self.logger.info(f"Successfully inserted {len(values_list)} rows into {table_name}")

            return True

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error inserting data into {table_name}: {e}")
            if self.connection:
                self.connection.rollback()
            return False

    def bulk_insert_data(self, table_name: str, data: List[Dict[str, Any]],
                         batch_size: int = 1000, ignore_conflicts: bool = False) -> Dict[str, Any]:
        """Insert large amounts of data in batches for better performance

        Args:
            table_name: Name of the table to insert into
            data: List of dicts containing the data to insert
            batch_size: Number of rows to insert per batch
            ignore_conflicts: If True, ignore rows that would cause conflicts

        Returns:
            dict: Statistics about the insertion process
        """
        if not self.connection:
            self.connect()

        stats = {
            "total_rows": len(data),
            "successful_batches": 0,
            "failed_batches": 0,
            "total_inserted": 0,
            "errors": []
        }

        try:
            # Process data in batches
            for i in range(0, len(data), batch_size):
                batch = data[i:i + batch_size]

                try:
                    success = self.insert_data(table_name, batch, ignore_conflicts=ignore_conflicts)
                    if success:
                        stats["successful_batches"] += 1
                        stats["total_inserted"] += len(batch)
                    else:
                        stats["failed_batches"] += 1
                        stats["errors"].append(f"Batch {i // batch_size + 1} failed")
                except Exception as e:
                    stats["failed_batches"] += 1
                    stats["errors"].append(f"Batch {i // batch_size + 1}: {str(e)}")

            if self.enable_logging:
                self.logger.info(
                    f"Bulk insert completed: {stats['total_inserted']}/{stats['total_rows']} rows inserted")

            return stats

        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error in bulk insert: {e}")
            stats["errors"].append(f"Bulk insert error: {str(e)}")
            return stats

    def insert_from_csv(self, table_name: str, csv_file_path: str,
                        delimiter: str = ',', skip_header: bool = True,
                        ignore_conflicts: bool = False) -> bool:
        """Insert data from a CSV file

        Args:
            table_name: Name of the table to insert into
            csv_file_path: Path to the CSV file
            delimiter: CSV delimiter character
            skip_header: Whether to skip the first row (header)
            ignore_conflicts: If True, ignore rows that would cause conflicts

        Returns:
            bool: True if insertion was successful, False otherwise
        """
        try:
            import csv

            data_list = []

            with open(csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
                # Detect if file has header
                sample = csvfile.read(1024)
                csvfile.seek(0)
                sniffer = csv.Sniffer()
                has_header = sniffer.has_header(sample)

                reader = csv.DictReader(csvfile, delimiter=delimiter)

                if skip_header and has_header:
                    next(reader, None)  # Skip header row

                for row in reader:
                    # Convert empty strings to None for better database handling
                    cleaned_row = {k: (v if v != '' else None) for k, v in row.items()}
                    data_list.append(cleaned_row)

            if not data_list:
                if self.enable_logging:
                    self.logger.warning(f"No data found in CSV file: {csv_file_path}")
                return False

            # Use bulk insert for better performance
            stats = self.bulk_insert_data(table_name, data_list, ignore_conflicts=ignore_conflicts)

            if self.enable_logging:
                self.logger.info(f"CSV import completed: {stats['total_inserted']} rows inserted from {csv_file_path}")

            return stats["failed_batches"] == 0

        except FileNotFoundError:
            if self.enable_logging:
                self.logger.error(f"CSV file not found: {csv_file_path}")
            return False
        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error importing CSV {csv_file_path}: {e}")
            return False

    def insert_from_json(self, table_name: str, json_file_path: str,
                         ignore_conflicts: bool = False) -> bool:
        """Insert data from a JSON file

        Args:
            table_name: Name of the table to insert into
            json_file_path: Path to the JSON file
            ignore_conflicts: If True, ignore rows that would cause conflicts

        Returns:
            bool: True if insertion was successful, False otherwise
        """
        try:
            with open(json_file_path, 'r', encoding='utf-8') as jsonfile:
                json_data = json.load(jsonfile)

            # Handle different JSON formats
            if isinstance(json_data, list):
                data_list = json_data
            elif isinstance(json_data, dict):
                # Check if it's a single record or contains a data array
                if 'data' in json_data and isinstance(json_data['data'], list):
                    data_list = json_data['data']
                elif 'records' in json_data and isinstance(json_data['records'], list):
                    data_list = json_data['records']
                else:
                    data_list = [json_data]
            else:
                raise ValueError("JSON data must be an object or array")

            if not data_list:
                if self.enable_logging:
                    self.logger.warning(f"No data found in JSON file: {json_file_path}")
                return False

            # Use bulk insert for better performance
            stats = self.bulk_insert_data(table_name, data_list, ignore_conflicts=ignore_conflicts)

            if self.enable_logging:
                self.logger.info(
                    f"JSON import completed: {stats['total_inserted']} rows inserted from {json_file_path}")

            return stats["failed_batches"] == 0

        except FileNotFoundError:
            if self.enable_logging:
                self.logger.error(f"JSON file not found: {json_file_path}")
            return False
        except json.JSONDecodeError as e:
            if self.enable_logging:
                self.logger.error(f"Invalid JSON in file {json_file_path}: {e}")
            return False
        except Exception as e:
            if self.enable_logging:
                self.logger.error(f"Error importing JSON {json_file_path}: {e}")
            return False

    def __enter__(self):
        """Context manager entry"""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()

