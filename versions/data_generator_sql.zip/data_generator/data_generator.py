import random
from faker import Faker
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Any, Set, Union, Optional
from collections import defaultdict

from .validator import DataValidator


class DataGenerator:
    def __init__(self, config, locale=None, logger=None, db=None):
        self.config = config
        self.logger = logger
        self.db = db  # SQLite database connection
        self.cursor = self.db.connect()

        if self.logger is None:
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
            self.logger = logging.getLogger()

        self.faker = None
        if locale is not None:
            self.faker = Faker(locale=locale)
        else:
            self.faker = Faker()
        self.validator = DataValidator(logger=self.logger)

        # Initialize constraint tracking tables in SQLite
        self._init_constraint_tables()

        # Keep small in-memory caches for performance
        self._pk_cache = defaultdict(set)
        self._fk_cache = defaultdict(list)
        self._cache_size_limit = 10000  # Limit cache size

    def _init_constraint_tables(self):
        """Initialize SQLite tables for constraint tracking"""
        if not self.db:
            self.db.connect()

        try:
            # Table for primary key tracking
            self.cursor.execute('''
                           CREATE TABLE IF NOT EXISTS pk_tracking
                           (
                               table_name TEXT,
                               pk_value   TEXT,
                               PRIMARY KEY (table_name, pk_value)
                           )
                           ''')

            # Table for composite key tracking
            self.cursor.execute('''
                           CREATE TABLE IF NOT EXISTS composite_pk_tracking
                           (
                               table_name    TEXT,
                               composite_key TEXT,
                               PRIMARY KEY (table_name, composite_key)
                           )
                           ''')

            # Table for foreign key value pools
            self.cursor.execute('''
                           CREATE TABLE IF NOT EXISTS fk_pools
                           (
                               parent_table  TEXT,
                               parent_column TEXT,
                               fk_value      TEXT,
                               PRIMARY KEY (parent_table, parent_column, fk_value)
                           )
                           ''')

            # Index for better performance
            self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_fk_pools ON fk_pools(parent_table, parent_column)')

            self.cursor.commit()
            self.logger.info("Constraint tracking tables initialized")

        except Exception as e:
            self.logger.error(f"Error initializing constraint tables: {e}")

    def reset_constraint_tracking(self):
        """Reset all constraint tracking for fresh generation"""
        if not self.db:
            return

        try:
            self.cursor.execute('DELETE FROM pk_tracking')
            self.cursor.execute('DELETE FROM composite_pk_tracking')
            self.cursor.execute('DELETE FROM fk_pools')
            self.cursor.commit()

            # Clear in-memory caches
            self._pk_cache.clear()
            self._fk_cache.clear()

            self.logger.info("Constraint tracking reset")
        except Exception as e:
            self.logger.error(f"Error resetting constraint tracking: {e}")

    def _is_pk_used(self, table_name: str, pk_value: str) -> bool:
        """Check if primary key value is already used"""
        # Check cache first
        if pk_value in self._pk_cache.get(table_name, set()):
            return True

        if not self.db:
            return False

        try:
            cursor = self.cursor.execute(
                'SELECT 1 FROM pk_tracking WHERE table_name = ? AND pk_value = ?',
                (table_name, str(pk_value))
            )
            return cursor.fetchone() is not None
        except Exception as e:
            self.logger.error(f"Error checking PK usage: {e}")
            return False

    def _store_pk_value(self, table_name: str, pk_value: str):
        """Store primary key value"""
        # Add to cache
        if len(self._pk_cache[table_name]) < self._cache_size_limit:
            self._pk_cache[table_name].add(pk_value)

        if not self.db:
            return

        try:
            self.cursor.execute(
                'INSERT OR IGNORE INTO pk_tracking (table_name, pk_value) VALUES (?, ?)',
                (table_name, str(pk_value))
            )
            self.cursor.commit()
        except Exception as e:
            self.logger.error(f"Error storing PK value: {e}")

    def _is_composite_key_used(self, table_name: str, composite_key: tuple) -> bool:
        """Check if composite key is already used"""
        if not self.db:
            return False

        try:
            key_str = '|'.join(str(k) for k in composite_key)
            cursor = self.cursor.execute(
                'SELECT 1 FROM composite_pk_tracking WHERE table_name = ? AND composite_key = ?',
                (table_name, key_str)
            )
            return cursor.fetchone() is not None
        except Exception as e:
            self.logger.error(f"Error checking composite key usage: {e}")
            return False

    def _store_composite_key(self, table_name: str, composite_key: tuple):
        """Store composite key value"""
        if not self.db:
            return

        try:
            self.cursor = self.cursor
            key_str = '|'.join(str(k) for k in composite_key)
            self.cursor.execute(
                'INSERT OR IGNORE INTO composite_pk_tracking (table_name, composite_key) VALUES (?, ?)',
                (table_name, key_str)
            )
            self.cursor.commit()
        except Exception as e:
            self.logger.error(f"Error storing composite key: {e}")

    def _get_fk_values(self, parent_table: str, parent_column: str) -> List[Any]:
        """Get foreign key values from database"""
        cache_key = f"{parent_table}.{parent_column}"

        # Check cache first
        if cache_key in self._fk_cache and len(self._fk_cache[cache_key]) > 0:
            return self._fk_cache[cache_key]

        if not self.db:
            return []

        try:
            cursor = self.cursor.execute(
                'SELECT fk_value FROM fk_pools WHERE parent_table = ? AND parent_column = ?',
                (parent_table, parent_column)
            )

            values = [row[0] for row in cursor.fetchall()]

            # Update cache if not too large
            if len(values) <= self._cache_size_limit:
                self._fk_cache[cache_key] = values

            return values
        except Exception as e:
            self.logger.error(f"Error getting FK values: {e}")
            return []

    def _store_fk_values(self, parent_table: str, parent_column: str, values: List[Any]):
        """Store foreign key values in database"""
        if not self.db or not values:
            return

        try:
            # Prepare data for batch insert
            data = [(parent_table, parent_column, str(value)) for value in values]

            self.cursor.executemany(
                'INSERT OR IGNORE INTO fk_pools (parent_table, parent_column, fk_value) VALUES (?, ?, ?)',
                data
            )
            self.cursor.commit()

            # Update cache
            cache_key = f"{parent_table}.{parent_column}"
            if len(values) <= self._cache_size_limit:
                self._fk_cache[cache_key].extend(values)

            self.logger.info(f"Stored {len(values)} FK values for {parent_table}.{parent_column}")

        except Exception as e:
            self.logger.error(f"Error storing FK values: {e}")

    def _get_next_sequential_pk(self, table_name: str) -> int:
        """Get next sequential primary key value"""
        if not self.db:
            return 1

        try:
            cursor = self.cursor.execute(
                'SELECT COUNT(*) FROM pk_tracking WHERE table_name = ?',
                (table_name,)
            )
            count = cursor.fetchone()[0]
            return count + 1
        except Exception as e:
            self.logger.error(f"Error getting sequential PK: {e}")
            return 1

    def random_date(self, start, end):
        """Generate random date between start and end"""
        start = datetime.strptime(start, "%Y-%m-%d")
        end = datetime.strptime(end, "%Y-%m-%d")
        delta = end - start
        return (start + timedelta(days=random.randint(0, delta.days))).date()

    def generate_value_with_distribution(self, rule, data_type):
        """Generate value considering probability distributions"""
        if isinstance(rule, dict) and rule.get("type") == "choice":
            choices = rule.get("value", [])
            probabilities = rule.get("probabilities", {})
            if probabilities:
                # Use weighted random selection
                weights = [probabilities.get(choice, 1.0) for choice in choices]
                return random.choices(choices, weights=weights, k=1)[0]
            else:
                return random.choice(choices)

        return self.generate_value(rule, data_type)

    def generate_value(self, rule, data_type):
        """Enhanced value generation with better rule handling"""
        if isinstance(rule, str):
            cleaned_rule = rule.replace(" ", "").replace("_", "").lower()
            mapped_data = {
                "bool": random.choice([True, False]),
                "uuid": self.faker.uuid4(),
                "cc": self.faker.credit_card_number(),
                "cc_cvv": self.faker.credit_card_security_code(),
                "cc_expiry_date": self.faker.credit_card_expire(),
                "phone": self.faker.phone_number(),
                "phonenumber": self.faker.phone_number(),
                "phoneno": self.faker.phone_number(),
                "firstname": self.faker.first_name(),
                "lastname": self.faker.last_name(),
                "timestamp": self.faker.date_time().strftime("%Y-%m-%d %H:%M:%S"),
            }
            try:
                faker_dict = {x.replace("_", ""): x for x in dir(self.faker) if not x.startswith("_")}
                faker_dict.update({''.join([y[0] for y in x.split('_')]): x for x in dir(self.faker) if '_' in x and not x.startswith('_')})
                if rule in faker_dict:
                    rule = faker_dict.get(rule, faker_dict.get(cleaned_rule))
                    return getattr(self.faker, rule)()
                else:
                    return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))
            except AttributeError:
                self.logger.warning(f"Faker does not support {rule}. Checking in mapped data")
                return mapped_data.get(rule, mapped_data.get(cleaned_rule, None))

        elif isinstance(rule, dict):
            rule_type = rule.get("type")
            rule_regex = rule.get("regex")
            data = None

            if rule_type is not None:
                if rule_type == "choice":
                    # Handle choice with probabilities
                    return self.generate_value_with_distribution(rule, data_type)
                elif rule_type in ["date", "date_range"]:
                    start_date = rule.get("start", "1950-01-01")
                    end_date = rule.get("end", datetime.now().strftime("%Y-%m-%d"))
                    data = self.random_date(start_date, end_date)
                elif rule_type in ["time", "time_range"]:
                    start_time = rule.get("start", "00:00:00")
                    end_time = rule.get("end", "23:59:59")
                    start_dt = datetime.strptime(f"1970-01-01 {start_time}", "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(f"1970-01-01 {end_time}", "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%H:%M:%S")
                elif rule_type in ["timestamp", "timestamp_range"]:
                    start_ts = rule.get("start", "2000-01-01 00:00:00")
                    end_ts = rule.get("end", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    start_dt = datetime.strptime(start_ts, "%Y-%m-%d %H:%M:%S")
                    end_dt = datetime.strptime(end_ts, "%Y-%m-%d %H:%M:%S")
                    data = self.faker.date_time_between_dates(start_dt, end_dt).strftime("%Y-%m-%d %H:%M:%S")
                elif rule_type == "range":
                    min_val = rule.get("min", 0)
                    max_val = rule.get("max", 10000)
                    if data_type == "int":
                        data = random.randint(int(min_val), int(max_val))
                    elif data_type == "float":
                        data = round(random.uniform(min_val, max_val), 2)
                elif rule_type in ["fixed", "default"]:
                    data = rule.get("value")
                elif rule_type == "email":
                    data = self.faker.email()
                elif rule_type == "phone_number":
                    data = self.faker.phone_number()
                else:
                    # Try to generate using rule_type as faker method
                    data = self.generate_value(rule_type, data_type)

            # Validate against regex if provided
            if rule_regex is not None and data is not None:
                max_attempts = 10
                attempts = 0
                while not self.validator.regex_validator(rule_regex, str(data)) and attempts < max_attempts:
                    if rule_type == "email":
                        data = self.faker.email()
                    elif rule_type == "phone_number":
                        # Generate phone number matching regex
                        data = self.generate_phone_matching_regex(rule_regex)
                    else:
                        data = self.generate_value(rule_type, data_type)
                    attempts += 1

                if attempts >= max_attempts:
                    self.logger.warning(f"Could not generate valid data matching regex {rule_regex}")

            return data
        return None

    def generate_phone_matching_regex(self, regex_pattern):
        """Generate phone number that matches the given regex pattern"""
        # Simple implementation for common phone patterns
        if "10,15" in regex_pattern:
            # Generate 10-15 digit phone number
            length = random.randint(10, 15)
            return ''.join([str(random.randint(0, 9)) for _ in range(length)])
        return self.faker.phone_number()

    def handle_conditions(self, conditions, row):
        """Enhanced condition handling with better operator support"""
        self.logger.debug("Handling conditions")
        for condition in conditions:
            column = condition["column"]
            operator = condition["operator"].replace(" ", "").replace("_", "").lower()

            if column not in row:
                self.logger.warning(f"Column {column} not found in row for condition check")
                return False

            row_value = row[column]
            if row_value is None:
                return False

            if operator in ["equals", "=", "eq"]:
                if row_value != condition["value"]:
                    return False
            elif operator in ["notequals", "!=", "ne"]:
                if row_value == condition["value"]:
                    return False
            elif operator in ["less", "<", "lessthan", "lt"]:
                if row_value >= condition["value"]:
                    return False
            elif operator in ["lessequal", "<=", "le"]:
                if row_value > condition["value"]:
                    return False
            elif operator in ["greater", ">", "greaterthan", "gt"]:
                if row_value <= condition["value"]:
                    return False
            elif operator in ["greaterequal", ">=", "ge"]:
                if row_value < condition["value"]:
                    return False
            elif operator in ["between", "range"]:
                min_val = condition.get("min", condition.get("start"))
                max_val = condition.get("max", condition.get("end"))
                if not (min_val <= row_value <= max_val):
                    return False
            elif operator in ["in", "contains"]:
                if row_value not in condition.get("values", []):
                    return False
            elif operator in ["notin", "notcontains"]:
                if row_value in condition.get("values", []):
                    return False
        return True

    def generate_primary_key(self, column_def, table_name, current_id=None):
        """Generate unique primary key value using database tracking"""
        data_type = column_def["type"]
        rule = column_def.get("rule", {})

        pk_value = None

        if current_id is not None:
            # Use provided ID for sequential generation
            if data_type == "int":
                pk_value = current_id
            elif data_type == "str":
                pk_value = f"{table_name}_{current_id}"

            if not self._is_pk_used(table_name, str(pk_value)):
                self._store_pk_value(table_name, str(pk_value))
                return pk_value

        # Generate unique value based on rule
        max_attempts = 100
        for attempt in range(max_attempts):
            if isinstance(rule, dict) and rule.get("type") == "range":
                if data_type == "int":
                    value = random.randint(rule.get("min", 1), rule.get("max", 100000))
                else:
                    value = self.generate_value(rule, data_type)
            else:
                value = self.generate_value(rule, data_type) if rule else (
                    random.randint(1, 100000) if data_type == "int" else self.faker.uuid4()
                )

            if not self._is_pk_used(table_name, str(value)):
                self._store_pk_value(table_name, str(value))
                return value

        # Fallback to sequential if all attempts failed
        fallback_id = self._get_next_sequential_pk(table_name)
        self._store_pk_value(table_name, str(fallback_id))
        return fallback_id

    def generate_composite_key(self, composite_columns, columns_def, table_name, current_id=None):
        """Generate unique composite primary key using database tracking"""
        max_attempts = 100

        for attempt in range(max_attempts):
            key_parts = []
            for idx, col_name in enumerate(composite_columns):
                col_def = next((c for c in columns_def if c["name"] == col_name), None)
                if not col_def:
                    continue

                if current_id is not None:
                    if col_def["type"] == "int":
                        key_parts.append(current_id + idx)
                    else:
                        key_parts.append(f"{col_name}_{current_id + idx}")
                else:
                    value = self.generate_value(col_def.get("rule"), col_def["type"])
                    key_parts.append(value)

            composite_key = tuple(key_parts)
            if not self._is_composite_key_used(table_name, composite_key):
                self._store_composite_key(table_name, composite_key)
                return dict(zip(composite_columns, key_parts))

        # Fallback
        fallback_id = self._get_next_sequential_pk(table_name)
        fallback_key = {}
        for idx, col_name in enumerate(composite_columns):
            col_def = next((c for c in columns_def if c["name"] == col_name), None)
            if col_def and col_def["type"] == "int":
                fallback_key[col_name] = fallback_id + idx
            else:
                fallback_key[col_name] = f"{col_name}_{fallback_id + idx}"

        composite_key = tuple(fallback_key.values())
        self._store_composite_key(table_name, composite_key)
        return fallback_key

    def handle_foreign_key_constraints(self, row, foreign_keys, foreign_key_data):
        """Handle foreign key constraints and relationships using database"""
        for fk in foreign_keys:
            child_column = fk["child_column"]
            parent_table = fk["parent_table"]
            parent_column = fk["parent_column"]

            # Get available foreign key values from database
            available_values = self._get_fk_values(parent_table, parent_column)

            # Also check provided foreign_key_data
            fk_key = f"{parent_table}.{parent_column}"
            if fk_key in foreign_key_data:
                available_values.extend(foreign_key_data[fk_key])

            if available_values:
                row[child_column] = random.choice(available_values)
                self.logger.debug(
                    f"Assigned FK {child_column} = {row[child_column]} from {parent_table}.{parent_column}")
            else:
                # Generate a reasonable foreign key value if no pool exists
                self.logger.warning(f"No FK pool for {parent_table}.{parent_column}, generating random value")
                row[child_column] = random.randint(1, 1000)

    def store_generated_pk_values(self, table_name: str, data: List[Dict[str, Any]], pk_columns: List[str]):
        """Store generated primary key values for foreign key reference"""
        if not pk_columns or not data:
            return

        # Extract and store primary key values
        for pk_col in pk_columns:
            values = [row[pk_col] for row in data if pk_col in row and row[pk_col] is not None]
            if values:
                self._store_fk_values(table_name, pk_col, values)

    def apply_conditional_rules(self, row, column_def):
        """Apply conditional rules based on other column values"""
        conditional_rules = column_def.get("conditional_rules", [])

        for condition_rule in conditional_rules:
            when_conditions = condition_rule.get("when", [])
            then_rule = condition_rule.get("then", {}).get("rule", {})

            if self.handle_conditions(when_conditions, row):
                # Apply the conditional rule
                if isinstance(then_rule, dict) and then_rule.get("type") in ["fixed", "default"]:
                    return then_rule.get("value")
                else:
                    # Merge base rule with conditional rule
                    base_rule = column_def.get("rule", {})
                    if isinstance(base_rule, dict) and isinstance(then_rule, dict):
                        merged_rule = {**base_rule, **then_rule}
                    else:
                        merged_rule = then_rule

                    return self.generate_value_with_distribution(merged_rule, column_def["type"])

        return None  # No conditional rule applied

    def generate_row(self, table_metadata, record_count, foreign_key_data=None):
        """Enhanced row generation with comprehensive constraint handling"""
        table_name = table_metadata["table_name"]
        columns = table_metadata["columns"]
        foreign_keys = table_metadata.get("foreign_keys", [])
        composite_columns = table_metadata.get("composite_primary_key", [])

        if foreign_key_data is None:
            foreign_key_data = {}

        # Identify primary key columns
        pk_columns = [col for col in columns if "PK" in col.get("constraint", [])]
        if not pk_columns and not composite_columns:
            # Look for constraints field as well
            pk_columns = [col for col in columns if "PK" in col.get("constraints", [])]

        current_record = 0

        while current_record < record_count:
            row = {}

            # Handle composite primary key first
            if composite_columns:
                composite_key_values = self.generate_composite_key(
                    composite_columns, columns, table_name, current_record + 1
                )
                row.update(composite_key_values)

            # Handle single primary key
            elif pk_columns:
                pk_col = pk_columns[0]  # Assuming single primary key
                pk_value = self.generate_primary_key(pk_col, table_name, current_record + 1)
                row[pk_col["name"]] = pk_value

            # Handle foreign key constraints
            self.handle_foreign_key_constraints(row, foreign_keys, foreign_key_data)

            # Generate values for all other columns
            for column in columns:
                column_name = column["name"]

                # Skip if already handled (PK, FK, composite)
                if column_name in row:
                    continue

                data_type = column["type"]
                nullable = column.get("nullable", True)
                default_value = column.get("default")

                # Apply conditional rules first
                conditional_value = self.apply_conditional_rules(row, column)
                if conditional_value is not None:
                    row[column_name] = conditional_value
                    continue

                # Generate value based on rule
                rule = column.get("rule")
                if rule:
                    value = self.generate_value_with_distribution(rule, data_type)
                else:
                    # Generate default value based on type
                    if data_type == "int":
                        value = random.randint(1, 100)
                    elif data_type == "float":
                        value = round(random.uniform(1.0, 100.0), 2)
                    elif data_type == "bool":
                        value = random.choice([True, False])
                    elif data_type == "date":
                        value = self.faker.date_between(start_date="-5y", end_date="today")
                    elif data_type == "str":
                        value = self.faker.text(max_nb_chars=50)
                    else:
                        value = None

                # Handle nullable columns
                if nullable and random.random() < 0.1:  # 10% chance of null
                    value = None

                row[column_name] = value

            if not self.validator.validate_record(row, table_metadata):
                continue

            current_record += 1
            yield row

    def generate_batch(self, table_metadata, batch_size, foreign_key_data=None):
        """Generate a batch of records"""
        batch = []
        for row in self.generate_row(table_metadata, batch_size, foreign_key_data):
            batch.append(row)
        return batch
