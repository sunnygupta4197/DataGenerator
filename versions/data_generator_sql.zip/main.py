import os
import logging
import argparse
from datetime import datetime

import pandas as pd
from traceback import print_exc

from reader.json_reader import JSONConfigReader
from data_generator.data_generator import DataGenerator
from data_generator.validator import DataValidator
from writer import CSVWriter, JsonWriter, ParquetWriter, SQLQueryWriter

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def extract_foreign_key_data(data, table_metadata):
    """Extract foreign key data from generated records"""
    fk_data = {}

    # Get primary key columns
    pk_columns = get_primary_key_columns(table_metadata)

    # Extract primary key values for foreign key references
    for pk_col in pk_columns:
        values = [row.get(pk_col) for row in data if row.get(pk_col) is not None]
        if values:
            fk_data[f"{table_metadata['table_name']}.{pk_col}"] = values
            logger.info(f"Extracted {len(values)} values for FK reference {table_metadata['table_name']}.{pk_col}")

    return fk_data


def collect_foreign_key_constraints(table_metadata, all_fk_data):
    """Collect foreign key constraints for current table"""
    constraints = {}

    foreign_keys = table_metadata.get("foreign_keys", [])
    for fk in foreign_keys:
        parent_table = fk["parent_table"]
        parent_column = fk["parent_column"]

        # Create the key to look up foreign key values
        fk_key = f"{parent_table}.{parent_column}"

        if fk_key in all_fk_data:
            constraints[fk_key] = all_fk_data[fk_key]
            logger.info(f"Found {len(all_fk_data[fk_key])} FK values for {fk_key}")
        else:
            logger.warning(f"No foreign key data found for {fk_key}")
            constraints[fk_key] = []

    return constraints


def export_data(db, table_metadata, output_dir, output_format, batch_size):
    """Write data chunk to file"""
    logger.info(f'Writing data for table {table_metadata["table_name"]} in {output_format} format')

    cursor = db.connect()
    data = pd.read_sql("SELECT * FROM {}".format(table_metadata["table_name"]), cursor)
    db.close()

    for column in table_metadata.get("columns", []):
        sensitivity = column.get("sensitivity")
        default_value = column.get("default")
        rule = column.get("rule", {})

        if default_value is not None:
            data[column["name"]] = data[column["name"]].fillna(default_value)
        if column["type"] in ["boolean", "bool"]:
            data[column["name"]] = data[column["name"]].astype(column["type"])
        if sensitivity is not None:
            pass
        if isinstance(rule, dict):
            distribution = rule.get("distribution", rule.get("probabilities"))
            if distribution is not None:
                pass
                # print(data[column["name"]].value_counts(normalize=True).to_dict())
                # print(distribution)

    if data.empty:
        logger.warning(f"No data to write")
        return

    writer = None

    try:
        if output_format == "csv":
            writer = CSVWriter(data, table_metadata, output_dir, batch_size, logger)
        elif output_format == "parquet":
            writer = ParquetWriter(data, table_metadata, output_dir, batch_size, logger)
        elif output_format == "json":
            writer = JsonWriter(data, table_metadata, output_dir, batch_size, logger)
        elif output_format == "sql_query":
            writer = SQLQueryWriter(data, table_metadata, output_dir, batch_size, logger)
        else:
            logger.error(f"Unsupported output format: {output_format}")
            return

        writer.write_data()

        logger.info(f"Data written to {output_dir} with {len(data)} records")
    except Exception as e:
        logger.error(f"Error writing data to {output_dir}: {e}")
        raise


def get_primary_key_columns(table_metadata):
    """Get primary key columns from table metadata"""
    # Check for composite primary key first
    composite_pk = table_metadata.get("composite_primary_key", [])
    if composite_pk:
        return composite_pk

    # Look for individual primary key columns
    pk_columns = []
    for column in table_metadata["columns"]:
        constraints = column.get("constraints", [])
        constraint = column.get("constraint", [])  # Alternative field name

        if "PK" in constraints or "PK" in constraint:
            pk_columns.append(column["name"])

    return pk_columns


def validate_table_metadata(table_metadata):
    """Validate table metadata structure"""
    required_fields = ["table_name", "columns"]

    for field in required_fields:
        if field not in table_metadata:
            logger.error(f"Missing required field '{field}' in table metadata")
            return False

    # Validate columns
    for column in table_metadata["columns"]:
        if "name" not in column or "type" not in column:
            logger.error(f"Column missing required 'name' or 'type' field: {column}")
            return False

    return True


def save_data_to_db(db, table_metadata, buffer, all_generated_fk_data, data_generator):
    try:
        db.insert_data(table_metadata["table_name"], buffer)
    except Exception as e:
        logger.warning(f"Database insertion failed for final chunk: {e}")

    # Extract foreign key data from final chunk
    final_fk_data = extract_foreign_key_data(buffer, table_metadata)
    for key, values in final_fk_data.items():
        if key not in all_generated_fk_data:
            all_generated_fk_data[key] = []
        all_generated_fk_data[key].extend(values)

    # Store primary key values for final chunk
    pk_columns = get_primary_key_columns(table_metadata)
    data_generator.store_generated_pk_values(table_metadata["table_name"], buffer, pk_columns)


def generate_data_and_save(table_metadata,
                           total_records,
                           foreign_key_data,
                           output_dir,
                           output_format,
                           chunk_size = 100000,
                           db=None):
    """Generate data for a table and save to files"""

    if not validate_table_metadata(table_metadata):
        raise ValueError(f"Invalid table metadata for {table_metadata.get('table_name', 'unknown')}")

    table_name = table_metadata["table_name"]
    logger.info(f"Starting data generation for table '{table_name}' with {total_records} records")

    # Initialize data generator with database connection and config
    data_generator = DataGenerator(
        config=table_metadata,  # Pass table metadata as config
        locale=config.get("locale"),
        logger=logger,
        db=db
    )

    data_validator = DataValidator(logger)

    # Store foreign key values in database for reference
    if foreign_key_data:
        for fk_key, values in foreign_key_data.items():
            if '.' in fk_key:
                parent_table, parent_column = fk_key.split('.', 1)
                data_generator._store_fk_values(parent_table, parent_column, values, table_metadata[parent_table][parent_column]["type"])
                logger.info(f"Stored {len(values)} FK values for {parent_table}.{parent_column}")

    # Track generation progress
    buffer = []
    chunk_id = 1
    records_generated = 0
    batch_size = min(chunk_size, 10000)  # Process in smaller batches for memory efficiency

    # To store all generated foreign key data
    all_generated_fk_data = {}

    try:
        # while remaining_records > 0:
        #     current_batch_size = min(batch_size, remaining_records)

        while records_generated < total_records:
            current_batch_size = min(batch_size, total_records - records_generated)
            logger.debug(f"Generating batch of {current_batch_size} records")

            # Generate batch using the updated generator
            batch_data = data_generator.generate_batch(
                table_metadata,
                current_batch_size,
                foreign_key_data
            )

            # Validate generated data
            valid_records = []
            for row in batch_data:
                is_valid, message = data_validator.validate_constraints(row, table_metadata)
                if is_valid:
                    valid_records.append(row)
                else:
                    logger.warning(f"Invalid record generated: {message}")

            buffer.extend(valid_records)
            records_generated += len(valid_records)

            # Write chunk if buffer is full
            if len(buffer) >= chunk_size:
                # Insert into database if available
                save_data_to_db(db, table_metadata, buffer, all_generated_fk_data, data_generator)
                # Update buffer and counters
                buffer = buffer[chunk_size:]
                chunk_id += 1

            # Progress logging
            if records_generated % 50000 == 0:
                logger.info(f"Generated {records_generated}/{total_records} records for {table_name}")

    except Exception as e:
        logger.error(f"Error during data generation for {table_name}: {e}")
        print_exc()
        raise

    # Write remaining buffer
    if buffer:
        # Insert into database if available
        save_data_to_db(db, table_metadata, buffer, all_generated_fk_data, data_generator)

    logger.info(f"Completed data generation for {table_name}: {records_generated} records generated")

    return all_generated_fk_data


def process_tables_in_dependency_order(config):
    """Order tables based on foreign key dependencies"""
    tables = config["tables"]
    processed = []
    remaining = tables.copy()

    # Keep track of processed table names
    processed_names = set()

    while remaining:
        progress_made = False

        for table in remaining[:]:  # Create a copy to iterate over
            table_name = table["table_name"]
            foreign_keys = table.get("foreign_keys", [])

            # Check if all parent tables have been processed
            dependencies_met = True
            for fk in foreign_keys:
                parent_table = fk["parent_table"]
                if parent_table not in processed_names and parent_table != table_name:
                    dependencies_met = False
                    break

            if dependencies_met:
                processed.append(table)
                processed_names.add(table_name)
                remaining.remove(table)
                progress_made = True

        # If no progress was made, there might be circular dependencies
        if not progress_made:
            logger.warning("Possible circular dependency detected in table relationships")
            # Add remaining tables anyway
            processed.extend(remaining)
            break

    return processed


def initialize_constraint_tracking(config, db):
    """Initialize constraint tracking for all tables"""
    if not db:
        return

    logger.info("Initializing constraint tracking system")

    # Create a temporary DataGenerator to initialize constraint tables
    temp_generator = DataGenerator(config={}, logger=logger, db=db)

    # Reset constraint tracking for fresh generation
    temp_generator.reset_constraint_tracking()

    logger.info("Constraint tracking system initialized")


def main(config,
         total_records,
         output_dir="./output",
         chunk_size=100000,
         db=None):
    """Main function to orchestrate data generation"""

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"Output directory: {output_dir}")

    # Get configuration values
    default_records = config.get("row_count", config.get("total_records", 100))
    total_records = total_records or default_records
    output_format = config.get("output_format", "csv")

    logger.info(f"Starting data generation process")
    logger.info(f"Records per table: {total_records}")
    logger.info(f"Output format: {output_format}")
    logger.info(f"Chunk size: {chunk_size}")

    # Initialize constraint tracking system
    initialize_constraint_tracking(config, db)

    # Process tables in dependency order
    ordered_tables = process_tables_in_dependency_order(config)
    logger.info(f"Processing {len(ordered_tables)} tables in dependency order")

    # Track foreign key data across all tables
    all_foreign_key_data = {}
    generation_stats = {}

    try:
        for i, table_metadata in enumerate(ordered_tables, 1):
            table_name = table_metadata["table_name"]
            logger.info(f"Processing table {i}/{len(ordered_tables)}: {table_name}")

            # Get foreign key constraints for current table
            foreign_key_data = collect_foreign_key_constraints(table_metadata, all_foreign_key_data)

            # Log foreign key relationships
            if foreign_key_data:
                logger.info(f"Foreign key constraints for {table_name}:")
                for fk_key, parent_vals in foreign_key_data.items():
                    logger.info(f"  {fk_key}: {len(parent_vals)} available values")

            start_time = pd.Timestamp.now()

            try:
                # Generate data for current table
                generated_fk_data = generate_data_and_save(
                    table_metadata=table_metadata,
                    total_records=total_records,
                    foreign_key_data=foreign_key_data,
                    output_dir=output_dir,
                    output_format=output_format,
                    chunk_size=chunk_size,
                    db=db
                )

                # Store generated primary key values for foreign key references
                for key, values in generated_fk_data.items():
                    if key not in all_foreign_key_data:
                        all_foreign_key_data[key] = []
                    all_foreign_key_data[key].extend(values)

                # Record generation statistics
                end_time = pd.Timestamp.now()
                duration = (end_time - start_time).total_seconds()

                generation_stats[table_name] = {
                    "records_generated": total_records,
                    "primary_keys_generated": sum(len(vals) for vals in generated_fk_data.values()),
                    "duration_seconds": duration,
                    "records_per_second": total_records / duration if duration > 0 else 0
                }

                logger.info(f"Completed {table_name} in {duration:.2f} seconds "
                            f"({generation_stats[table_name]['records_per_second']:.0f} records/sec)")

            except Exception as e:
                logger.error(f"Failed to generate data for table {table_name}: {e}")
                # Continue with other tables
                generation_stats[table_name] = f"error {e}"
                continue

            try:
                logger.info(f"Exporting data to {output_dir}/{table_name}.{output_format}")
                export_data(db, table_metadata, output_dir, output_format, chunk_size)
            except Exception as e:
                logger.info(f"Failed to export data for table {table_name}: {e}")

    except KeyboardInterrupt:
        logger.warning("Data generation interrupted by user")
        return
    except Exception as e:
        logger.error(f"Unexpected error during data generation: {e}")
        print_exc()
        raise

    # Generate summary report
    generate_summary_report(generation_stats, output_dir, config)
    logger.info("Data generation process completed successfully")


def generate_summary_report(stats,
                            output_dir,
                            config):
    """Generate a summary report of the data generation process"""

    report_path = os.path.join(output_dir, "generation_report.json")

    # Calculate totals
    total_records = sum(s.get("records_generated", 0) for s in stats.values() if "error" not in s)
    total_duration = sum(s.get("duration_seconds", 0) for s in stats.values() if "error" not in s)
    successful_tables = len([s for s in stats.values() if "error" not in s])
    failed_tables = len([s for s in stats.values() if "error" in s])

    summary = {
        "generation_timestamp": pd.Timestamp.now().isoformat(),
        "configuration": {
            "total_tables": len(config.get("tables", [])),
            "records_per_table": config.get("row_count", config.get("total_records", 100)),
            "output_format": config.get("output_format", "csv"),
            "output_directory": output_dir
        },
        "summary_statistics": {
            "successful_tables": successful_tables,
            "failed_tables": failed_tables,
            "total_records_generated": total_records,
            "total_duration_seconds": total_duration,
            "average_records_per_second": total_records / total_duration if total_duration > 0 else 0
        },
        "table_details": stats
    }

    try:
        import json
        with open(report_path, 'w') as f:
            json.dump(summary, f, indent=2, default=str)

        logger.info(f"Generation report saved to: {report_path}")

        # Log summary to console
        logger.info("=== GENERATION SUMMARY ===")
        logger.info(f"Successful tables: {successful_tables}/{len(config.get('tables', []))}")
        logger.info(f"Total records generated: {total_records:,}")
        logger.info(f"Total duration: {total_duration:.2f} seconds")
        logger.info(f"Average speed: {summary['summary_statistics']['average_records_per_second']:.0f} records/second")

        if failed_tables > 0:
            logger.warning(f"Failed tables: {failed_tables}")
            for table_name, table_stats in stats.items():
                if "error" in table_stats:
                    logger.error(f"  {table_name}: {table_stats['error']}")

    except Exception as e:
        logger.error(f"Could not generate summary report: {e}")


def arguments(start_time_slug):
    parser = argparse.ArgumentParser(description='Data Generator Utility')
    parser.add_argument('--config', '-c', required=True, help='Path to JSON config file')
    parser.add_argument('--output_dir', '-od', help='Path to save the output file')
    parser.add_argument('--output_format', '-f', choices=['csv', 'json', 'sql_query', 'parquet'], help='Output file format')
    parser.add_argument('--rows', '-r', type=int, default=10, help='Number of rows to generate per table')
    parser.add_argument('--locale', '-l', default="en_GB", help='Locale for data generation')

    args = parser.parse_args()

    db_file = f'data_generator_{start_time_slug}.db'

    logger.info(f"Loading configuration from: {args.config}")
    config_reader = JSONConfigReader(args.config, db_file)
    config = config_reader.load_config()

    if args.output_format:
        config.update({"output_format": args.output_format})
    if args.rows:
        config.update({"rows": args.rows})
    if args.locale:
        config.update({"locale": args.locale})

    return args.output_dir, config, config_reader

if __name__ == "__main__":
    # Configuration
    start_time_slug = datetime.now().strftime("%Y%m%d_%H%M%S")

    # output_dir, config, config_reader = arguments(start_time_slug)

    config_file = "config3.json"
    output_directory = f'./output/{start_time_slug}'
    db_file = f'data_generator_{start_time_slug}.db'

    try:
        # Load configuration
        logger.info(f"Loading configuration from: {config_file}")
        config_reader = JSONConfigReader(config_file, db_file)
        config = config_reader.load_config()

        # Run data generation
        main(
            config=config,
            total_records=config.get("rows", 100),
            output_dir=output_directory,
            chunk_size=100000,
            db=config_reader.db
        )

    except FileNotFoundError:
        logger.error(f"Configuration file '{config_file}' not found")
        exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        exit(1)