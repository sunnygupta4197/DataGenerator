import json
from json_reader import JSONConfigReader


if __name__ == "__main__":
    # for config_file in ["../config1.json", "../config2.json"]:
    config_file = "../config2.json"
    config = JSONConfigReader(config_file).load_config()
    print(json.dumps(config, indent=4))
