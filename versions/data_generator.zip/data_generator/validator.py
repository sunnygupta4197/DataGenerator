import re
import string
import random
from faker import Faker


class DataValidator:
    def __init__(self):
        self.faker = Faker()

    def regex_validator(self, regex_pattern, data):
        return re.match(regex_pattern, data)