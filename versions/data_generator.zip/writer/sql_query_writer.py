import os
import pandas as pd

from base_writer import BaseWriter

class SQLQueryWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, output_format, chunk_id, logger=None):
        super().__init__(data, table_metadata, output_dir, output_format, chunk_id, logger)

    def write_batch(self, data, sql_file, columns):
        values_list = []
        for _, row in data.iterrows():
            values = ', '.join(f"'{str(x).replace("'", "''")}'" if pd.notnull(x) else "NULL" for x in row)
            values_list.append(f"({values})")
        insert_stmt = f"INSERT INTO {self.table_metadata["table_name"]} ({columns}) VALUES ({', '.join(values_list)});\n"
        sql_file.write(insert_stmt)

    def write_data(self):
        self.logger.info(f'Writing data in chunk {self.chunk_id} in SQL format')
        df = pd.DataFrame(self.data)
        columns = df.columns
        path = self._prepare_file_name("sql")
        with open(path, 'w') as sql_file:
            for index, batch_data in enumerate(self.generate_batch()):
                self.logger.info(f'Writing batch {index} in chunk {self.chunk_id}')
                self.write_batch(batch_data, sql_file, columns)
        self.logger.info(f"Chunk {self.chunk_id} written to {path} with {len(self.data)} records")
