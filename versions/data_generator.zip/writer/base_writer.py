import os
import logging
from abc import ABC, abstractmethod

class BaseWriter(ABC):
    def __init__(self, data, table_metadata, output_dir, output_format, chunk_id, batch_size=1000, logger=None):
        self.data = data
        self.table_metadata = table_metadata
        self.output_dir = output_dir
        self.output_format = output_format
        self.chunk_id = chunk_id
        self.batch_size = batch_size
        self.logger = logger
        if self.logger is None:
            logger = logging.getLogger()
            self.logger = logger

    def _prepare_file_name(self, file_format: str) -> str:
        self.logger.info('Preparing file name')
        filename = [self.table_metadata["table_name"]]
        if self.chunk_id:
            filename.append(f"_part{self.chunk_id}")
        filename.append(f".{file_format}")
        filename = ''.join(filename)
        self.logger.info(f'File name: {filename}')
        return os.path.join(self.output_dir, filename)

    def generate_batch(self):
        for start in range(0, len(self.data), self.batch_size):
            batch = self.data.iloc[start:start + self.batch_size]
            yield batch

    @abstractmethod
    def write_data(self):
        pass