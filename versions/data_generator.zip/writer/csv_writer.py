import os
import pandas as pd

from base_writer import BaseWriter

class CSVWriter(BaseWriter):
    def __init__(self, data, table_metadata, output_dir, output_format, chunk_id, logger=None):
        super().__init__(data, table_metadata, output_dir, output_format, chunk_id, logger)

    def write_data(self):
        self.logger.info(f'Writing data in chunk {self.chunk_id} in CSV format')
        df = pd.DataFrame(self.data)
        path = self._prepare_file_name("csv")
        df.to_csv(path, index=False, sep=",", na_rep="NaN")
        self.logger.info(f"Chunk {self.chunk_id} written to {path} with {len(self.data)} records")
