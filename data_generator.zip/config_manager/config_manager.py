import os
import json
import logging
from typing import Dict, Any, List, Optional, Union
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict, field
from enum import Enum
import tempfile
import shutil
from contextlib import contextmanager
from .json_reader import JSONConfigReader


class Environment(Enum):
    """Environment types"""
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"


@dataclass
class DatabaseConfig:
    """Database connection configuration"""
    host: str = "localhost"
    port: int = 5432
    database: str = "testdata"
    username: str = "postgres"
    password: str = ""
    ssl_mode: str = "disable"
    connection_timeout: int = 30


@dataclass
class PerformanceConfig:
    """Performance-related configuration"""
    max_workers: int = 4
    batch_size: int = 10000
    streaming_batch_size: int = 1000
    max_memory_mb: int = 1000
    enable_parallel: bool = True
    enable_streaming: bool = True
    cache_size_limit: int = 50000
    use_processes: bool = False
    optimization_level: str = "balanced"

    def __post_init__(self):
        # Validate performance settings
        if self.max_workers < 1:
            self.max_workers = 1
        elif self.max_workers > 32:  # Reasonable upper limit
            self.max_workers = 32

        if self.batch_size < 100:
            self.batch_size = 100
        elif self.batch_size > 1000000:
            self.batch_size = 1000000

        if self.max_memory_mb < 100:
            self.max_memory_mb = 100


@dataclass
class SecurityConfig:
    """Enhanced Security configuration with masking rules support"""

    # Basic security settings
    enable_data_masking: bool = False
    enable_encryption: bool = False
    audit_enabled: bool = False

    # Masking configuration
    masking_rules: Dict[str, str] = field(default_factory=dict)
    sensitivity_map: Dict[str, str] = field(default_factory=dict)
    encrypt_fields: List[str] = field(default_factory=list)

    # Advanced security settings
    encryption_algorithm: str = "AES-256-GCM"
    encryption_key: Optional[str] = None
    encryption_key_file: Optional[str] = None
    key_source: str = "environment"  # environment, config, file
    key_env_var: str = "DATA_ENCRYPTION_KEY"

    # Compliance settings
    compliance_profile: Optional[str] = None  # GDPR, HIPAA, PCI_DSS, SOX
    auto_detect_pii: bool = True
    strict_mode: bool = False
    require_explicit_consent: bool = False

    # Audit configuration
    audit_log_level: str = "detailed"  # basic, detailed, verbose
    audit_file: Optional[str] = None
    include_masked_values: bool = False
    include_original_values: bool = False
    retention_days: int = 90

    # Pattern-based masking
    pattern_based_masking: Dict[str, str] = field(default_factory=dict)

    # Validation settings
    validate_masking_effectiveness: bool = True
    min_masking_percentage: float = 70.0
    validate_patterns: bool = True

    def __post_init__(self):
        """Post-initialization validation and setup"""

        # Validate masking rule types
        valid_masking_types = ["partial", "full", "hash", "custom", "format_preserving", "deterministic"]
        for field_name, mask_type in self.masking_rules.items():
            if isinstance(mask_type, str) and mask_type not in valid_masking_types:
                raise ValueError(f"Invalid masking type '{mask_type}' for field '{field_name}'. "
                                 f"Valid types: {valid_masking_types}")

        # Validate sensitivity levels
        valid_sensitivity_levels = ["PUBLIC", "INTERNAL", "PII", "SENSITIVE"]
        for field_name, sensitivity in self.sensitivity_map.items():
            if sensitivity not in valid_sensitivity_levels:
                raise ValueError(f"Invalid sensitivity level '{sensitivity}' for field '{field_name}'. "
                                 f"Valid levels: {valid_sensitivity_levels}")

        # Set up default masking rules if auto-detect is enabled
        if self.auto_detect_pii and not self.masking_rules:
            self.masking_rules.update(self._get_default_masking_rules())

        # Set up default sensitivity map if auto-detect is enabled
        if self.auto_detect_pii and not self.sensitivity_map:
            self.sensitivity_map.update(self._get_default_sensitivity_map())

        # Apply compliance profile settings
        if self.compliance_profile:
            self._apply_compliance_profile()

    def _get_default_masking_rules(self) -> Dict[str, str]:
        """Get default masking rules for common PII fields"""
        return {
            "email": "partial",
            "phone": "partial",
            "phone_number": "partial",
            "ssn": "full",
            "social_security": "full",
            "credit_card": "full",
            "card_number": "full",
            "salary": "hash",
            "income": "hash",
            "name": "partial",
            "first_name": "partial",
            "last_name": "partial",
            "address": "partial",
            "zipcode": "partial",
            "postal_code": "partial"
        }

    def _get_default_sensitivity_map(self) -> Dict[str, str]:
        """Get default sensitivity levels for common fields"""
        return {
            "email": "PII",
            "phone": "PII",
            "phone_number": "PII",
            "ssn": "SENSITIVE",
            "social_security": "SENSITIVE",
            "credit_card": "SENSITIVE",
            "card_number": "SENSITIVE",
            "salary": "SENSITIVE",
            "income": "SENSITIVE",
            "name": "PII",
            "first_name": "PII",
            "last_name": "PII",
            "address": "PII",
            "zipcode": "PII",
            "postal_code": "PII",
            "id": "INTERNAL",
            "user_id": "INTERNAL",
            "employee_id": "INTERNAL",
            "department": "INTERNAL",
            "status": "PUBLIC",
            "category": "PUBLIC",
            "product_id": "PUBLIC"
        }

    def _apply_compliance_profile(self):
        """Apply settings based on compliance profile"""
        if self.compliance_profile == "GDPR":
            self.strict_mode = True
            self.audit_enabled = True
            self.require_explicit_consent = True
            self.min_masking_percentage = 95.0

        elif self.compliance_profile == "HIPAA":
            self.strict_mode = True
            self.audit_enabled = True
            self.enable_encryption = True
            self.min_masking_percentage = 99.0

        elif self.compliance_profile == "PCI_DSS":
            self.strict_mode = True
            self.audit_enabled = True
            self.enable_encryption = True
            # Focus on payment card data
            self.masking_rules.update({
                "credit_card": "full",
                "card_number": "full",
                "cvv": "full",
                "expiry": "full"
            })

        elif self.compliance_profile == "SOX":
            self.audit_enabled = True
            self.retention_days = 2555  # 7 years
            # Focus on financial data
            self.masking_rules.update({
                "salary": "hash",
                "income": "hash",
                "revenue": "hash",
                "profit": "hash"
            })

    def add_masking_rule(self, field_pattern: str, masking_type: str):
        """Add a new masking rule"""
        valid_types = ["partial", "full", "hash", "custom", "format_preserving", "deterministic"]
        if masking_type not in valid_types:
            raise ValueError(f"Invalid masking type: {masking_type}. Valid types: {valid_types}")

        self.masking_rules[field_pattern] = masking_type

    def set_sensitivity_level(self, field_name: str, sensitivity_level: str):
        """Set sensitivity level for a field"""
        valid_levels = ["PUBLIC", "INTERNAL", "PII", "SENSITIVE"]
        if sensitivity_level not in valid_levels:
            raise ValueError(f"Invalid sensitivity level: {sensitivity_level}. Valid levels: {valid_levels}")

        self.sensitivity_map[field_name] = sensitivity_level

    def get_masking_rule_for_field(self, field_name: str) -> Optional[str]:
        """Get masking rule for a specific field, including pattern matching"""

        # Direct match first
        if field_name in self.masking_rules:
            return self.masking_rules[field_name]

        # Pattern matching
        field_lower = field_name.lower()
        for pattern, mask_type in self.masking_rules.items():
            pattern_lower = pattern.lower()

            # Wildcard pattern matching
            if pattern.startswith('*') and pattern.endswith('*'):
                # *email* pattern
                if pattern_lower.strip('*') in field_lower:
                    return mask_type
            elif pattern.startswith('*'):
                # *_email pattern
                if field_lower.endswith(pattern_lower[1:]):
                    return mask_type
            elif pattern.endswith('*'):
                # email_* pattern
                if field_lower.startswith(pattern_lower[:-1]):
                    return mask_type
            elif pattern_lower in field_lower:
                # Simple substring match
                return mask_type

        # Pattern-based masking
        for pattern, mask_type in self.pattern_based_masking.items():
            if self._match_pattern(field_name, pattern):
                return mask_type

        return None

    def _match_pattern(self, field_name: str, pattern: str) -> bool:
        """Match field name against pattern"""
        import re

        # Convert glob pattern to regex
        regex_pattern = pattern.replace('*', '.*').replace('?', '.')
        return bool(re.match(f"^{regex_pattern}$", field_name, re.IGNORECASE))

    def get_sensitivity_level(self, field_name: str) -> str:
        """Get sensitivity level for a field"""
        return self.sensitivity_map.get(field_name, "PUBLIC")

    def is_field_encrypted(self, field_name: str) -> bool:
        """Check if a field should be encrypted"""
        return field_name in self.encrypt_fields

    def validate_configuration(self) -> List[str]:
        """Validate security configuration and return any issues"""
        issues = []

        # Check for encryption without key
        if self.enable_encryption and not self.encryption_key and self.key_source == "config":
            issues.append("Encryption enabled but no encryption key provided")

        # Check for sensitive fields without masking
        for field_name, sensitivity in self.sensitivity_map.items():
            if sensitivity in ["PII", "SENSITIVE"] and not self.get_masking_rule_for_field(field_name):
                issues.append(f"Sensitive field '{field_name}' has no masking rule")

        # Check masking effectiveness
        if self.validate_masking_effectiveness:
            masked_fields = len(self.masking_rules)
            total_sensitive_fields = len([f for f, s in self.sensitivity_map.items()
                                          if s in ["PII", "SENSITIVE"]])

            if total_sensitive_fields > 0:
                masking_percentage = (masked_fields / total_sensitive_fields) * 100
                if masking_percentage < self.min_masking_percentage:
                    issues.append(
                        f"Masking coverage {masking_percentage:.1f}% below threshold {self.min_masking_percentage}%")

        return issues

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            "enable_data_masking": self.enable_data_masking,
            "enable_encryption": self.enable_encryption,
            "audit_enabled": self.audit_enabled,
            "masking_rules": self.masking_rules,
            "sensitivity_map": self.sensitivity_map,
            "encrypt_fields": self.encrypt_fields,
            "encryption_algorithm": self.encryption_algorithm,
            "compliance_profile": self.compliance_profile,
            "auto_detect_pii": self.auto_detect_pii,
            "strict_mode": self.strict_mode
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'SecurityConfig':
        """Create SecurityConfig from dictionary"""
        # Handle legacy configuration keys
        legacy_mapping = {
            "data_masking_enabled": "enable_data_masking",
            "encryption_enabled": "enable_encryption",
            "masking_enabled": "enable_data_masking"
        }

        # Apply legacy key mapping
        for old_key, new_key in legacy_mapping.items():
            if old_key in config_dict:
                config_dict[new_key] = config_dict.pop(old_key)

        return cls(**config_dict)


@dataclass
class OpenAIConfig:
    """OpenAI integration configuration"""
    enabled: bool = False
    api_key: Optional[str] = None
    api_key_env_var: str = "OPENAI_API_KEY"
    api_key_file: Optional[str] = None
    model: str = "gpt-3.5-turbo"
    max_tokens: int = 2000
    temperature: float = 0.7
    cache_size: int = 100
    timeout_seconds: int = 30
    retry_attempts: int = 3
    fallback_enabled: bool = True
    cost_limit_usd: Optional[float] = None

    def __post_init__(self):
        """Load API key from environment if not provided"""
        if self.enabled and not self.api_key:
            self.api_key = os.getenv(self.api_key_env_var)
            if not self.api_key:
                print(f"Warning: OpenAI enabled but no API key found in {self.api_key_env_var}")
                self.enabled = False

    def get_api_key(self) -> Optional[str]:
        """Get API key from various sources in priority order"""
        # 1. Direct API key (highest priority)
        if self.api_key:
            return self.api_key

        # 2. API key from file
        if self.api_key_file and os.path.exists(self.api_key_file):
            try:
                with open(self.api_key_file, 'r') as f:
                    key = f.read().strip()
                    if key:
                        return key
            except Exception:
                pass

        # 3. Environment variable (lowest priority)
        return os.getenv(self.api_key_env_var)

    def is_available(self) -> bool:
        """Check if OpenAI is properly configured and available"""
        return self.enabled and self.get_api_key() is not None


@dataclass
class OutputConfig:
    """Output configuration"""
    format: str = "csv"
    directory: str = "./output"
    filename_template: str = "{table_name}_{timestamp}"
    compression: Optional[str] = None
    encoding: str = "utf-8"
    include_header: bool = True
    append_timestamp: bool = True
    create_directory: bool = True

    # Format-specific settings
    csv_delimiter: str = ","
    csv_quotechar: str = '"'
    json_indent: int = 2
    parquet_engine: str = "pyarrow"

    def __post_init__(self):
        """Validate output configuration"""
        valid_formats = ["csv", "json", "jsonl", "parquet", "sql_query", "xlsx"]
        if self.format not in valid_formats:
            print(f"Warning: Invalid format '{self.format}', defaulting to 'csv'")
            self.format = "csv"

        # Create output directory if it doesn't exist
        if self.create_directory and not os.path.exists(self.directory):
            try:
                os.makedirs(self.directory, exist_ok=True)
            except Exception as e:
                print(f"Warning: Could not create output directory {self.directory}: {e}")

    def get_output_path(self, table_name: str) -> str:
        """Generate output file path for a table"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.filename_template.format(
            table_name=table_name,
            timestamp=timestamp
        )

        # Add file extension
        if not filename.endswith(f".{self.format}"):
            filename = f"{filename}.{self.format}"

        # Add compression extension
        if self.compression:
            filename = f"{filename}.{self.compression}"

        return os.path.join(self.directory, filename)


@dataclass
class BusinessRule:
    """Business rule definition"""
    type: str  # conditional, range_dependency, mutual_exclusivity
    condition_column: Optional[str] = None
    condition_operator: Optional[str] = None
    condition_value: Optional[Any] = None
    requirement_column: Optional[str] = None
    requirement_value: Optional[Any] = None

    # For range_dependency rules
    income_column: Optional[str] = None
    score_column: Optional[str] = None
    income_threshold: Optional[float] = None
    score_threshold: Optional[float] = None

    # For mutual_exclusivity rules
    column1: Optional[str] = None
    column2: Optional[str] = None
    value1: Optional[Any] = None
    value2: Optional[Any] = None

    description: Optional[str] = None
    severity: str = "warning"  # info, warning, error
    enabled: bool = True


@dataclass
class ValidationConfig:
    """Validation configuration"""
    strict_mode: bool = False
    max_validation_errors: int = 100
    enable_business_rules: bool = True
    enable_data_quality_analysis: bool = True
    enable_anomaly_detection: bool = True
    quality_threshold: float = 0.8
    business_rules: List[Dict[str, Any]] = field(default_factory=list)

    # Validation thresholds
    max_null_percentage: float = 50.0
    min_uniqueness_ratio: float = 0.1
    outlier_detection_method: str = "iqr"  # iqr, zscore, isolation_forest
    outlier_threshold: float = 3.0

    # Pattern validation
    enable_pattern_validation: bool = True
    custom_patterns: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        """Convert business rules dictionaries to BusinessRule objects"""
        if self.business_rules and isinstance(self.business_rules[0], dict):
            self.business_rules = [
                BusinessRule(**rule) if isinstance(rule, dict) else rule
                for rule in self.business_rules
            ]


@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: Optional[str] = None
    max_file_size_mb: int = 100
    backup_count: int = 5
    enhanced_format: bool = False
    console_output: bool = True

    # Advanced logging settings
    log_to_file: bool = True
    log_performance: bool = False
    log_memory_usage: bool = False
    log_sql_queries: bool = False

    def __post_init__(self):
        """Validate logging configuration"""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if self.level.upper() not in valid_levels:
            print(f"Warning: Invalid log level '{self.level}', defaulting to 'INFO'")
            self.level = "INFO"

        # Create log directory if file_path is specified
        if self.file_path:
            log_dir = os.path.dirname(self.file_path)
            if log_dir and not os.path.exists(log_dir):
                try:
                    os.makedirs(log_dir, exist_ok=True)
                except Exception as e:
                    print(f"Warning: Could not create log directory {log_dir}: {e}")


@dataclass
class GenerationConfig:
    """Main configuration class"""
    environment: str = Environment.DEVELOPMENT.value
    locale: str = "en_GB"
    tables: List[Dict[str, Any]] = field(default_factory=list)
    rows: int = 100
    output_format: str = 'csv'

    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    openai: OpenAIConfig = field(default_factory=OpenAIConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)

    # Additional settings
    seed: Optional[int] = None
    debug_mode: bool = False
    dry_run: bool = False

    def __post_init__(self):
        # Initialize sub-configurations with defaults if not provided
        if self.database is None:
            self.database = DatabaseConfig()
        if self.performance is None:
            self.performance = PerformanceConfig()
        if self.security is None:
            self.security = SecurityConfig()
        if self.openai is None:
            self.openai = OpenAIConfig()
        if self.output is None:
            self.output = OutputConfig()
        if self.validation is None:
            self.validation = ValidationConfig()
        if self.logging is None:
            self.logging = LoggingConfig()
        if self.tables is None:
            self.tables = []

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'GenerationConfig':
        """Create GenerationConfig from dictionary with proper nested object creation"""

        # Extract nested configurations
        performance_data = config_dict.pop('performance', {})
        security_data = config_dict.pop('security', {})
        openai_data = config_dict.pop('openai', {})
        output_data = config_dict.pop('output', {})
        validation_data = config_dict.pop('validation', {})
        logging_data = config_dict.pop('logging', {})
        database_data = config_dict.pop('database', {})

        # Create nested config objects
        performance_config = PerformanceConfig(**performance_data)
        security_config = SecurityConfig(**security_data)
        openai_config = OpenAIConfig(**openai_data)
        output_config = OutputConfig(**output_data)
        validation_config = ValidationConfig(**validation_data)
        logging_config = LoggingConfig(**logging_data)
        database_config = DatabaseConfig(**database_data)

        # Create main config
        return cls(
            performance=performance_config,
            security=security_config,
            openai=openai_config,
            output=output_config,
            validation=validation_config,
            logging=logging_config,
            database=database_config,
            **config_dict  # Remaining top-level fields
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            "environment": self.environment,
            "locale": self.locale,
            "rows": self.rows,
            "output_format": self.output_format,
            "tables": self.tables,
            "performance": self.performance.__dict__,
            "security": self.security.__dict__,
            "openai": self.openai.__dict__,
            "output": self.output.__dict__,
            "validation": self.validation.__dict__,
            "logging": self.logging.__dict__,
            "database": self.database.__dict__,
            "seed": self.seed,
            "debug_mode": self.debug_mode,
            "dry_run": self.dry_run
        }

    def validate(self) -> List[str]:
        """Validate the entire configuration and return any issues"""
        issues = []

        # Validate basic settings
        if self.rows <= 0:
            issues.append("Rows must be greater than 0")

        if not self.tables:
            issues.append("No tables defined in configuration")

        # Validate nested configurations
        try:
            security_issues = self.security.validate_configuration()
            issues.extend([f"Security: {issue}" for issue in security_issues])
        except AttributeError:
            pass  # validate_configuration method may not exist

        # Validate table configurations
        table_names = set()
        for i, table in enumerate(self.tables):
            table_name = table.get('table_name')
            if not table_name:
                issues.append(f"Table {i} missing table_name")
            elif table_name in table_names:
                issues.append(f"Duplicate table name: {table_name}")
            else:
                table_names.add(table_name)

            if not table.get('columns'):
                issues.append(f"Table {table_name} has no columns defined")

        return issues


class ConfigurationManager:
    """
    Centralized configuration management with environment support,
    validation, templates, OpenAI integration, and backward compatibility
    """

    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)
        self.config_cache = {}
        self.environment_configs = {}
        self.template_configs = {}

        # Load default configurations
        self._load_default_configs()

    def _load_default_configs(self):
        """Load default configurations for different environments"""
        # Development environment
        dev_config = GenerationConfig(
            environment=Environment.DEVELOPMENT.value,
            rows=1000,
            performance=PerformanceConfig(
                max_workers=2,
                batch_size=5000,
                max_memory_mb=500
            ),
            security=SecurityConfig(
                enable_data_masking=False,
                enable_encryption=False,
                audit_enabled=False
            ),
            openai=OpenAIConfig(
                enabled=False,
                model="gpt-3.5-turbo",
                cache_size=50,
                cost_limit_usd=5.0  # Low limit for development
            ),
            validation=ValidationConfig(
                strict_mode=False,
                max_validation_errors=50
            )
        )

        # Testing environment
        test_config = GenerationConfig(
            environment=Environment.TESTING.value,
            rows=10000,
            performance=PerformanceConfig(
                max_workers=4,
                batch_size=10000,
                max_memory_mb=1000
            ),
            security=SecurityConfig(
                enable_data_masking=True,
                enable_encryption=False,
                audit_enabled=True
            ),
            openai=OpenAIConfig(
                enabled=True,
                model="gpt-3.5-turbo",
                cache_size=100,
                cost_limit_usd=10.0
            ),
            validation=ValidationConfig(
                strict_mode=True,
                max_validation_errors=10
            )
        )

        # Production environment
        prod_config = GenerationConfig(
            environment=Environment.PRODUCTION.value,
            rows=1000000,
            performance=PerformanceConfig(
                max_workers=8,
                batch_size=50000,
                max_memory_mb=4000,
                enable_streaming=True
            ),
            security=SecurityConfig(
                enable_data_masking=True,
                enable_encryption=True,
                audit_enabled=True
            ),
            openai=OpenAIConfig(
                enabled=True,
                model="gpt-3.5-turbo",
                cache_size=200,
                cost_limit_usd=50.0,
                timeout_seconds=60,
                retry_attempts=5
            ),
            validation=ValidationConfig(
                strict_mode=True,
                max_validation_errors=0,
                quality_threshold=0.95
            )
        )

        self.environment_configs = {
            Environment.DEVELOPMENT.value: dev_config,
            Environment.TESTING.value: test_config,
            Environment.PRODUCTION.value: prod_config
        }

    # ===================== CONFIGURATION LOADING =====================

    def load_configuration(self, config_path: str,
                           environment: str = None) -> GenerationConfig:
        """Load configuration from file with environment override"""
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        raw_config = self._load_json(config_path)

        # Parse configuration
        config = self._parse_config_dict(raw_config)

        # Apply environment-specific overrides
        if environment:
            config = self._apply_environment_overrides(config, environment)

        # Apply environment variables
        config = self._apply_environment_variables(config)

        # Validate configuration
        self._validate_configuration(config)

        # Cache configuration
        cache_key = f"{config_path}:{environment or 'default'}"
        self.config_cache[cache_key] = config

        return config

    def _load_json(self, config_path: Path) -> Dict[str, Any]:
        """Load JSON configuration file"""
        try:
            config_reader = JSONConfigReader(config_path)
            config = config_reader.load_config()
            return config_reader.validate_schema(config)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON configuration: {e}")

    def _parse_config_dict(self, config_dict: Dict[str, Any]) -> GenerationConfig:
        """Parse configuration dictionary into GenerationConfig object"""
        # Handle nested configurations
        nested_configs = {}

        # Make a copy to avoid modifying the original
        config_dict = config_dict.copy()

        if 'database' in config_dict:
            nested_configs['database'] = DatabaseConfig(**config_dict.pop('database'))

        if 'performance' in config_dict:
            nested_configs['performance'] = PerformanceConfig(**config_dict.pop('performance'))

        if 'security' in config_dict:
            security_data = config_dict.pop('security', {})
            if isinstance(security_data, dict):
                # Filter out any unknown parameters
                valid_params = {
                    'enable_data_masking', 'masking_rules', 'sensitivity_map',
                    'encrypt_fields', 'audit_enabled', 'enable_encryption'
                }
                filtered_security = {k: v for k, v in security_data.items() if k in valid_params}
                nested_configs['security'] = SecurityConfig(**filtered_security)
            else:
                nested_configs['security'] = SecurityConfig()

        if 'openai' in config_dict:
            nested_configs['openai'] = OpenAIConfig(**config_dict.pop('openai'))

        if 'output' in config_dict:
            nested_configs['output'] = OutputConfig(**config_dict.pop('output'))

        if 'validation' in config_dict:
            nested_configs['validation'] = ValidationConfig(**config_dict.pop('validation'))

        if 'logging' in config_dict:
            nested_configs['logging'] = LoggingConfig(**config_dict.pop('logging'))

        # Create main configuration
        try:
            config = GenerationConfig(**config_dict, **nested_configs)
            return config
        except TypeError as e:
            raise ValueError(f"Invalid configuration structure: {e}")

    def _apply_environment_overrides(self, config: GenerationConfig,
                                     environment: str) -> GenerationConfig:
        """Apply environment-specific configuration overrides"""
        if environment not in self.environment_configs:
            self.logger.warning(f"Unknown environment: {environment}")
            return config

        env_config = self.environment_configs[environment]

        # Apply overrides selectively
        config.environment = environment

        # Performance overrides
        if env_config.performance:
            config.performance.max_workers = env_config.performance.max_workers
            config.performance.max_memory_mb = env_config.performance.max_memory_mb
            config.performance.enable_streaming = env_config.performance.enable_streaming

        # Security overrides
        if env_config.security:
            config.security.enable_data_masking = env_config.security.enable_data_masking
            config.security.enable_encryption = env_config.security.enable_encryption
            config.security.audit_enabled = env_config.security.audit_enabled

        # OpenAI overrides
        if env_config.openai:
            config.openai.enabled = env_config.openai.enabled
            config.openai.model = env_config.openai.model
            config.openai.cache_size = env_config.openai.cache_size
            config.openai.cost_limit_usd = env_config.openai.cost_limit_usd

        # Validation overrides
        if env_config.validation:
            config.validation.strict_mode = env_config.validation.strict_mode
            config.validation.max_validation_errors = env_config.validation.max_validation_errors

        return config

    def _apply_environment_variables(self, config: GenerationConfig) -> GenerationConfig:
        """Apply environment variable overrides"""
        env_mappings = {
            'DG_ROWS': ('rows', int),
            'DG_LOCALE': ('locale', str),
            'DG_OUTPUT_DIR': ('output.directory', str),
            'DG_OUTPUT_FORMAT': ('output.format', str),
            'DG_MAX_WORKERS': ('performance.max_workers', int),
            'DG_BATCH_SIZE': ('performance.batch_size', int),
            'DG_MAX_MEMORY_MB': ('performance.max_memory_mb', int),
            'DG_ENABLE_MASKING': ('security.enable_data_masking', bool),
            'DG_ENABLE_ENCRYPTION': ('security.enable_encryption', bool),
            'DG_LOG_LEVEL': ('logging.level', str),
            'DG_DB_HOST': ('database.host', str),
            'DG_DB_PORT': ('database.port', int),
            'DG_DB_NAME': ('database.database', str),
            # OpenAI specific environment variables
            'DG_OPENAI_ENABLED': ('openai.enabled', bool),
            'DG_OPENAI_API_KEY': ('openai.api_key', str),
            'DG_OPENAI_MODEL': ('openai.model', str),
            'DG_OPENAI_MAX_TOKENS': ('openai.max_tokens', int),
            'DG_OPENAI_TEMPERATURE': ('openai.temperature', float),
            'DG_OPENAI_CACHE_SIZE': ('openai.cache_size', int),
            'DG_OPENAI_COST_LIMIT': ('openai.cost_limit_usd', float),
        }

        for env_var, (config_path, data_type) in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value:
                try:
                    # Convert value to appropriate type
                    if data_type == bool:
                        converted_value = env_value.lower() in ('true', '1', 'yes', 'on')
                    else:
                        converted_value = data_type(env_value)

                    # Set nested configuration value
                    self._set_nested_config_value(config, config_path, converted_value)

                except (ValueError, TypeError) as e:
                    self.logger.warning(f"Invalid environment variable {env_var}={env_value}: {e}")

        return config

    def _set_nested_config_value(self, config: GenerationConfig,
                                 config_path: str, value: Any):
        """Set nested configuration value using dot notation"""
        parts = config_path.split('.')
        current = config

        # Navigate to the parent object
        for part in parts[:-1]:
            current = getattr(current, part)

        # Set the final value
        setattr(current, parts[-1], value)

    # ===================== CONFIGURATION VALIDATION =====================

    def _validate_configuration(self, config: GenerationConfig):
        """Comprehensive configuration validation"""
        errors = []
        warnings = []

        # Basic validation
        if config.rows <= 0:
            errors.append("Rows must be positive")

        if not config.tables:
            warnings.append("No tables defined in configuration")

        # Performance validation
        if config.performance.max_workers <= 0:
            errors.append("Max workers must be positive")

        if config.performance.batch_size <= 0:
            errors.append("Batch size must be positive")

        if config.performance.max_memory_mb <= 0:
            errors.append("Max memory must be positive")

        # Output validation
        if not config.output.directory:
            errors.append("Output directory must be specified")

        if config.output.format not in ['csv', 'json', 'parquet', 'sql_query']:
            errors.append(f"Unsupported output format: {config.output.format}")

        # Database validation
        if config.database.port <= 0 or config.database.port > 65535:
            errors.append("Database port must be between 1 and 65535")

        # Security validation
        if config.security.enable_encryption and not config.security.encryption_key_file:
            warnings.append("Encryption enabled but no key file specified")

        # OpenAI validation
        self._validate_openai_config(config.openai, errors, warnings)

        # Validation settings validation
        if config.validation.quality_threshold < 0 or config.validation.quality_threshold > 1:
            errors.append("Quality threshold must be between 0 and 1")

        # Table schema validation
        for i, table in enumerate(config.tables):
            table_errors = self._validate_table_schema(table, i)
            errors.extend(table_errors)

        # Log results
        if warnings:
            for warning in warnings:
                self.logger.warning(f"Configuration warning: {warning}")

        if errors:
            error_msg = "Configuration validation failed:\n" + "\n".join(f"  - {error}" for error in errors)
            raise ValueError(error_msg)

        self.logger.info("Configuration validation passed")

    def _validate_openai_config(self, openai_config: OpenAIConfig, errors: List[str], warnings: List[str]):
        """Validate OpenAI configuration"""
        if not openai_config.enabled:
            return

        # Check API key availability
        api_key = openai_config.get_api_key()
        if not api_key:
            errors.append("OpenAI enabled but no API key found in config, file, or environment variable")
        elif len(api_key) < 20:  # Basic sanity check
            warnings.append("OpenAI API key seems too short, please verify")

        # Validate model name
        valid_models = [
            'gpt-3.5-turbo', 'gpt-3.5-turbo-16k',
            'gpt-4', 'gpt-4-turbo-preview', 'gpt-4-32k'
        ]
        if openai_config.model not in valid_models:
            warnings.append(f"Unknown OpenAI model '{openai_config.model}', may not be supported")

        # Validate numeric parameters
        if openai_config.max_tokens <= 0:
            errors.append("OpenAI max_tokens must be positive")
        elif openai_config.max_tokens > 4096:
            warnings.append("OpenAI max_tokens > 4096 may be expensive and slow")

        if not (0.0 <= openai_config.temperature <= 2.0):
            errors.append("OpenAI temperature must be between 0.0 and 2.0")

        if openai_config.cache_size <= 0:
            errors.append("OpenAI cache_size must be positive")
        elif openai_config.cache_size > 1000:
            warnings.append("Large OpenAI cache_size may consume significant memory")

        if openai_config.timeout_seconds <= 0:
            errors.append("OpenAI timeout_seconds must be positive")

        if openai_config.retry_attempts < 0:
            errors.append("OpenAI retry_attempts cannot be negative")

        # Cost limit validation
        if openai_config.cost_limit_usd is not None:
            if openai_config.cost_limit_usd <= 0:
                errors.append("OpenAI cost_limit_usd must be positive if specified")
            elif openai_config.cost_limit_usd < 1.0:
                warnings.append("Very low OpenAI cost limit may restrict functionality")

        # Check file path if specified
        if openai_config.api_key_file:
            if not os.path.exists(openai_config.api_key_file):
                errors.append(f"OpenAI API key file not found: {openai_config.api_key_file}")
            else:
                # Check file permissions
                try:
                    with open(openai_config.api_key_file, 'r') as f:
                        content = f.read().strip()
                        if not content:
                            warnings.append("OpenAI API key file is empty")
                except PermissionError:
                    errors.append(f"Cannot read OpenAI API key file: {openai_config.api_key_file}")

    def _validate_table_schema(self, table: Dict[str, Any], table_index: int) -> List[str]:
        """Validate individual table schema"""
        errors = []

        if 'table_name' not in table:
            errors.append(f"Table {table_index}: Missing table_name")

        if 'columns' not in table:
            errors.append(f"Table {table_index}: Missing columns")
            return errors

        if not isinstance(table['columns'], list):
            errors.append(f"Table {table_index}: Columns must be a list")
            return errors

        # Validate columns
        column_names = set()
        for j, column in enumerate(table['columns']):
            if not isinstance(column, dict):
                errors.append(f"Table {table_index}, Column {j}: Must be a dictionary")
                continue

            if 'name' not in column:
                errors.append(f"Table {table_index}, Column {j}: Missing name")
                continue

            column_name = column['name']
            if column_name in column_names:
                errors.append(f"Table {table_index}: Duplicate column name '{column_name}'")
            column_names.add(column_name)

            if 'type' not in column:
                errors.append(f"Table {table_index}, Column '{column_name}': Missing type")

        return errors

    # ===================== OPENAI UTILITIES =====================

    def test_openai_connection(self, config: GenerationConfig) -> Dict[str, Any]:
        """Test OpenAI connection and return status"""
        if not config.openai.enabled:
            return {
                'status': 'disabled',
                'message': 'OpenAI integration is disabled in configuration'
            }

        api_key = config.openai.get_api_key()
        if not api_key:
            return {
                'status': 'error',
                'message': 'No API key found'
            }

        try:
            # Try to import openai
            import openai

            # Set API key
            openai.api_key = api_key

            # Test with a simple completion
            response = openai.ChatCompletion.create(
                model=config.openai.model,
                messages=[{"role": "user", "content": "Test connection"}],
                max_tokens=10,
                timeout=config.openai.timeout_seconds
            )

            return {
                'status': 'success',
                'message': 'OpenAI connection successful',
                'model': config.openai.model,
                'response_id': response.get('id', 'unknown')
            }

        except ImportError:
            return {
                'status': 'error',
                'message': 'OpenAI package not installed. Run: pip install openai'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': f'OpenAI connection failed: {str(e)}'
            }

    def get_openai_status(self, config: GenerationConfig) -> Dict[str, Any]:
        """Get comprehensive OpenAI configuration status"""
        openai_config = config.openai

        status = {
            'enabled': openai_config.enabled,
            'api_key_source': None,
            'api_key_available': False,
            'model': openai_config.model,
            'cache_size': openai_config.cache_size,
            'cost_limit_usd': openai_config.cost_limit_usd,
            'configuration_valid': True,
            'errors': [],
            'warnings': []
        }

        if openai_config.enabled:
            # Check API key source
            if openai_config.api_key:
                status['api_key_source'] = 'direct_config'
                status['api_key_available'] = True
            elif openai_config.api_key_file and os.path.exists(openai_config.api_key_file):
                status['api_key_source'] = 'file'
                try:
                    with open(openai_config.api_key_file, 'r') as f:
                        content = f.read().strip()
                        status['api_key_available'] = bool(content)
                except:
                    status['api_key_available'] = False
            elif os.getenv(openai_config.api_key_env_var):
                status['api_key_source'] = 'environment_variable'
                status['api_key_available'] = True
            else:
                status['api_key_source'] = 'none'
                status['api_key_available'] = False
                status['errors'].append('No API key found')

            # Validate configuration
            if not status['api_key_available']:
                status['configuration_valid'] = False

            # Test connection if requested
            if status['api_key_available']:
                connection_test = self.test_openai_connection(config)
                status['connection_test'] = connection_test
                if connection_test['status'] != 'success':
                    status['configuration_valid'] = False

        return status

    # ===================== CONFIGURATION TEMPLATES WITH OPENAI =====================

    def generate_config_template_with_openai(self, table_schemas: List[Dict[str, Any]],
                                             template_type: str = "basic",
                                             enable_openai: bool = False) -> GenerationConfig:
        """Generate configuration template with OpenAI settings"""
        config = self.generate_config_template(table_schemas, template_type)

        if enable_openai:
            if template_type == "basic":
                config.openai = OpenAIConfig(
                    enabled=True,
                    model="gpt-3.5-turbo",
                    cache_size=50,
                    cost_limit_usd=5.0
                )
            elif template_type == "advanced":
                config.openai = OpenAIConfig(
                    enabled=True,
                    model="gpt-3.5-turbo",
                    cache_size=100,
                    cost_limit_usd=15.0,
                    temperature=0.7,
                    timeout_seconds=45
                )
            elif template_type == "production":
                config.openai = OpenAIConfig(
                    enabled=True,
                    model="gpt-3.5-turbo",
                    cache_size=200,
                    cost_limit_usd=100.0,
                    temperature=0.5,
                    timeout_seconds=60,
                    retry_attempts=5,
                    fallback_enabled=True
                )

        return config

    # ===================== CONFIGURATION SAVING WITH OPENAI =====================

    def save_configuration(self, config: GenerationConfig,
                           output_path: str, format: str = 'json',
                           include_sensitive: bool = False):
        """Save configuration to file with option to exclude sensitive data"""
        output_path = Path(output_path)

        # Convert config to dictionary
        config_dict = self._config_to_dict(config, include_sensitive)

        self._save_json(config_dict, output_path)

        self.logger.info(f"Configuration saved to: {output_path}")

    def _config_to_dict(self, config: GenerationConfig, include_sensitive: bool = False) -> Dict[str, Any]:
        """Convert configuration object to dictionary with option to exclude sensitive data"""
        config_dict = {}

        # Main fields
        config_dict['environment'] = config.environment
        config_dict['locale'] = config.locale
        config_dict['rows'] = config.rows
        config_dict['tables'] = config.tables

        # Sub-configurations
        if config.database:
            db_config = asdict(config.database)
            if not include_sensitive:
                db_config['password'] = '[HIDDEN]'
            config_dict['database'] = db_config

        if config.performance:
            config_dict['performance'] = asdict(config.performance)

        if config.security:
            sec_config = asdict(config.security)
            if not include_sensitive and sec_config.get('encryption_key_file'):
                sec_config['encryption_key_file'] = '[HIDDEN]'
            config_dict['security'] = sec_config

        if config.openai:
            openai_config = asdict(config.openai)
            if not include_sensitive:
                # Hide sensitive OpenAI data
                if openai_config.get('api_key'):
                    openai_config['api_key'] = '[HIDDEN]'
                if openai_config.get('api_key_file'):
                    openai_config['api_key_file'] = '[HIDDEN]'
            config_dict['openai'] = openai_config

        if config.output:
            config_dict['output'] = asdict(config.output)

        if config.validation:
            config_dict['validation'] = asdict(config.validation)

        if config.logging:
            config_dict['logging'] = asdict(config.logging)

        return config_dict

    # ===================== ENHANCED CONFIGURATION WIZARD =====================

    def create_config_wizard_with_openai(self) -> GenerationConfig:
        """Interactive configuration wizard with OpenAI options"""
        print("=== Enhanced Data Generator Configuration Wizard ===")
        print("This wizard will help you create a configuration file with OpenAI support.")
        print()

        # Basic settings
        environment = input("Environment (development/testing/production) [development]: ").strip() or "development"
        rows = int(input("Number of rows to generate [1000]: ").strip() or "1000")
        locale = input("Locale [en_GB]: ").strip() or "en_GB"

        # Output settings
        output_format = input("Output format (csv/json/parquet) [csv]: ").strip() or "csv"
        output_dir = input("Output directory [./output]: ").strip() or "./output"

        # Performance settings
        max_workers = int(input("Max workers [4]: ").strip() or "4")
        batch_size = int(input("Batch size [10000]: ").strip() or "10000")

        # Security settings
        enable_masking = input("Enable data masking (y/n) [n]: ").strip().lower() in ['y', 'yes']
        audit_enabled = input("Enable audit logging (y/n) [y]: ").strip().lower() in ['y', 'yes', '']

        # OpenAI settings
        print("\n--- OpenAI Integration Settings ---")
        enable_openai = input("Enable OpenAI integration (y/n) [n]: ").strip().lower() in ['y', 'yes']

        openai_config = OpenAIConfig()
        if enable_openai:
            print("OpenAI API Key Configuration:")
            print("1. Enter API key directly (not recommended for production)")
            print("2. Use environment variable OPENAI_API_KEY")
            print("3. Use API key file")

            key_method = input("Choose method (1/2/3) [2]: ").strip() or "2"

            if key_method == "1":
                api_key = input("Enter OpenAI API key: ").strip()
                openai_config.api_key = api_key if api_key else None
            elif key_method == "3":
                key_file = input("Path to API key file: ").strip()
                openai_config.api_key_file = key_file if key_file else None
            # For method 2, we keep default environment variable

            model = input("OpenAI model [gpt-3.5-turbo]: ").strip() or "gpt-3.5-turbo"
            cache_size = int(input("Cache size [100]: ").strip() or "100")
            cost_limit = input("Cost limit in USD [10.0]: ").strip()

            openai_config.enabled = True
            openai_config.model = model
            openai_config.cache_size = cache_size
            openai_config.cost_limit_usd = float(cost_limit) if cost_limit else 10.0

        # Create configuration
        config = GenerationConfig(
            environment=environment,
            rows=rows,
            locale=locale,
            performance=PerformanceConfig(
                max_workers=max_workers,
                batch_size=batch_size
            ),
            security=SecurityConfig(
                enable_data_masking=enable_masking,
                audit_enabled=audit_enabled
            ),
            openai=openai_config,
            output=OutputConfig(
                format=output_format,
                directory=output_dir
            )
        )

        print("\n=== Configuration Created Successfully ===")

        # Show OpenAI status
        if enable_openai:
            print("\n--- OpenAI Configuration Status ---")
            openai_status = self.get_openai_status(config)
            print(f"Enabled: {openai_status['enabled']}")
            print(f"API Key Source: {openai_status['api_key_source']}")
            print(f"API Key Available: {openai_status['api_key_available']}")
            print(f"Model: {openai_status['model']}")
            print(f"Configuration Valid: {openai_status['configuration_valid']}")

            if openai_status['errors']:
                print("Errors:")
                for error in openai_status['errors']:
                    print(f"  - {error}")

            if openai_status['warnings']:
                print("Warnings:")
                for warning in openai_status['warnings']:
                    print(f"  - {warning}")

        return config

    def generate_config_template(self, table_schemas: List[Dict[str, Any]],
                                 template_type: str = "basic") -> GenerationConfig:
        """Generate configuration template from table schemas"""
        if template_type == "basic":
            return self._generate_basic_template(table_schemas)
        elif template_type == "advanced":
            return self._generate_advanced_template(table_schemas)
        elif template_type == "production":
            return self._generate_production_template(table_schemas)
        else:
            raise ValueError(f"Unknown template type: {template_type}")

    def _generate_basic_template(self, table_schemas: List[Dict[str, Any]]) -> GenerationConfig:
        """Generate basic configuration template"""
        tables = []

        for schema in table_schemas:
            table = {
                'table_name': schema.get('name', 'unnamed_table'),
                'columns': []
            }

            # Generate columns from schema
            for column_info in schema.get('columns', []):
                column = {
                    'name': column_info.get('name'),
                    'type': self._map_database_type_to_generator_type(column_info.get('type')),
                    'nullable': column_info.get('nullable', True)
                }

                # Add constraints
                if column_info.get('primary_key'):
                    column['constraints'] = ['PK']

                # Add basic rules based on column name and type
                rule = self._infer_rule_from_column(column_info)
                if rule:
                    column['rule'] = rule

                table['columns'].append(column)

            tables.append(table)

        return GenerationConfig(
            environment=Environment.DEVELOPMENT.value,
            tables=tables,
            rows=1000,
            openai=OpenAIConfig(enabled=False)  # Default disabled for basic template
        )

    def _generate_advanced_template(self, table_schemas: List[Dict[str, Any]]) -> GenerationConfig:
        """Generate advanced configuration template with more features"""
        config = self._generate_basic_template(table_schemas)

        # Enhanced performance settings
        config.performance = PerformanceConfig(
            max_workers=4,
            batch_size=10000,
            enable_parallel=True,
            enable_streaming=True
        )

        # Enhanced security settings
        config.security = SecurityConfig(
            enable_data_masking=True,
            audit_enabled=True
        )

        # Enhanced validation
        config.validation = ValidationConfig(
            strict_mode=True,
            enable_data_quality_analysis=True,
            enable_anomaly_detection=True
        )

        # OpenAI enabled with moderate settings
        config.openai = OpenAIConfig(
            enabled=True,
            model="gpt-3.5-turbo",
            cache_size=100,
            cost_limit_usd=15.0
        )

        # Add foreign key relationships
        self._infer_foreign_keys(config.tables)

        return config

    def _generate_production_template(self, table_schemas: List[Dict[str, Any]]) -> GenerationConfig:
        """Generate production-ready configuration template"""
        config = self._generate_advanced_template(table_schemas)

        config.environment = Environment.PRODUCTION.value
        config.rows = 100000

        # Production performance settings
        config.performance = PerformanceConfig(
            max_workers=8,
            batch_size=50000,
            max_memory_mb=4000,
            enable_parallel=True,
            enable_streaming=True
        )

        # Production security settings
        config.security = SecurityConfig(
            enable_data_masking=True,
            enable_encryption=True,
            audit_enabled=True
        )

        # Production validation
        config.validation = ValidationConfig(
            strict_mode=True,
            max_validation_errors=0,
            quality_threshold=0.95,
            enable_data_quality_analysis=True,
            enable_anomaly_detection=True
        )

        # Production OpenAI settings
        config.openai = OpenAIConfig(
            enabled=True,
            model="gpt-3.5-turbo",
            cache_size=200,
            cost_limit_usd=100.0,
            temperature=0.5,
            timeout_seconds=60,
            retry_attempts=5,
            fallback_enabled=True
        )

        # Production output settings
        config.output = OutputConfig(
            format="parquet",
            compression="snappy",
            directory="./production_output"
        )

        return config

    def _map_database_type_to_generator_type(self, db_type: str) -> str:
        """Map database types to generator types"""
        if not db_type:
            return 'str'

        db_type_lower = db_type.lower()

        type_mapping = {
            'integer': 'int',
            'int': 'int',
            'bigint': 'int',
            'smallint': 'int',
            'decimal': 'float',
            'numeric': 'float',
            'real': 'float',
            'double': 'float',
            'varchar': 'str',
            'char': 'str',
            'text': 'str',
            'string': 'str',
            'boolean': 'bool',
            'bool': 'bool',
            'date': 'date',
            'datetime': 'datetime',
            'timestamp': 'datetime',
            'uuid': 'uuid'
        }

        for db_type_pattern, generator_type in type_mapping.items():
            if db_type_pattern in db_type_lower:
                return generator_type

        return 'str'  # Default to string

    def _infer_rule_from_column(self, column_info: Dict[str, Any]) -> Union[
        dict[str, str], dict[str, str], str, dict[str, Union[str, int]], dict[str, str], dict[str, Union[str, int]],
        dict[str, str], dict[str, Union[str, list[str]]], None]:
        """Infer generation rule from column information"""
        column_name = column_info.get('name', '').lower()
        column_type = column_info.get('type', '').lower()

        # Email detection
        if 'email' in column_name:
            return {'type': 'email'}

        # Phone detection
        if 'phone' in column_name:
            return {'type': 'phone_number'}

        # Name detection
        if any(name_part in column_name for name_part in ['first_name', 'last_name', 'name']):
            return 'name'

        # Age detection
        if 'age' in column_name:
            return {'type': 'range', 'min': 18, 'max': 80}

        # Date detection
        if any(date_part in column_name for date_part in ['date', 'created', 'updated', 'birth']):
            return {'type': 'date_range', 'start': '2020-01-01', 'end': '2024-12-31'}

        # ID detection
        if column_name.endswith('_id') or column_name == 'id':
            if 'int' in column_type:
                return {'type': 'range', 'min': 1, 'max': 999999}
            else:
                return {'type': 'uuid'}

        # Status/Category detection
        if any(status_part in column_name for status_part in ['status', 'type', 'category']):
            return {'type': 'choice', 'value': ['ACTIVE', 'INACTIVE', 'PENDING']}

        return None

    def _infer_foreign_keys(self, tables: List[Dict[str, Any]]):
        """Infer foreign key relationships between tables"""
        # Build table and column registry
        table_columns = {}
        for table in tables:
            table_name = table['table_name']
            table_columns[table_name] = [col['name'] for col in table['columns']]

        # Look for foreign key patterns
        for table in tables:
            foreign_keys = []

            for column in table['columns']:
                column_name = column['name']

                # Look for foreign key pattern (table_name_id -> table_name.id)
                if column_name.endswith('_id') and column_name != 'id':
                    potential_table = column_name[:-3]  # Remove '_id'

                    # Check if table exists and has 'id' column
                    if potential_table in table_columns and 'id' in table_columns[potential_table]:
                        foreign_keys.append({
                            'parent_table': potential_table,
                            'parent_column': 'id',
                            'child_column': column_name
                        })

            if foreign_keys:
                table['foreign_keys'] = foreign_keys

    def _save_json(self, config_dict: Dict[str, Any], output_path: Path):
        """Save configuration as JSON"""
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(config_dict, f, indent=2, ensure_ascii=False)

    # ===================== CONFIGURATION UTILITIES =====================

    @contextmanager
    def temporary_config(self, config: GenerationConfig):
        """Context manager for temporary configuration changes"""
        temp_file = None
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                temp_file = f.name

            # Save configuration to temp file
            self.save_configuration(config, temp_file, 'json')

            yield temp_file
        finally:
            # Clean up temp file
            if temp_file and os.path.exists(temp_file):
                os.unlink(temp_file)

    def merge_configurations(self, base_config: GenerationConfig,
                             override_config: GenerationConfig) -> GenerationConfig:
        """Merge two configurations with override taking precedence"""
        # Convert to dictionaries for easier merging
        base_dict = self._config_to_dict(base_config)
        override_dict = self._config_to_dict(override_config)

        # Deep merge dictionaries
        merged_dict = self._deep_merge_dicts(base_dict, override_dict)

        # Convert back to configuration object
        return self._parse_config_dict(merged_dict)

    def _deep_merge_dicts(self, base: Dict[str, Any],
                          override: Dict[str, Any]) -> Dict[str, Any]:
        """Deep merge two dictionaries"""
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge_dicts(result[key], value)
            else:
                result[key] = value

        return result

    def validate_environment_config(self, environment: str) -> bool:
        """Validate if environment configuration is available"""
        return environment in self.environment_configs

    def list_available_environments(self) -> List[str]:
        """List all available environment configurations"""
        return list(self.environment_configs.keys())

    def get_config_summary(self, config: GenerationConfig) -> Dict[str, Any]:
        """Get a summary of configuration settings"""
        return {
            'environment': config.environment,
            'total_tables': len(config.tables),
            'total_rows': config.rows,
            'output_format': config.output.format,
            'performance': {
                'max_workers': config.performance.max_workers,
                'batch_size': config.performance.batch_size,
                'streaming_enabled': config.performance.enable_streaming,
                'parallel_enabled': config.performance.enable_parallel
            },
            'security': {
                'masking_enabled': config.security.enable_data_masking,
                'encryption_enabled': config.security.enable_encryption,
                'audit_enabled': config.security.audit_enabled
            },
            'openai': {
                'enabled': config.openai.enabled,
                'model': config.openai.model if config.openai.enabled else None,
                'api_key_available': config.openai.is_available(),
                'cache_size': config.openai.cache_size,
                'cost_limit_usd': config.openai.cost_limit_usd
            },
            'validation': {
                'strict_mode': config.validation.strict_mode,
                'quality_analysis': config.validation.enable_data_quality_analysis
            }
        }

    def _parse_security_config(self, config_dict: Dict[str, Any]) -> SecurityConfig:
        """Parse security configuration with proper error handling"""
        try:
            security_data = config_dict.get('security', {})

            # Handle the case where security is a boolean (legacy)
            if isinstance(security_data, bool):
                return SecurityConfig(enable_data_masking=security_data)

            # Handle dictionary configuration
            if isinstance(security_data, dict):
                return SecurityConfig.from_dict(security_data)

            # Default security config
            return SecurityConfig()

        except TypeError as e:
            # More helpful error message
            available_params = [
                'enable_data_masking', 'enable_encryption', 'audit_enabled',
                'masking_rules', 'sensitivity_map', 'encrypt_fields'
            ]

            raise TypeError(
                f"Invalid security configuration parameter. "
                f"Available parameters: {available_params}. "
                f"Original error: {e}"
            )
