import random
import json
import io
import sys
import rstr
import csv
from faker import Faker
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Any

from validators.unified_validation_system import UnifiedValidator

try:
    import openai

    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    print("Warning: OpenAI package not available. AI fallback will be disabled.")


class ValueGenerator:
    """Enhanced ValueGenerator with configurable OpenAI integration"""

    def __init__(self, faker: Faker, logger: logging.Logger, openai_config=None):
        self.faker = faker
        self.logger = logger
        self.openai_config = openai_config

        # OpenAI configuration and initialization
        self.openai_enabled = False
        self.openai_client = None

        if openai_config and OPENAI_AVAILABLE:
            self._initialize_openai(openai_config)

        # Cache for OpenAI generated data
        self._openai_cache = {}  # cache_key -> list of values
        self._cache_usage_count = {}  # cache_key -> current usage index
        self._default_cache_size = 100  # Default cache size
        self._cost_tracker = 0.0  # Track estimated costs

        # Performance tracking
        self._openai_requests = 0
        self._openai_cache_hits = 0
        self._openai_failures = 0

    def _initialize_openai(self, openai_config):
        """Initialize OpenAI with configuration"""
        try:
            # Check if OpenAI is enabled in config
            if not openai_config.enabled:
                self.logger.info("OpenAI integration is disabled in configuration")
                return

            # Get API key from configuration
            api_key = openai_config.get_api_key()
            if not api_key:
                self.logger.warning("OpenAI enabled but no API key available")
                return

            # Set up OpenAI client
            openai.api_key = api_key

            # Update cache size from config
            self._default_cache_size = openai_config.cache_size

            # Test connection
            try:
                # Simple test to verify API key works
                test_response = openai.ChatCompletion.create(
                    model=openai_config.model,
                    messages=[{"role": "user", "content": "Test"}],
                    max_tokens=1,
                    timeout=openai_config.timeout_seconds
                )

                self.openai_enabled = True
                self.logger.info(f"OpenAI initialized successfully with model: {openai_config.model}")

            except Exception as e:
                self.logger.error(f"OpenAI connection test failed: {e}")
                self.openai_enabled = False

        except Exception as e:
            self.logger.error(f"Failed to initialize OpenAI: {e}")
            self.openai_enabled = False

    def generate_by_rule(self, rule: Any, data_type: str, column_name: str = "generated_column") -> Any:
        """Main entry point for value generation with OpenAI support"""
        if isinstance(rule, str):
            result = self._generate_from_string_rule(rule)
            if result is not None:
                return result
        elif isinstance(rule, dict):
            # Check if this is an OpenAI generation rule
            if rule.get("type") == "openai_generated":
                return self._generate_with_openai_rule(rule, data_type, column_name)
            else:
                result = self._generate_from_dict_rule(rule, data_type)
                if result is not None:
                    return result

        result = self._generate_default_by_type(data_type)
        if result is not None:
            return result

        # Final fallback to OpenAI if enabled and no other method worked
        if self.openai_enabled and self.openai_config.fallback_enabled:
            return self._generate_with_openai_fallback(rule, data_type, column_name)

        # Ultimate fallback
        return self._ultimate_fallback(data_type)

    def _generate_with_openai_rule(self, rule: Dict[str, Any], data_type: str, column_name: str) -> Any:
        """Generate value using OpenAI with specific rule configuration"""
        if not self.openai_enabled:
            self.logger.warning(f"OpenAI rule specified for {column_name} but OpenAI not available")
            return self._ultimate_fallback(data_type)

        try:
            # Check cost limit
            if self._check_cost_limit():
                self.logger.warning("OpenAI cost limit reached, falling back to default generation")
                return self._ultimate_fallback(data_type)

            # Create cache key based on rule
            cache_key = self._create_cache_key_for_rule(rule, data_type, column_name)

            # Check if we have cached data
            if cache_key in self._openai_cache:
                self._openai_cache_hits += 1
                return self._get_cached_value(cache_key)

            # Generate new batch of data via OpenAI
            self._generate_and_cache_openai_data_from_rule(rule, data_type, column_name, cache_key)

            # Return first value from cache
            return self._get_cached_value(cache_key)

        except Exception as e:
            self.logger.warning(f"OpenAI rule generation failed for {column_name}: {e}")
            self._openai_failures += 1
            return self._ultimate_fallback(data_type)

    def _generate_with_openai_fallback(self, rule: Any, data_type: str, column_name: str = "generated_column") -> Any:
        """Generate value using OpenAI as fallback with caching"""
        if not self.openai_enabled:
            return self._ultimate_fallback(data_type)

        try:
            # Check cost limit
            if self._check_cost_limit():
                return self._ultimate_fallback(data_type)

            # Create cache key based on rule and data type
            cache_key = self._create_cache_key(rule, data_type, column_name)

            # Check if we have cached data
            if cache_key in self._openai_cache:
                self._openai_cache_hits += 1
                return self._get_cached_value(cache_key)

            # Generate new batch of data via OpenAI
            self._generate_and_cache_openai_data(rule, data_type, column_name, cache_key)

            # Return first value from cache
            return self._get_cached_value(cache_key)

        except Exception as e:
            self.logger.warning(f"OpenAI fallback failed: {e}")
            self._openai_failures += 1
            return self._ultimate_fallback(data_type)

    def _check_cost_limit(self) -> bool:
        """Check if we've exceeded the cost limit"""
        if not self.openai_config.cost_limit_usd:
            return False
        return self._cost_tracker >= self.openai_config.cost_limit_usd

    def _create_cache_key(self, rule: Any, data_type: str, column_name: str) -> str:
        """Create a unique cache key for the rule/data type combination"""
        rule_str = json.dumps(rule, sort_keys=True) if isinstance(rule, dict) else str(rule)
        return f"{column_name}_{data_type}_{hash(rule_str)}"

    def _create_cache_key_for_rule(self, rule: Dict[str, Any], data_type: str, column_name: str) -> str:
        """Create cache key specifically for OpenAI rules"""
        # Include description and context in cache key
        description = rule.get("description", "")
        context_columns = rule.get("context_columns", [])
        max_length = rule.get("max_length", 100)

        key_components = [column_name, data_type, description, str(context_columns), str(max_length)]
        return f"openai_{hash('_'.join(key_components))}"

    def _get_cached_value(self, cache_key: str) -> Any:
        """Get next value from cache, cycling through available values"""
        if cache_key not in self._openai_cache or not self._openai_cache[cache_key]:
            return self._ultimate_fallback("str")

        # Get current usage index
        current_index = self._cache_usage_count.get(cache_key, 0)
        cached_values = self._openai_cache[cache_key]

        # Cycle through cached values
        value = cached_values[current_index % len(cached_values)]

        # Update usage count
        self._cache_usage_count[cache_key] = current_index + 1

        return value

    def _generate_and_cache_openai_data_from_rule(self, rule: Dict[str, Any], data_type: str,
                                                  column_name: str, cache_key: str):
        """Generate and cache data using OpenAI with specific rule"""
        column_metadata = self._prepare_column_metadata_from_rule(rule, data_type, column_name)

        try:
            csv_data = self._get_synthetic_csv(column_metadata)
            parsed_values = self._parse_csv_response(csv_data, column_name, data_type)

            if parsed_values:
                self._openai_cache[cache_key] = parsed_values
                self._cache_usage_count[cache_key] = 0
                self.logger.info(f"Cached {len(parsed_values)} OpenAI values for {cache_key}")

                # Track costs (rough estimate)
                self._estimate_and_track_cost(column_metadata)

            else:
                self.logger.warning(f"No valid data received from OpenAI for {cache_key}")

        except Exception as e:
            self.logger.error(f"Failed to generate data via OpenAI: {e}")
            raise

    def _generate_and_cache_openai_data(self, rule: Any, data_type: str,
                                        column_name: str, cache_key: str):
        """Generate and cache data using OpenAI (fallback method)"""
        column_metadata = self._prepare_column_metadata(rule, data_type, column_name)

        try:
            csv_data = self._get_synthetic_csv(column_metadata)
            parsed_values = self._parse_csv_response(csv_data, column_name, data_type)

            if parsed_values:
                self._openai_cache[cache_key] = parsed_values
                self._cache_usage_count[cache_key] = 0
                self.logger.info(f"Cached {len(parsed_values)} values for {cache_key}")

                # Track costs
                self._estimate_and_track_cost(column_metadata)

            else:
                self.logger.warning(f"No valid data received from OpenAI for {cache_key}")

        except Exception as e:
            self.logger.error(f"Failed to generate data via OpenAI: {e}")
            raise

    def _prepare_column_metadata_from_rule(self, rule: Dict[str, Any], data_type: str, column_name: str) -> dict:
        """Prepare column metadata from OpenAI rule"""
        metadata = {
            "name": column_name,
            "type": data_type,
            "how_much": self._default_cache_size,
            "description": rule.get("description", f"Generate {data_type} data"),
            "context_columns": rule.get("context_columns", []),
            "max_length": rule.get("max_length", 100),
            "generation_type": "rule_based"
        }

        return metadata

    def _prepare_column_metadata(self, rule: Any, data_type: str, column_name: str) -> dict:
        """Prepare column metadata for OpenAI prompt (fallback)"""
        metadata = {
            "name": column_name,
            "type": data_type,
            "how_much": self._default_cache_size,
            "generation_type": "fallback"
        }

        # Add rule information
        if isinstance(rule, str):
            metadata["rule"] = rule
            metadata["description"] = f"Generate {data_type} data following rule: {rule}"
        elif isinstance(rule, dict):
            metadata["rule"] = rule
            if "description" in rule:
                metadata["description"] = rule["description"]
            else:
                metadata["description"] = f"Generate {data_type} data with complex rule"
        else:
            metadata["description"] = f"Generate random {data_type} data"

        return metadata

    def _generate_prompt(self, column_metadata: dict) -> str:
        """Generate prompt for OpenAI"""
        if column_metadata.get("generation_type") == "rule_based":
            return self._generate_rule_based_prompt(column_metadata)
        else:
            return self._generate_fallback_prompt(column_metadata)

    def _generate_rule_based_prompt(self, column_metadata: dict) -> str:
        """Generate prompt for rule-based OpenAI generation"""
        description = column_metadata.get("description", "")
        context_columns = column_metadata.get("context_columns", [])
        max_length = column_metadata.get("max_length", 100)
        column_name = column_metadata.get("name", "column")
        data_type = column_metadata.get("type", "str")
        count = column_metadata.get("how_much", 100)

        prompt = f"""
You are a synthetic data generator. Generate {count} realistic values for a column named '{column_name}' of type '{data_type}'.

Requirements:
- {description}
- Maximum length: {max_length} characters
- Return ONLY a CSV with header '{column_name}' and {count} data rows
- No explanations, no markdown formatting
- Each value should be realistic and diverse

"""

        if context_columns:
            prompt += f"Consider that this column relates to: {', '.join(context_columns)}\n"

        prompt += f"\nGenerate {count} diverse, realistic values now:"

        return prompt.strip()

    def _generate_fallback_prompt(self, column_metadata: dict) -> str:
        """Generate prompt for fallback OpenAI generation"""
        return f"""
You are a synthetic data generator. I will give you a JSON containing column metadata. 
You need to return only synthetic CSV data for that column with the specified number of rows. 
The CSV should contain only the header (column name) and synthetic data, and nothing else — no explanations, no markdown.

Here's the input JSON:
{json.dumps(column_metadata, indent=2)}

Now generate the data accordingly.
""".strip()

    def _get_synthetic_csv(self, column_metadata: dict) -> str:
        """Get synthetic CSV data from OpenAI"""
        prompt = self._generate_prompt(column_metadata)

        self._openai_requests += 1

        try:
            response = openai.ChatCompletion.create(
                model=self.openai_config.model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=self.openai_config.temperature,
                max_tokens=self.openai_config.max_tokens,
                timeout=self.openai_config.timeout_seconds
            )

            return response['choices'][0]['message']['content'].strip()

        except Exception as e:
            # Retry logic
            if self._openai_requests <= self.openai_config.retry_attempts:
                self.logger.warning(
                    f"OpenAI request failed, retrying... ({self._openai_requests}/{self.openai_config.retry_attempts})")
                return self._get_synthetic_csv(column_metadata)
            else:
                raise e

    def _estimate_and_track_cost(self, column_metadata: dict):
        """Estimate and track OpenAI API costs"""
        # Rough cost estimation (these are approximate rates)
        model = self.openai_config.model

        # Estimated tokens used (prompt + response)
        estimated_prompt_tokens = len(str(column_metadata)) // 4  # Rough estimate
        estimated_response_tokens = column_metadata.get("how_much", 100) * 10  # Rough estimate

        # Cost per 1K tokens (approximate, as of 2024)
        cost_per_1k_tokens = {
            "gpt-3.5-turbo": 0.002,
            "gpt-4": 0.03,
            "gpt-4-turbo-preview": 0.01
        }

        rate = cost_per_1k_tokens.get(model, 0.002)
        estimated_cost = ((estimated_prompt_tokens + estimated_response_tokens) / 1000) * rate

        self._cost_tracker += estimated_cost

        self.logger.debug(f"Estimated OpenAI cost: ${estimated_cost:.4f} (Total: ${self._cost_tracker:.4f})")

    def _parse_csv_response(self, csv_data: str, column_name: str, data_type: str) -> List[Any]:
        """Parse CSV response and convert to appropriate data types"""
        try:
            # Use StringIO to parse CSV data
            csv_file = io.StringIO(csv_data)
            reader = csv.DictReader(csv_file)

            values = []
            for row in reader:
                # Get value from the expected column or first available column
                value = row.get(column_name) or next(iter(row.values()), None)
                if value is not None:
                    # Convert to appropriate type
                    converted_value = self._convert_openai_value(value, data_type)
                    if converted_value is not None:
                        values.append(converted_value)

            return values

        except Exception as e:
            self.logger.warning(f"Failed to parse CSV response: {e}")
            # Try simple line-by-line parsing as fallback
            return self._parse_simple_response(csv_data, data_type)

    def _parse_simple_response(self, response_data: str, data_type: str) -> List[Any]:
        """Simple fallback parser for non-CSV responses"""
        lines = response_data.strip().split('\n')
        values = []

        # Skip header line if it looks like a header
        start_idx = 1 if lines and any(word in lines[0].lower()
                                       for word in ['name', 'column', 'header']) else 0

        for line in lines[start_idx:]:
            line = line.strip()
            if line and not line.startswith('#'):  # Skip comments
                converted_value = self._convert_openai_value(line, data_type)
                if converted_value is not None:
                    values.append(converted_value)

        return values

    def _convert_openai_value(self, value: str, data_type: str) -> Any:
        """Convert OpenAI generated value to appropriate data type"""
        if not value or value.lower() in ['null', 'none', '']:
            return None

        try:
            if data_type.lower() in ['int', 'integer']:
                # Extract numeric part from string if needed
                import re
                numeric_match = re.search(r'-?\d+', str(value))
                if numeric_match:
                    return int(numeric_match.group())
                return int(value)

            elif data_type.lower() in ['float', 'double', 'decimal']:
                import re
                numeric_match = re.search(r'-?\d+\.?\d*', str(value))
                if numeric_match:
                    return float(numeric_match.group())
                return float(value)

            elif data_type.lower() in ['bool', 'boolean']:
                return str(value).lower() in ['true', '1', 'yes', 'on']

            elif data_type.lower() in ['date']:
                # Try to parse date
                for date_format in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                    try:
                        return datetime.strptime(str(value), date_format).date()
                    except ValueError:
                        continue
                return str(value)  # Return as string if parsing fails

            else:
                return str(value).strip('"\'')  # Remove quotes if present

        except (ValueError, TypeError):
            return str(value)  # Fallback to string

    def _ultimate_fallback(self, data_type: str) -> Any:
        """Ultimate fallback when all else fails"""
        fallbacks = {
            "int": lambda: random.randint(1, 1000),
            "integer": lambda: random.randint(1, 1000),
            "float": lambda: round(random.uniform(1.0, 100.0), 2),
            "double": lambda: round(random.uniform(1.0, 100.0), 2),
            "decimal": lambda: round(random.uniform(1.0, 100.0), 2),
            "bool": lambda: random.choice([True, False]),
            "boolean": lambda: random.choice([True, False]),
            "date": lambda: self.faker.date_between(start_date="-5y", end_date="today"),
            "str": lambda: f"generated_value_{random.randint(1, 9999)}",
            "string": lambda: f"generated_value_{random.randint(1, 9999)}",
            "text": lambda: f"generated_value_{random.randint(1, 9999)}",
        }

        generator = fallbacks.get(data_type.lower(), lambda: f"default_value_{random.randint(1, 9999)}")
        return generator()

    def clear_openai_cache(self, cache_key: str = None):
        """Clear OpenAI cache for specific key or all keys"""
        if cache_key:
            self._openai_cache.pop(cache_key, None)
            self._cache_usage_count.pop(cache_key, None)
        else:
            self._openai_cache.clear()
            self._cache_usage_count.clear()
        self.logger.info(f"Cleared OpenAI cache: {cache_key or 'all'}")

    def get_cache_statistics(self) -> dict:
        """Get statistics about OpenAI cache usage and performance"""
        return {
            "openai_enabled": self.openai_enabled,
            "cached_rules": len(self._openai_cache),
            "total_cached_values": sum(len(values) for values in self._openai_cache.values()),
            "cache_usage": {key: count for key, count in self._cache_usage_count.items()},
            "performance_stats": {
                "total_requests": self._openai_requests,
                "cache_hits": self._openai_cache_hits,
                "failures": self._openai_failures,
                "estimated_cost_usd": self._cost_tracker,
                "cost_limit_usd": self.openai_config.cost_limit_usd if self.openai_config else None,
                "cache_hit_rate": (self._openai_cache_hits / (self._openai_requests + self._openai_cache_hits)) if (
                                                                                                                               self._openai_requests + self._openai_cache_hits) > 0 else 0
            },
            "configuration": {
                "model": self.openai_config.model if self.openai_config else None,
                "cache_size": self._default_cache_size,
                "temperature": self.openai_config.temperature if self.openai_config else None,
                "max_tokens": self.openai_config.max_tokens if self.openai_config else None,
                "timeout_seconds": self.openai_config.timeout_seconds if self.openai_config else None,
                "retry_attempts": self.openai_config.retry_attempts if self.openai_config else None,
                "fallback_enabled": self.openai_config.fallback_enabled if self.openai_config else None
            }
        }

    def reset_performance_stats(self):
        """Reset performance tracking statistics"""
        self._openai_requests = 0
        self._openai_cache_hits = 0
        self._openai_failures = 0
        self._cost_tracker = 0.0
        self.logger.info("OpenAI performance statistics reset")

    # Keep all existing methods unchanged for backward compatibility
    def _generate_from_string_rule(self, rule: str) -> Any:
        """Generate value from string rule (faker method name)"""
        cleaned_rule = rule.replace(" ", "").replace("_", "").lower()

        # Direct mappings for common cases
        direct_mappings = {
            "bool": lambda: random.choice([True, False]),
            "uuid": lambda: self.faker.uuid4(),
            "cc": lambda: self.faker.credit_card_number(),
            "cc_cvv": lambda: self.faker.credit_card_security_code(),
            "cc_expiry_date": lambda: self.faker.credit_card_expire(),
            "phone": lambda: self.faker.phone_number(),
            "phonenumber": lambda: self.faker.phone_number(),
            "phoneno": lambda: self.faker.phone_number(),
            "firstname": lambda: self.faker.first_name(),
            "lastname": lambda: self.faker.last_name(),
            "timestamp": lambda: self.faker.date_time().strftime("%Y-%m-%d %H:%M:%S"),
        }

        # Try direct mapping first
        if rule in direct_mappings:
            return direct_mappings[rule]()
        if cleaned_rule in direct_mappings:
            return direct_mappings[cleaned_rule]()

        # Try faker method
        return self._try_faker_method(rule, cleaned_rule)

    def _try_faker_method(self, original_rule: str, cleaned_rule: str) -> Any:
        """Try to call faker method with fallback"""
        faker_methods = {x.replace("_", ""): x for x in dir(self.faker) if not x.startswith("_")}
        faker_methods.update({
            ''.join([y[0] for y in x.split('_')]): x
            for x in dir(self.faker)
            if '_' in x and not x.startswith('_')
        })

        method_name = faker_methods.get(original_rule) or faker_methods.get(cleaned_rule)
        if method_name:
            try:
                return getattr(self.faker, method_name)()
            except AttributeError:
                self.logger.warning(f"Faker method '{method_name}' not found")

        return None

    def _generate_from_dict_rule(self, rule: dict, data_type: str) -> Any:
        """Generate value from dictionary rule"""
        rule_type = rule.get("type")

        generators = {
            "choice": lambda: self._generate_choice(rule),
            "date": lambda: self._generate_date_range(rule),
            "date_range": lambda: self._generate_date_range(rule),
            "time": lambda: self._generate_time_range(rule),
            "time_range": lambda: self._generate_time_range(rule),
            "timestamp": lambda: self._generate_timestamp_range(rule),
            "timestamp_range": lambda: self._generate_timestamp_range(rule),
            "range": lambda: self._generate_numeric_range(rule, data_type),
            "fixed": lambda: rule.get("value"),
            "default": lambda: rule.get("value"),
            "email": lambda: self.faker.email(),
            "phone_number": lambda: self.faker.phone_number(),
            "uuid": lambda: self.faker.uuid4(),
            "regex": lambda: self._generate_regex_value(rule)
        }

        if rule_type in generators:
            value = generators[rule_type]()
        else:
            value = self.generate_by_rule(rule_type, data_type) if rule_type else None

        if 'prefix' in rule or 'suffix' in rule:
            value = self._apply_prefix_suffix(value, rule)

        if rule_type == 'regex' or 'regex' in rule:
            value = self._apply_regex_validation(value, rule)
        return value

    def _apply_prefix_suffix(self, value: Any, rule: dict) -> Any:
        """Apply prefix and/or suffix to generated value"""
        if value is None:
            return value

        # Convert value to string for prefix/suffix operations
        str_value = str(value)

        # Apply prefix
        prefix = rule.get("prefix", "")
        if prefix:
            str_value = f"{prefix}{str_value}"

        # Apply suffix
        suffix = rule.get("suffix", "")
        if suffix:
            str_value = f"{str_value}{suffix}"

        # Return as string if prefix/suffix was applied, otherwise return original type
        if prefix or suffix:
            return str_value

        return value

    def _generate_choice(self, rule: dict) -> Any:
        """Generate value from choices with optional probabilities"""
        choices = rule.get("value", [])
        probabilities = rule.get("probabilities", {})

        if probabilities:
            weights = [probabilities.get(choice, 1.0) for choice in choices]
            return random.choices(choices, weights=weights, k=1)[0]
        return random.choice(choices)

    def _generate_date_range(self, rule: dict) -> Any:
        """Generate date within range"""
        start_date = rule.get("start", "1950-01-01")
        end_date = rule.get("end", datetime.now().strftime("%Y-%m-%d"))

        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        delta = end - start
        return (start + timedelta(days=random.randint(0, delta.days))).date()

    def _generate_time_range(self, rule: dict) -> str:
        """Generate time within range"""
        start_time = rule.get("start", "00:00:00")
        end_time = rule.get("end", "23:59:59")

        start_dt = datetime.strptime(f"1970-01-01 {start_time}", "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(f"1970-01-01 {end_time}", "%Y-%m-%d %H:%M:%S")

        return self.faker.date_time_between_dates(start_dt, end_dt).strftime("%H:%M:%S")

    def _generate_timestamp_range(self, rule: dict) -> str:
        """Generate timestamp within range"""
        start_ts = rule.get("start", "2000-01-01 00:00:00")
        end_ts = rule.get("end", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        start_dt = datetime.strptime(start_ts, "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(end_ts, "%Y-%m-%d %H:%M:%S")

        return self.faker.date_time_between_dates(start_dt, end_dt).strftime("%Y-%m-%d %H:%M:%S")

    def _generate_numeric_range(self, rule: dict, data_type: str) -> Any:
        """Generate numeric value within range"""
        min_val = rule.get("min", 0)
        max_val = rule.get("max", sys.maxsize)

        if data_type in ["int", "str"]:
            return random.randint(int(min_val), int(max_val))
        elif data_type in ["float", "str"]:
            return round(random.uniform(min_val, max_val), 2)
        return min_val

    def _generate_regex_value(self, rule: dict) -> str:
        pattern = rule.get('regex')
        if pattern is None:
            return self.faker.sentence()
        return rstr.xeger(pattern)

    def _apply_regex_validation(self, value: Any, rule: dict) -> Any:
        """Apply regex validation with retry logic"""
        rule_regex = rule.get("regex")
        if not rule_regex or value is None:
            return value
        validator = UnifiedValidator(logger=self.logger)

        max_attempts = 10
        attempts = 0

        while not validator.validate_value(str(value), rule) and attempts < max_attempts:
            rule_type = rule.get("type")
            if rule_type == "email":
                base_value = self.faker.email()
            elif rule_type == "phone_number":
                base_value = self._generate_phone_matching_regex(rule_regex)
            else:
                base_value = self.generate_by_rule(rule_type, "str")

            # Reapply prefix/suffix after regenerating base value
            value = self._apply_prefix_suffix(base_value, rule)
            attempts += 1

        return value

    def _generate_phone_matching_regex(self, regex_pattern: str) -> str:
        """Generate phone number matching regex pattern"""
        if "10,15" in regex_pattern:
            length = random.randint(10, 15)
            return ''.join([str(random.randint(0, 9)) for _ in range(length)])
        return self.faker.phone_number()

    def _generate_default_by_type(self, data_type: str) -> Any:
        """Generate default value based on data type"""
        defaults = {
            "int": lambda: random.randint(1, 100000),
            "float": lambda: round(random.uniform(1.0, 100.0), 2),
            "bool": lambda: random.choice([True, False]),
            "date": lambda: self.faker.date_between(start_date="-5y", end_date="today"),
            "str": lambda: self.faker.text(max_nb_chars=50),
        }

        return defaults.get(data_type, lambda: None)()
